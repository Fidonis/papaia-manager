/**
 * Pattern 9: dates, times and numbers in fixed formats.
 *
 * The tables equal `contract/vectors/formats.json` of the kit (the tests
 * compare them and run the same vectors as the Python binding). Fixed patterns
 * and an own month list, no locale data, so every module prints the same
 * characters.
 */

export type Language = "de" | "en";
export type MomentKind = "due" | "reminder" | "next_run" | "log" | "version" | "data_state";

export interface LanguageFormat {
  readonly date: string;
  readonly time: string;
  readonly months?: readonly string[];
  readonly weekdays: readonly string[];
  readonly weekday_separator: string;
  readonly date_time_separator: string;
  readonly decimal: string;
  readonly group: string;
}

export const LANGUAGE_FORMATS: Readonly<Record<Language, LanguageFormat>> = {
  de: {
    date: "{dd}.{mm}.{yyyy}",
    time: "{HH}:{MM}",
    weekdays: ["Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa.", "So."],
    weekday_separator: ", ",
    date_time_separator: ", ",
    decimal: ",",
    group: ".",
  },
  en: {
    date: "{d} {mon} {yyyy}",
    time: "{HH}:{MM}",
    months: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    weekdays: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    weekday_separator: " ",
    date_time_separator: ", ",
    decimal: ".",
    group: ",",
  },
};

/** Kind of time value -> whether a weekday stands before the date. */
export const WEEKDAY_KINDS: Readonly<Record<MomentKind, boolean>> = {
  due: true,
  reminder: true,
  next_run: true,
  log: false,
  version: false,
  data_state: false,
};

export const MAX_DECIMALS = 12;
const MAX_NUMBER_CHARS = 64;
const ZONE = /^[A-Za-z][A-Za-z0-9_+-]*(?:\/[A-Za-z0-9_+-]+)*$/;
const NUMBER = /^-?\d+(?:\.\d+)?$/;

export interface Moment {
  readonly iso: string;
  readonly weekday: string | null;
  readonly date: string;
  readonly time: string;
  /** Date and time, the content of the `<time>` element. */
  readonly stamp: string;
  /** What the person reads. */
  readonly text: string;
  readonly weekdaySeparator: string;
}

function fail(message: string): RangeError {
  return new RangeError(`format: ${message}`);
}

function languageFormat(lang: unknown): LanguageFormat {
  if (lang !== "de" && lang !== "en") throw fail("unknown language, expected de or en");
  return LANGUAGE_FORMATS[lang];
}

function pad(value: number, width: number): string {
  return String(value).padStart(width, "0");
}

function fill(pattern: string, fields: Readonly<Record<string, string>>): string {
  return pattern.replace(/\{([A-Za-z]+)\}/g, (_, name: string) => fields[name] ?? "");
}

interface LocalFields {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
}

function localFields(instant: Date, timeZone: string): LocalFields {
  let parts: Intl.DateTimeFormatPart[];
  try {
    parts = new Intl.DateTimeFormat("en-US", {
      timeZone,
      hourCycle: "h23",
      year: "numeric",
      month: "numeric",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
    }).formatToParts(instant);
  } catch {
    throw fail("unknown time zone");
  }
  const value = (type: Intl.DateTimeFormatPartTypes): number => {
    const part = parts.find((p) => p.type === type);
    if (part === undefined) throw fail("time zone data incomplete");
    return Number(part.value);
  };
  return {
    year: value("year"),
    month: value("month"),
    day: value("day"),
    hour: value("hour"),
    minute: value("minute"),
    second: value("second"),
  };
}

/** Format `value` (an instant) for a person reading `lang` in `timeZone`. */
export function formatMoment(
  value: Date,
  kind: MomentKind,
  lang: Language,
  timeZone: string,
): Moment {
  if (!(value instanceof Date) || Number.isNaN(value.getTime())) throw fail("value must be a valid Date");
  if (!Object.hasOwn(WEEKDAY_KINDS, kind)) throw fail("unknown kind of time value");
  const spec = languageFormat(lang);
  if (typeof timeZone !== "string" || timeZone.length > 64 || !ZONE.test(timeZone)) {
    throw fail("time zone must be an IANA name such as Europe/Berlin");
  }
  const instant = new Date(Math.floor(value.getTime() / 1000) * 1000);
  const local = localFields(instant, timeZone);
  const asUtc = Date.UTC(local.year, local.month - 1, local.day, local.hour, local.minute, local.second);
  const offsetMinutes = Math.round((asUtc - instant.getTime()) / 60000);
  const sign = offsetMinutes < 0 ? "-" : "+";
  const offset = `${sign}${pad(Math.floor(Math.abs(offsetMinutes) / 60), 2)}:${pad(Math.abs(offsetMinutes) % 60, 2)}`;
  const fields = {
    d: String(local.day),
    dd: pad(local.day, 2),
    mm: pad(local.month, 2),
    mon: spec.months?.[local.month - 1] ?? "",
    yyyy: pad(local.year, 4),
    HH: pad(local.hour, 2),
    MM: pad(local.minute, 2),
  };
  // Monday = 0, as in the weekday lists.
  const weekdayIndex = (new Date(Date.UTC(local.year, local.month - 1, local.day)).getUTCDay() + 6) % 7;
  const date = fill(spec.date, fields);
  const time = fill(spec.time, fields);
  const stamp = `${date}${spec.date_time_separator}${time}`;
  const weekday = WEEKDAY_KINDS[kind] ? (spec.weekdays[weekdayIndex] ?? null) : null;
  return {
    iso: `${fields.yyyy}-${fields.mm}-${fields.dd}T${fields.HH}:${fields.MM}:${pad(local.second, 2)}${offset}`,
    weekday,
    date,
    time,
    stamp,
    text: weekday === null ? stamp : `${weekday}${spec.weekday_separator}${stamp}`,
    weekdaySeparator: spec.weekday_separator,
  };
}

function escapeHtml(text: string): string {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/** Markup of pattern 9: weekday as its own element before `<time>`, escaped. */
export function momentHtml(moment: Moment): string {
  const stamp = `<time datetime="${escapeHtml(moment.iso)}">${escapeHtml(moment.stamp)}</time>`;
  if (moment.weekday === null) return stamp;
  return `<span data-pk-weekday>${escapeHtml(moment.weekday)}</span>${escapeHtml(moment.weekdaySeparator)}${stamp}`;
}

function plainDecimal(value: unknown): string {
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw fail("number must be finite");
    const text = String(value);
    if (/e/i.test(text)) throw fail("number out of range");
    return text;
  }
  if (typeof value === "string" && value.length <= MAX_NUMBER_CHARS && NUMBER.test(value)) return value;
  throw fail("number expected (number or a plain decimal string)");
}

/** Round the digits of a plain non-negative decimal half up to `decimals` places. */
function roundHalfUp(whole: string, fraction: string, decimals: number): [string, string] {
  if (fraction.length <= decimals) return [whole, fraction.padEnd(decimals, "0")];
  const keep = whole + fraction.slice(0, decimals);
  const up = (fraction.charCodeAt(decimals) - 48) >= 5;
  let digits = keep;
  if (up) {
    const chars = keep.split("");
    let i = chars.length - 1;
    while (i >= 0) {
      if (chars[i] === "9") {
        chars[i] = "0";
        i -= 1;
      } else {
        chars[i] = String(Number(chars[i]) + 1);
        break;
      }
    }
    digits = (i < 0 ? "1" : "") + chars.join("");
  }
  const cut = digits.length - decimals;
  return [digits.slice(0, cut) || "0", digits.slice(cut)];
}

/** `1234567.5` -> de `1.234.567,5`, en `1,234,567.5`; `decimals` rounds half up. */
export function formatNumber(value: number | string, lang: Language, decimals?: number | null): string {
  const spec = languageFormat(lang);
  const plain = plainDecimal(value);
  const negative = plain.startsWith("-");
  const unsigned = negative ? plain.slice(1) : plain;
  let [whole = "0", fraction = ""] = unsigned.split(".");
  if (decimals !== undefined && decimals !== null) {
    if (!Number.isInteger(decimals) || decimals < 0 || decimals > MAX_DECIMALS) {
      throw fail(`decimals must be an integer between 0 and ${MAX_DECIMALS}`);
    }
    [whole, fraction] = roundHalfUp(whole, fraction, decimals);
  }
  whole = whole.replace(/^0+(?=\d)/, "");
  const groups: string[] = [];
  while (whole.length > 3) {
    groups.unshift(whole.slice(-3));
    whole = whole.slice(0, -3);
  }
  groups.unshift(whole);
  let text = groups.join(spec.group);
  if (fraction) text = `${text}${spec.decimal}${fraction}`;
  const isZero = /^[0]*$/.test(groups.join("") + fraction);
  return negative && !isZero ? `-${text}` : text;
}
