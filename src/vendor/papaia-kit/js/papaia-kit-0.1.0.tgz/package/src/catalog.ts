/**
 * Types of the platform catalog as a user interface sees it, and a reader that
 * checks the parts the helpers of this package use.
 *
 * The module's own server reads `services.json` with the Python reader (schema,
 * hashes, size and depth limits) and hands the console what it needs. The
 * browser checks again what it relies on, because an address taken from the
 * catalog ends up in a link: `ui[]` items with their targets follow the schema
 * `platform-services.v1` strictly (unknown fields rejected); other entry fields
 * are not read and not kept.
 */

/** Run state of an installed module. */
export type State = "running" | "stopped";

/** Text in both interface languages. */
export interface Text {
  readonly de: string;
  readonly en: string;
}

/** A named target: an own path with `{placeholder}` segments. */
export interface Target {
  readonly pattern: string;
  readonly afterDone: string | null;
}

/** One user interface surface (`ui[]` item) together with its entry's state. */
export interface Surface {
  readonly id: string;
  readonly entryId: string;
  readonly state: State | null;
  readonly running: boolean;
  readonly title: Text;
  readonly summary: Text | null;
  readonly icon: string;
  readonly order: number;
  readonly publicUrl: string;
  readonly visibleForRoles: readonly string[];
  readonly opensIn: "same_tab" | "new_tab";
  readonly targets: Readonly<Record<string, Target>>;
  readonly adminUrl: string | null;
}

/** The checked, immutable view of a catalog. */
export interface Catalog {
  readonly surfaces: readonly Surface[];
}

/** The catalog has a shape the helpers cannot rely on. Names the place, never a value. */
export class CatalogShapeError extends Error {
  readonly place: string;

  constructor(place: string, rule: string) {
    super(`${place}: ${rule}`);
    this.name = "CatalogShapeError";
    this.place = place;
  }
}

// The same expressions as schemas/platform-services.v1.schema.json. JavaScript
// `$` without the m flag matches only at the end, so no trailing line break passes.
const IDENTIFIER = /^[a-z0-9][a-z0-9._-]{0,127}$/;
const NAME = /^[a-z][a-z0-9_-]{0,62}$/;
const ICON = /^[a-z0-9][a-z0-9-]{0,39}$/;
const HOST_KEY = /^[a-z0-9][a-z0-9-]{0,62}$/;
const TARGET_NAME = /^[a-z][a-z0-9_]{0,39}$/;
const HOST = "[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*(:[0-9]{1,5})?";
const PUBLIC_URL = new RegExp(`^https://${HOST}(/[A-Za-z0-9._~%-]+)*/?$`);
const PATH = /^(\/[A-Za-z0-9._~%-]+)*\/?$/;
const PATH_PATTERN = /^(\/([A-Za-z0-9._~%-]|\{[a-z][a-z0-9_]{0,39}\})+)*\/?$/;
const MAX_TEXT = 200;
const MAX_SERVICES = 500;
const MAX_ROLES = 64;
const MAX_TARGETS = 50;

const UI_FIELDS = new Set([
  "id",
  "title",
  "summary",
  "example",
  "icon",
  "order",
  "host_key",
  "path",
  "public_url",
  "visible_for_roles",
  "targets",
  "admin_url",
  "opens_in",
]);
const UI_REQUIRED = ["id", "title", "icon", "order", "public_url", "visible_for_roles", "opens_in"];
const TARGET_FIELDS = new Set(["pattern", "after_done"]);

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function own(value: Record<string, unknown>, key: string): unknown {
  return Object.prototype.hasOwnProperty.call(value, key) ? value[key] : undefined;
}

function object(value: unknown, place: string): Record<string, unknown> {
  if (!isObject(value)) {
    throw new CatalogShapeError(place, "must be an object");
  }
  return value;
}

function onlyFields(value: Record<string, unknown>, allowed: Set<string>, place: string): void {
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) {
      throw new CatalogShapeError(place, "unknown field");
    }
  }
}

function matching(value: unknown, pattern: RegExp, place: string, limit = 2048): string {
  if (typeof value !== "string" || value.length > limit || !pattern.test(value)) {
    throw new CatalogShapeError(place, "does not match the schema");
  }
  return value;
}

function text(value: unknown, place: string): Text {
  const raw = object(value, place);
  onlyFields(raw, new Set(["de", "en"]), place);
  const result: Record<string, string> = {};
  for (const lang of ["de", "en"]) {
    const item = own(raw, lang);
    // Counted in code points, as JSON Schema counts.
    if (typeof item !== "string" || item.length === 0 || [...item].length > MAX_TEXT) {
      throw new CatalogShapeError(`${place}/${lang}`, "must be a text of 1 to 200 characters");
    }
    result[lang] = item;
  }
  return Object.freeze(result) as unknown as Text;
}

function targets(value: unknown, place: string): Readonly<Record<string, Target>> {
  if (value === undefined) {
    return Object.freeze({});
  }
  const raw = object(value, place);
  const names = Object.keys(raw);
  if (names.length > MAX_TARGETS) {
    throw new CatalogShapeError(place, "too many targets");
  }
  const result: Record<string, Target> = Object.create(null) as Record<string, Target>;
  for (const name of names) {
    if (!TARGET_NAME.test(name)) {
      throw new CatalogShapeError(place, "target name does not match the schema");
    }
    const where = `${place}/${name}`;
    const target = object(raw[name], where);
    onlyFields(target, TARGET_FIELDS, where);
    const afterDone = own(target, "after_done");
    result[name] = Object.freeze({
      pattern: matching(own(target, "pattern"), PATH_PATTERN, `${where}/pattern`),
      afterDone: afterDone === undefined ? null : matching(afterDone, PATH, `${where}/after_done`),
    });
  }
  return Object.freeze(result);
}

function roles(value: unknown, place: string): readonly string[] {
  if (!Array.isArray(value) || value.length > MAX_ROLES) {
    throw new CatalogShapeError(place, "must be a list of at most 64 role names");
  }
  const result = value.map((role, index) => matching(role, NAME, `${place}/${index}`));
  if (new Set(result).size !== result.length) {
    throw new CatalogShapeError(place, "role names must be unique");
  }
  return Object.freeze(result);
}

function surface(value: unknown, entryId: string, state: State | null, place: string): Surface {
  const raw = object(value, place);
  onlyFields(raw, UI_FIELDS, place);
  for (const key of UI_REQUIRED) {
    if (own(raw, key) === undefined) {
      throw new CatalogShapeError(`${place}/${key}`, "is required");
    }
  }
  const order = own(raw, "order");
  if (typeof order !== "number" || !Number.isInteger(order) || order < 0 || order > 1000) {
    throw new CatalogShapeError(`${place}/order`, "must be an integer from 0 to 1000");
  }
  const opensIn = own(raw, "opens_in");
  if (opensIn !== "same_tab" && opensIn !== "new_tab") {
    throw new CatalogShapeError(`${place}/opens_in`, "must be same_tab or new_tab");
  }
  const summary = own(raw, "summary");
  const adminUrl = own(raw, "admin_url");
  // Not used by the helpers, still checked: the view holds only checked values.
  if (own(raw, "example") !== undefined) text(own(raw, "example"), `${place}/example`);
  if (own(raw, "host_key") !== undefined) matching(own(raw, "host_key"), HOST_KEY, `${place}/host_key`);
  if (own(raw, "path") !== undefined) matching(own(raw, "path"), PATH, `${place}/path`);
  return Object.freeze({
    id: matching(own(raw, "id"), IDENTIFIER, `${place}/id`),
    entryId,
    state,
    running: state === "running",
    title: text(own(raw, "title"), `${place}/title`),
    summary: summary === undefined ? null : text(summary, `${place}/summary`),
    icon: matching(own(raw, "icon"), ICON, `${place}/icon`),
    order,
    publicUrl: matching(own(raw, "public_url"), PUBLIC_URL, `${place}/public_url`),
    visibleForRoles: roles(own(raw, "visible_for_roles"), `${place}/visible_for_roles`),
    opensIn,
    targets: targets(own(raw, "targets"), `${place}/targets`),
    adminUrl: adminUrl === undefined ? null : matching(adminUrl, PATH, `${place}/admin_url`),
  });
}

/** Check the parts of a parsed `services.json` the helpers use; returns an immutable view. */
export function readCatalog(value: unknown): Catalog {
  const root = object(value, "(root)");
  const services = own(root, "services");
  if (!Array.isArray(services) || services.length > MAX_SERVICES) {
    throw new CatalogShapeError("services", "must be a list of at most 500 entries");
  }
  const surfaces: Surface[] = [];
  const seen = new Set<string>();
  services.forEach((rawEntry: unknown, index: number) => {
    const place = `services/${index}`;
    const entry = object(rawEntry, place);
    const entryId = matching(own(entry, "id"), IDENTIFIER, `${place}/id`);
    const rawState = own(entry, "state");
    if (rawState !== undefined && rawState !== "running" && rawState !== "stopped") {
      throw new CatalogShapeError(`${place}/state`, "must be running or stopped");
    }
    const state: State | null = rawState === undefined ? null : rawState;
    const ui = own(entry, "ui");
    if (ui === undefined) {
      return;
    }
    if (!Array.isArray(ui)) {
      throw new CatalogShapeError(`${place}/ui`, "must be a list");
    }
    ui.forEach((item: unknown, uiIndex: number) => {
      const read = surface(item, entryId, state, `${place}/ui/${uiIndex}`);
      if (seen.has(read.id)) {
        throw new CatalogShapeError(`${place}/ui/${uiIndex}/id`, "duplicate switcher id");
      }
      seen.add(read.id);
      surfaces.push(read);
    });
  });
  return Object.freeze({ surfaces: Object.freeze(surfaces) });
}

/** The surface with switcher id `id`, if the catalog has one. */
export function findSurface(catalog: Catalog, id: string): Surface | null {
  return catalog.surfaces.find((s) => s.id === id) ?? null;
}
