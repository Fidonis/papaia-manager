/**
 * Which modules a person sees in the switcher, and how a link to a module looks
 * (oberflaeche 2.2 and 2.4). Same rule and same vectors as the Python binding
 * (`contract/vectors/visible_modules.json`):
 *
 *     visibleModules(catalog, roles) =
 *       sort by (order, id) [ s in catalog.surfaces
 *         | s.state == "running"
 *         and (s.visibleForRoles is empty or shares a role with roles) ]
 *
 * `roles` is the `roles` claim of the ID token of the module's own client.
 * Visibility is display only: every module checks rights server-side on every
 * request, so nothing here grants or withholds access.
 */
import { findSurface, type Catalog, type Surface } from "./catalog.ts";

/** How another module shows a link to a module. */
export const LinkState = {
  /** Installed, running, visible to the person: a normal link. */
  OPEN: "open",
  /** Installed but stopped: a disabled link with "<module> is not reachable right now". */
  LOCKED: "locked",
  /** Installed, but not for the person's roles: no link. */
  HIDDEN: "hidden",
  /** Not installed: no link; dependent places show the "not set up" sentence. */
  ABSENT: "absent",
} as const;

export type LinkState = (typeof LinkState)[keyof typeof LinkState];

function held(roles: Iterable<string>): ReadonlySet<string> {
  // A single role passed as a string would otherwise be read as its characters.
  if (typeof roles === "string" || roles === null || typeof roles !== "object") {
    throw new TypeError("roles must be a collection of role names, not a single string");
  }
  const result = new Set<string>();
  for (const role of roles as Iterable<unknown>) {
    if (typeof role !== "string") {
      throw new TypeError("every role must be a string");
    }
    result.add(role);
  }
  return result;
}

function forRoles(surface: Surface, roles: ReadonlySet<string>): boolean {
  return surface.visibleForRoles.length === 0 || surface.visibleForRoles.some((r) => roles.has(r));
}

// Code unit order equals code point order for the ASCII ids the schema allows,
// so this matches Python's string order.
function byOrderThenId(a: Surface, b: Surface): number {
  if (a.order !== b.order) {
    return a.order - b.order;
  }
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

/** Switcher surfaces for `roles`, ordered by `order` and then `id`. */
export function visibleModules(catalog: Catalog, roles: Iterable<string>): readonly Surface[] {
  const set = held(roles);
  return Object.freeze(
    catalog.surfaces.filter((s) => s.running && forRoles(s, set)).sort(byOrderThenId),
  );
}

/** State of a link to the module with switcher id `surfaceId`. */
export function linkState(catalog: Catalog, surfaceId: string, roles: Iterable<string>): LinkState {
  const set = held(roles);
  const surface = findSurface(catalog, surfaceId);
  if (surface === null) {
    return LinkState.ABSENT;
  }
  if (!forRoles(surface, set)) {
    return LinkState.HIDDEN;
  }
  return surface.running ? LinkState.OPEN : LinkState.LOCKED;
}
