// Landmarks, page title, shell zones and reflow (K5 c, PLT-75-A4, PLT-75-A6). The browser side
// (collect.ts) reads a snapshot of the page; the checks here are pure.

export const ZONES = ["brand", "switcher", "nav", "footer", "page-header"] as const;
export const SIDEBAR_PX = 256;
export const TOLERANCE_PX = 1;
const TITLE_SEPARATOR = " – ";

export interface LandmarkSnapshot {
  lang: string;
  title: string;
  /** content of <meta name="papaia-kit">, null without the element */
  kitMeta: string | null;
  firstFocusable: { tag: string; className: string; href: string | null } | null;
  mains: number;
  /** every nav element with its accessible name (aria-label or aria-labelledby text) */
  navs: { name: string }[];
  /** heading levels in document order */
  headings: number[];
  /** data-pk-zone values in document order */
  zones: string[];
  /** width of the sidebar in CSS pixels; null below the drawer breakpoint */
  sidebarWidth: number | null;
  /** left edge of the zones brand, switcher and footer in CSS pixels (wide viewport only) */
  zoneLeft: Record<string, number>;
  /** buttons and links with data-pk-variant="primary" inside page-header */
  primaryInHeader: number;
}

export interface Finding {
  check: string;
  message: string;
}

export interface LandmarkOptions {
  lang: string;
  kitVersion: string;
}

function zoneOrder(zones: string[]): string | null {
  const shell = zones.filter((z) => (ZONES as readonly string[]).includes(z));
  for (const zone of ZONES) {
    const count = shell.filter((z) => z === zone).length;
    if (count !== 1) return `zone ${zone} appears ${count} times, expected once`;
  }
  return shell.join(",") === ZONES.join(",") ? null : `zones in order ${shell.join(", ")}, expected ${ZONES.join(", ")}`;
}

/** Every deviation of a page from the structure rules of the shell contract. */
export function checkLandmarks(snap: LandmarkSnapshot, opts: LandmarkOptions): Finding[] {
  const found: Finding[] = [];
  const add = (check: string, message: string): void => {
    found.push({ check, message });
  };
  const first = snap.firstFocusable;
  if (!first || first.tag !== "a" || !first.className.split(/\s+/).includes("pk-skip") || !first.href?.startsWith("#")) {
    add("skip-link", "the first focusable element is not the skip link a.pk-skip to the content");
  }
  if (snap.mains !== 1) add("main", `${snap.mains} main elements, expected exactly one`);
  if (snap.navs.length === 0) add("nav-name", "no nav element");
  else if (snap.navs.some((n) => n.name.trim() === "")) add("nav-name", "a nav element has no accessible name");
  const h1 = snap.headings.filter((l) => l === 1).length;
  if (h1 !== 1) add("h1", `${h1} h1 elements, expected exactly one`);
  else {
    const skipped = snap.headings.findIndex((level, i) => i > 0 && level > snap.headings[i - 1]! + 1);
    if (skipped > 0) {
      add("heading-levels", `heading level ${snap.headings[skipped]} follows level ${snap.headings[skipped - 1]}`);
    }
  }
  if (snap.lang !== opts.lang) add("lang", `lang is "${snap.lang}", expected "${opts.lang}"`);
  const parts = snap.title.split(TITLE_SEPARATOR);
  if (parts.length !== 3 || parts.some((p) => p.trim() === "")) {
    add("title", 'page title is not "<page> – <module> – <installation>"');
  }
  const order = zoneOrder(snap.zones);
  if (order) add("zones", order);
  if (snap.sidebarWidth !== null && Math.abs(snap.sidebarWidth - SIDEBAR_PX) > TOLERANCE_PX) {
    add("sidebar-width", `sidebar is ${snap.sidebarWidth} px wide, expected ${SIDEBAR_PX} ± ${TOLERANCE_PX}`);
  }
  // Below the drawer breakpoint the sidebar is off canvas: width and edges are not measured.
  for (const zone of snap.sidebarWidth === null ? [] : ["brand", "switcher", "footer"]) {
    const left = snap.zoneLeft[zone];
    if (left === undefined || Math.abs(left) > TOLERANCE_PX) {
      add("left-edge", `zone ${zone} starts at ${left ?? "?"} px, expected 0 ± ${TOLERANCE_PX}`);
    }
  }
  if (snap.primaryInHeader > 1) add("primary-action", `${snap.primaryInHeader} primary actions in page-header, at most one`);
  if (snap.kitMeta !== opts.kitVersion) {
    add("papaia-kit-meta", `meta papaia-kit is ${snap.kitMeta ?? "missing"}, expected ${opts.kitVersion}`);
  }
  return found;
}

/** 1.4.10: at the narrow width the page does not scroll horizontally. */
export function checkReflow(size: { scrollWidth: number; innerWidth: number }): Finding[] {
  if (size.scrollWidth <= size.innerWidth) return [];
  return [
    {
      check: "reflow",
      message: `page is ${size.scrollWidth} px wide at a viewport of ${size.innerWidth} px`,
    },
  ];
}
