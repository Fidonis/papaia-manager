// Minimal PNG reader and writer for screenshots (RFC 2083): 8 bits per channel, no interlace.
// Playwright writes exactly this kind of file; anything else is refused.
import { deflateSync, inflateSync } from "node:zlib";

import type { Image } from "./imgdiff.ts";

const SIGNATURE = Uint8Array.from([137, 80, 78, 71, 13, 10, 26, 10]);
const MAX_SIDE = 16_384;
const MAX_PIXELS = 40_000_000;
const CHANNELS: Record<number, number> = { 0: 1, 2: 3, 4: 2, 6: 4 };

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let c = 0xffffffff;
  for (const byte of bytes) c = CRC_TABLE[(c ^ byte) & 0xff]! ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function fail(reason: string): never {
  throw new Error(`not a supported PNG file: ${reason}`);
}

function paeth(a: number, b: number, c: number): number {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
}

/** Decode a PNG file into RGBA pixels. */
export function decodePng(file: Uint8Array): Image {
  if (file.length < 8 + 25 || SIGNATURE.some((b, i) => file[i] !== b)) fail("signature");
  const view = new DataView(file.buffer, file.byteOffset, file.byteLength);
  let offset = 8;
  let width = 0;
  let height = 0;
  let colorType = -1;
  const idat: Uint8Array[] = [];
  let ended = false;
  while (offset + 12 <= file.length && !ended) {
    const length = view.getUint32(offset);
    if (offset + 12 + length > file.length) fail("truncated chunk");
    const typeAndData = file.subarray(offset + 4, offset + 8 + length);
    if (crc32(typeAndData) !== view.getUint32(offset + 8 + length)) fail("checksum");
    const type = String.fromCharCode(...typeAndData.subarray(0, 4));
    const data = typeAndData.subarray(4);
    if (type === "IHDR") {
      const header = new DataView(data.buffer, data.byteOffset, data.byteLength);
      width = header.getUint32(0);
      height = header.getUint32(4);
      colorType = data[9]!;
      if (data[8] !== 8 || data[12] !== 0 || !(colorType in CHANNELS)) fail("bit depth, colour type or interlace");
      if (!width || !height || width > MAX_SIDE || height > MAX_SIDE || width * height > MAX_PIXELS) fail("size");
    } else if (type === "IDAT") idat.push(data);
    else if (type === "IEND") ended = true;
    offset += 12 + length;
  }
  if (!ended || colorType < 0 || idat.length === 0) fail("missing IHDR, IDAT or IEND");
  const channels = CHANNELS[colorType]!;
  const stride = width * channels;
  let raw: Uint8Array;
  try {
    raw = inflateSync(Buffer.concat(idat), { maxOutputLength: (stride + 1) * height });
  } catch {
    fail("image data");
  }
  if (raw.length !== (stride + 1) * height) fail("image data length");
  const pixels = new Uint8Array(stride * height);
  for (let y = 0; y < height; y++) {
    const filter = raw[y * (stride + 1)]!;
    const line = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1));
    const out = y * stride;
    for (let x = 0; x < stride; x++) {
      const a = x >= channels ? pixels[out + x - channels]! : 0;
      const b = y > 0 ? pixels[out - stride + x]! : 0;
      const c = x >= channels && y > 0 ? pixels[out - stride + x - channels]! : 0;
      const value = line[x]!;
      let result: number;
      if (filter === 0) result = value;
      else if (filter === 1) result = value + a;
      else if (filter === 2) result = value + b;
      else if (filter === 3) result = value + ((a + b) >> 1);
      else if (filter === 4) result = value + paeth(a, b, c);
      else fail("filter type");
      pixels[out + x] = result & 0xff;
    }
  }
  const data = new Uint8Array(width * height * 4);
  for (let i = 0, j = 0; i < width * height; i++, j += channels) {
    const gray = channels <= 2;
    const r = pixels[j]!;
    data[i * 4] = r;
    data[i * 4 + 1] = gray ? r : pixels[j + 1]!;
    data[i * 4 + 2] = gray ? r : pixels[j + 2]!;
    data[i * 4 + 3] = channels === 4 ? pixels[j + 3]! : channels === 2 ? pixels[j + 1]! : 255;
  }
  return { width, height, data };
}

function chunk(type: string, data: Uint8Array): Uint8Array {
  const out = new Uint8Array(12 + data.length);
  const view = new DataView(out.buffer);
  view.setUint32(0, data.length);
  for (let i = 0; i < 4; i++) out[4 + i] = type.charCodeAt(i);
  out.set(data, 8);
  view.setUint32(8 + data.length, crc32(out.subarray(4, 8 + data.length)));
  return out;
}

/** Encode RGBA pixels as a PNG file (filter 0, for reference images and tests). */
export function encodePng(img: Image): Uint8Array {
  const header = new Uint8Array(13);
  const view = new DataView(header.buffer);
  view.setUint32(0, img.width);
  view.setUint32(4, img.height);
  header.set([8, 6, 0, 0, 0], 8);
  const stride = img.width * 4;
  const raw = new Uint8Array((stride + 1) * img.height);
  for (let y = 0; y < img.height; y++) raw.set(img.data.subarray(y * stride, (y + 1) * stride), y * (stride + 1) + 1);
  return Buffer.concat([SIGNATURE, chunk("IHDR", header), chunk("IDAT", deflateSync(raw)), chunk("IEND", new Uint8Array())]);
}
