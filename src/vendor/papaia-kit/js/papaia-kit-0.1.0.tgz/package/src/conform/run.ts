// pk-conform and pk-audit runs (K5, contract/specimen.md) on a Playwright browser. The caller
// starts the browser (pinned Playwright container) and passes it in; pages are reached through
// the module's development stack with a test person signed in via the kit's test issuer.
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { join } from "node:path";

import type { Browser, BrowserContext, Page } from "playwright-core";

import { AXE_TAGS, evaluateAxe, REPORT_TAGS, type AxeEvaluation, type AxeRun, type AxeViolation, type KnownEntry } from "./a11y.ts";
import { collectDesign, collectLandmarks, collectReflow, collectStyles, collectTokens, settle } from "./collect.ts";
import { checkDesign } from "./design.ts";
import { compareImages } from "./imgdiff.ts";
import { checkLandmarks, checkReflow, type Finding } from "./landmarks.ts";
import { decodePng } from "./png.ts";
import { DESIGN_VIEWPORTS, MASK, REFIMG_SHOTS, refimgPath, type Shot } from "./refimg.ts";
import { compareSpecimen, READ_PROPS, type Deviation, type SpecimenExpected } from "./specimen.ts";

export const SPECIMEN_PATH = "/_kit/specimen";
export type Theme = "light" | "dark";

export interface Viewports {
  desktop: { width: number; height: number };
  narrow: { width: number; height: number };
}

export interface ConformOptions {
  browser: Browser;
  /** origin of the module under test, e.g. http://127.0.0.1:60320 */
  baseUrl: string;
  /** root of the kit (contract/, refimg/) */
  kitDir: string;
  kitVersion: string;
  module: string;
  lang: "de" | "en";
  themes: Theme[];
  /** Playwright storage state with the signed-in test person */
  storageState?: string;
  /** compare the zones with the reference images, or report them as not checked */
  images: "compare" | "skip";
  /** platform directory of the reference images, e.g. linux-arm64 */
  platform: string | null;
  playwrightVersion: string;
  viewports: Viewports;
}

export interface ImageResult {
  shot: string;
  status: "ok" | "differs" | "not-checked";
  ratio?: number;
  reason?: string;
}

export interface ThemeResult {
  theme: Theme;
  specimen: Deviation[];
  landmarks: Finding[];
  reflow: Finding[];
  images: ImageResult[];
}

export interface ConformReport {
  format: "papaia.pk-conform/1";
  kit: string;
  module: string;
  status: "pass" | "fail" | "incomplete";
  themes: ThemeResult[];
}

export function readJson<T>(path: string): T {
  return JSON.parse(readFileSync(path, "utf-8")) as T;
}

export function loadExpected(kitDir: string, theme: Theme): SpecimenExpected {
  const expected = readJson<SpecimenExpected>(join(kitDir, "contract", `specimen-expected.${theme}.json`));
  if (expected.format !== "papaia.specimen-expected/1" || expected.theme !== theme) {
    throw new Error(`specimen-expected.${theme}.json has the wrong format or theme`);
  }
  return expected;
}

/** Open a page of the module in one theme: data-theme set, fonts loaded. */
export async function openPage(context: BrowserContext, url: string, theme: Theme): Promise<Page> {
  const page = await context.newPage();
  const response = await page.goto(url, { waitUntil: "load" });
  if (!response || response.status() !== 200) {
    throw new Error(`${url}: HTTP ${response?.status() ?? "no response"}`);
  }
  await page.evaluate((t) => {
    document.documentElement.setAttribute("data-theme", t);
  }, theme);
  await page.evaluate(settle);
  return page;
}

async function observeStyles(page: Page, expected: SpecimenExpected): Promise<Record<string, Record<string, string> | null>> {
  const interactive = (n: string): boolean => expected.states[n] === "focus" || expected.states[n] === "hover";
  const rest = Object.fromEntries(Object.entries(expected.selectors).filter(([n]) => !interactive(n)));
  const out = await page.evaluate(collectStyles, { selectors: rest, props: READ_PROPS });
  for (const [name, selector] of Object.entries(expected.selectors)) {
    if (!interactive(name)) continue;
    const target = page.locator(selector);
    if ((await target.count()) < 1) {
      out[name] = null;
      continue;
    }
    if (expected.states[name] === "focus") {
      // Keyboard focus: :focus-visible applies as it does for a person using the keyboard.
      await page.keyboard.press("Escape");
      await target.first().focus();
    } else {
      await target.first().hover();
    }
    await page.evaluate(settle);
    const seen = await page.evaluate(collectStyles, { selectors: { [name]: selector }, props: READ_PROPS });
    out[name] = seen[name] ?? null;
    await page.mouse.move(0, 0);
    await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  }
  await page.evaluate(settle);
  return out;
}

/** Screenshot one shot of the shell (zone, opened menu) with the module name masked. */
export async function captureShot(page: Page, shot: Shot): Promise<Uint8Array> {
  await page.evaluate((open) => {
    for (const d of document.querySelectorAll("details")) d.removeAttribute("open");
    if (open) document.querySelector(open)?.setAttribute("open", "");
    (document.activeElement as HTMLElement | null)?.blur();
  }, shot.open ?? null);
  await page.evaluate(settle);
  const zone = page.locator(shot.zone).first();
  return zone.screenshot({ animations: "disabled", caret: "hide", mask: [page.locator(MASK)], scale: "css" });
}

/** Screenshot of a whole page (reference images of the specimen and composed pages, always module me). */
export async function capturePage(page: Page): Promise<Uint8Array> {
  await page.evaluate(() => {
    (document.activeElement as HTMLElement | null)?.blur();
  });
  await page.mouse.move(0, 0);
  await page.evaluate(settle);
  return page.screenshot({ fullPage: true, animations: "disabled", caret: "hide", scale: "css" });
}

async function compareShots(page: Page, opts: ConformOptions, theme: Theme): Promise<ImageResult[]> {
  if (opts.images === "skip") return REFIMG_SHOTS.map((s) => ({ shot: s.name, status: "not-checked", reason: "skipped" }));
  if (opts.platform === null) {
    return REFIMG_SHOTS.map((s) => ({ shot: s.name, status: "not-checked", reason: "no reference images for this platform" }));
  }
  const results: ImageResult[] = [];
  for (const shot of REFIMG_SHOTS) {
    const rel = refimgPath({ playwright: opts.playwrightVersion, platform: opts.platform, module: opts.module, shot: shot.name, theme });
    let reference: Uint8Array;
    try {
      reference = readFileSync(join(opts.kitDir, rel));
    } catch {
      results.push({ shot: shot.name, status: "not-checked", reason: `missing ${rel}` });
      continue;
    }
    const result = compareImages(decodePng(await captureShot(page, shot)), decodePng(reference));
    results.push({ shot: shot.name, status: result.ok ? "ok" : "differs", ratio: result.ratio });
  }
  return results;
}

/** K5 (a)-(d), (f) and reflow for every theme. */
export async function runConform(opts: ConformOptions): Promise<ConformReport> {
  const themes: ThemeResult[] = [];
  for (const theme of opts.themes) {
    const expected = loadExpected(opts.kitDir, theme);
    const context = await opts.browser.newContext({
      viewport: opts.viewports.desktop,
      colorScheme: theme,
      locale: opts.lang,
      reducedMotion: "reduce",
      ...(opts.storageState ? { storageState: opts.storageState } : {}),
    });
    try {
      const page = await openPage(context, new URL(SPECIMEN_PATH, opts.baseUrl).href, theme);
      const elements = await observeStyles(page, expected);
      const tokens = await page.evaluate(collectTokens, Object.keys(expected.tokens));
      const specimen = compareSpecimen(expected, { elements, tokens });
      const landmarks = checkLandmarks(await page.evaluate(collectLandmarks), { lang: opts.lang, kitVersion: opts.kitVersion });
      const images = await compareShots(page, opts, theme);
      await page.setViewportSize(opts.viewports.narrow);
      const reflow = checkReflow(await page.evaluate(collectReflow));
      themes.push({ theme, specimen, landmarks, reflow, images });
    } finally {
      await context.close();
    }
  }
  const failed = themes.some(
    (t) => t.specimen.length || t.landmarks.length || t.reflow.length || t.images.some((i) => i.status === "differs"),
  );
  const incomplete = themes.some((t) => t.images.some((i) => i.status === "not-checked"));
  return {
    format: "papaia.pk-conform/1",
    kit: opts.kitVersion,
    module: opts.module,
    status: failed ? "fail" : incomplete ? "incomplete" : "pass",
    themes,
  };
}

/** Source of axe-core from the pinned package; refuses another version than the contract's. */
export function axeSource(version: string): string {
  const require = createRequire(import.meta.url);
  const pkg = readJson<{ version: string }>(require.resolve("axe-core/package.json"));
  if (pkg.version !== version) throw new Error(`axe-core ${pkg.version} installed, the kit pins ${version}`);
  return readFileSync(require.resolve("axe-core/axe.min.js"), "utf-8");
}

interface AxeRaw {
  violations: { id: string; impact?: AxeViolation["impact"]; tags: string[]; nodes: { target: unknown[] }[] }[];
}

async function axeOn(page: Page, source: string): Promise<AxeViolation[]> {
  await page.evaluate(settle);
  await page.addScriptTag({ content: source });
  const tags = [...AXE_TAGS, ...REPORT_TAGS];
  const raw = (await page.evaluate(async (runOnly) => {
    const axe = (window as unknown as { axe: { run: (ctx: Document, o: object) => Promise<unknown> } }).axe;
    return axe.run(document, { runOnly: { type: "tag", values: runOnly }, resultTypes: ["violations"] });
  }, tags)) as AxeRaw;
  return raw.violations.map((v) => ({
    id: v.id,
    impact: v.impact ?? null,
    tags: v.tags,
    nodes: v.nodes.length,
    targets: v.nodes.slice(0, 10).map((n) => n.target.map(String).join(" ")),
  }));
}

export interface AuditOptions {
  browser: Browser;
  baseUrl: string;
  paths: string[];
  lang: "de" | "en";
  themes: Theme[];
  storageState?: string;
  axeVersion: string;
  viewport: { width: number; height: number };
}

/** States of a page: at rest, and with every menu (details) and the first dialog open. */
const STATES: [string, (page: Page) => Promise<boolean>][] = [
  ["rest", async () => true],
  [
    "menus-open",
    async (page) =>
      page.evaluate(() => {
        const menus = document.querySelectorAll("details");
        for (const d of menus) d.setAttribute("open", "");
        return menus.length > 0;
      }),
  ],
  [
    "dialog-open",
    async (page) =>
      page.evaluate(() => {
        for (const d of document.querySelectorAll("details")) d.removeAttribute("open");
        const dialog = document.querySelector("dialog");
        if (!dialog) return false;
        dialog.showModal();
        return true;
      }),
  ],
];

/** K5 (e): axe over every page, theme and state. */
export async function runAudit(opts: AuditOptions): Promise<AxeRun[]> {
  const source = axeSource(opts.axeVersion);
  const runs: AxeRun[] = [];
  for (const theme of opts.themes) {
    const context = await opts.browser.newContext({
      viewport: opts.viewport,
      colorScheme: theme,
      locale: opts.lang,
      reducedMotion: "reduce",
      // axe is injected as a script; the page's content security policy stays as served otherwise.
      bypassCSP: true,
      ...(opts.storageState ? { storageState: opts.storageState } : {}),
    });
    try {
      for (const path of opts.paths) {
        const page = await openPage(context, new URL(path, opts.baseUrl).href, theme);
        for (const [state, enter] of STATES) {
          if (await enter(page)) runs.push({ page: path, theme, state, violations: await axeOn(page, source) });
        }
        await page.close();
      }
    } finally {
      await context.close();
    }
  }
  return runs;
}

export interface DesignOptions {
  browser: Browser;
  baseUrl: string;
  paths: string[];
  lang: "de" | "en";
  themes: Theme[];
  storageState?: string;
  axeVersion: string;
  /** accepted violations below serious (the module's a11y-known.yaml) */
  known: KnownEntry[];
}

export interface DesignPageResult {
  page: string;
  theme: Theme;
  viewport: string;
  findings: Finding[];
}

export interface DesignReport {
  format: "papaia.pk-design/1";
  status: "pass" | "fail";
  pages: DesignPageResult[];
  a11y: AxeEvaluation;
}

/** pk-conform --design: the design rules at every width, reflow at 320 px and axe, both themes. */
export async function runDesign(opts: DesignOptions): Promise<DesignReport> {
  const source = axeSource(opts.axeVersion);
  const pages: DesignPageResult[] = [];
  const runs: AxeRun[] = [];
  for (const theme of opts.themes) {
    const context = await opts.browser.newContext({
      viewport: DESIGN_VIEWPORTS.desktop,
      colorScheme: theme,
      locale: opts.lang,
      reducedMotion: "reduce",
      bypassCSP: true,
      ...(opts.storageState ? { storageState: opts.storageState } : {}),
    });
    try {
      for (const path of opts.paths) {
        const page = await openPage(context, new URL(path, opts.baseUrl).href, theme);
        for (const [viewport, size] of Object.entries(DESIGN_VIEWPORTS)) {
          await page.setViewportSize(size);
          await page.evaluate(settle);
          const findings =
            viewport === "reflow" ? checkReflow(await page.evaluate(collectReflow)) : checkDesign(await page.evaluate(collectDesign));
          pages.push({ page: path, theme, viewport, findings });
        }
        await page.setViewportSize(DESIGN_VIEWPORTS.desktop);
        for (const [state, enter] of STATES) {
          if (await enter(page)) runs.push({ page: path, theme, state, violations: await axeOn(page, source) });
        }
        await page.close();
      }
    } finally {
      await context.close();
    }
  }
  const a11y = evaluateAxe(runs, opts.known);
  const failed = pages.some((p) => p.findings.length) || !a11y.ok;
  return { format: "papaia.pk-design/1", status: failed ? "fail" : "pass", pages, a11y };
}
