// Design checks of pk-conform --design (contract/design-review.md): a visual quality gate for
// any page of a module. The browser side (collect.ts, collectDesign) reads a snapshot of the
// page; the checks here are pure. Reflow at 320 px and the accessibility run reuse checkReflow
// (landmarks.ts) and evaluateAxe (a11y.ts).
import type { Finding } from "./landmarks.ts";

/** Vertical gaps between siblings in #pk-main are multiples of 0.25rem (at 16 px). */
export const SPACING_STEP_PX = 4;
/** Rounding of the layout engine that a gap may deviate from the scale. */
export const SPACING_TOLERANCE_PX = 0.5;
/** No two interactive elements are closer than this. */
export const MIN_TARGET_GAP_PX = 8;
/** Widest line of a paragraph, in characters ("0" of its font). */
export const MAX_MEASURE_CH = 80;
/** A box of wrapping text narrower than this is a sliver (one word per line). */
export const MIN_TEXT_WIDTH_PX = 120;
/** A text box below MIN_TEXT_WIDTH_PX that wraps inside a parent wider than this is squeezed. */
export const WIDE_PARENT_PX = 400;
/** A text box below MIN_TEXT_WIDTH_PX that wraps onto this many lines is squeezed anywhere. */
export const SQUEEZED_LINES = 3;
/** At most this many primary buttons in page-header. */
export const MAX_PRIMARY_IN_HEADER = 1;
/** Upper bound of every list of a snapshot (a page that large is refused, not checked half). */
export const MAX_ENTRIES = 5000;

export interface Box {
  where: string;
  left: number;
  top: number;
  right: number;
  bottom: number;
  /** `where` of an interactive element that contains this one (not measured against it) */
  inside?: string;
  /** `where` of the open menu panel the element is an item of; items of one panel form one control */
  group?: string;
}

export interface DesignSnapshot {
  /** first family of every --pk-font-* variable on :root, lower case */
  kitFonts: string[];
  /** every element with text of its own: where it is and the first family it is drawn in */
  texts: { where: string; family: string }[];
  /** vertical gaps between block siblings stacked on top of each other inside #pk-main */
  gaps: { where: string; gap: number }[];
  /** interactive elements inside #pk-main (checkbox and radio: with their label) */
  targets: Box[];
  /** buttons and links with data-pk-variant="primary" inside page-header */
  primaryInHeader: number;
  /** paragraphs inside #pk-main: widest line in characters */
  paragraphs: { where: string; chars: number }[];
  /** elements with text of their own inside #pk-main: width, width of the parent, lines of text */
  textBoxes: { where: string; width: number; parentWidth: number; lines: number }[];
  /** elements without focus that draw an outline (a focus ring left standing, a framed block) */
  outlines: { where: string; style: string; width: number }[];
}

function bounded(snap: DesignSnapshot): void {
  for (const [name, list] of [
    ["texts", snap.texts],
    ["gaps", snap.gaps],
    ["targets", snap.targets],
    ["paragraphs", snap.paragraphs],
    ["textBoxes", snap.textBoxes],
    ["outlines", snap.outlines],
    ["kitFonts", snap.kitFonts],
  ] as const) {
    if (!Array.isArray(list) || list.length > MAX_ENTRIES) {
      throw new RangeError(`design snapshot: ${name} must be a list of at most ${MAX_ENTRIES} entries`);
    }
  }
}

function round(value: number): string {
  return String(Math.round(value * 100) / 100);
}

/** Shortest distance between two boxes; 0 when they touch or overlap. */
export function boxDistance(a: Box, b: Box): number {
  const dx = Math.max(0, b.left - a.right, a.left - b.right);
  const dy = Math.max(0, b.top - a.bottom, a.top - b.bottom);
  return Math.hypot(dx, dy);
}

function offScale(gap: number): boolean {
  const rest = Math.abs(gap) % SPACING_STEP_PX;
  return Math.min(rest, SPACING_STEP_PX - rest) > SPACING_TOLERANCE_PX;
}

/** Every deviation of a page from the design rules; empty when the page passes. */
export function checkDesign(snap: DesignSnapshot): Finding[] {
  bounded(snap);
  const found: Finding[] = [];
  const add = (check: string, message: string): void => {
    found.push({ check, message });
  };
  const fonts = new Set(snap.kitFonts.map((f) => f.toLowerCase()));
  for (const text of snap.texts) {
    if (!fonts.has(text.family.toLowerCase())) {
      add("font", `${text.where}: text in "${text.family}", not in a font of the kit (${[...fonts].join(", ")})`);
    }
  }
  for (const { where, gap } of snap.gaps) {
    if (offScale(gap)) add("spacing-scale", `${where}: vertical gap of ${round(gap)} px is not a multiple of 0.25rem`);
  }
  const targets = snap.targets;
  for (let i = 0; i < targets.length; i++) {
    for (let j = i + 1; j < targets.length; j++) {
      const a = targets[i]!;
      const b = targets[j]!;
      if (a.inside === b.where || b.inside === a.where || (a.group !== undefined && a.group === b.group)) continue;
      const distance = boxDistance(a, b);
      if (distance < MIN_TARGET_GAP_PX) {
        add("target-gap", `${a.where} and ${b.where} are ${round(distance)} px apart, at least ${MIN_TARGET_GAP_PX} px`);
      }
    }
  }
  if (snap.primaryInHeader > MAX_PRIMARY_IN_HEADER) {
    add("primary-action", `${snap.primaryInHeader} primary buttons in page-header, at most ${MAX_PRIMARY_IN_HEADER}`);
  }
  for (const { where, chars } of snap.paragraphs) {
    if (chars > MAX_MEASURE_CH + 0.5) add("measure", `${where}: lines of ${round(chars)} characters, at most ${MAX_MEASURE_CH}`);
  }
  // Text that wraps in a box narrower than a short phrase: a column squeezed by its neighbour.
  // Text on one line is shrink-wrapped (a count, a badge) and never narrow.
  for (const { where, width, parentWidth, lines } of snap.textBoxes) {
    if (width >= MIN_TEXT_WIDTH_PX || lines < 2) continue;
    if (parentWidth > WIDE_PARENT_PX || lines >= SQUEEZED_LINES) {
      add(
        "narrow-text",
        `${where}: text box of ${round(width)} px wraps onto ${lines} lines (parent ${round(parentWidth)} px); at least ${MIN_TEXT_WIDTH_PX} px`,
      );
    }
  }
  for (const { where, style, width } of snap.outlines) {
    add("outline", `${where}: ${style} outline of ${round(width)} px without focus; outlines are for keyboard focus only`);
  }
  return found;
}
