// pk-audit baseline (K5 e, PLT-75-A1): axe-core with the WCAG 2.1 A/AA tags; no critical or
// serious violation; every other violation is listed with a ticket in a11y-known.yaml.
// WCAG 2.2 AA runs as report only.

export const AXE_TAGS: readonly string[] = ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"];
export const REPORT_TAGS: readonly string[] = ["wcag22aa"];
const BLOCKING = new Set(["critical", "serious"]);

export interface AxeViolation {
  id: string;
  impact: "minor" | "moderate" | "serious" | "critical" | null;
  tags: string[];
  nodes: number;
  /** selectors of the first affected nodes (at most ten) */
  targets?: string[];
}

export interface AxeRun {
  page: string;
  theme: "light" | "dark";
  state: string;
  violations: AxeViolation[];
}

export interface KnownEntry {
  rule: string;
  page: string;
  ticket: string;
  reason: string;
}

export interface Listed extends AxeViolation {
  page: string;
  theme: string;
  state: string;
}

export interface AxeEvaluation {
  ok: boolean;
  blocking: Listed[];
  unlisted: Listed[];
  listed: Listed[];
  reportOnly: Listed[];
  stale: KnownEntry[];
}

const FIELDS: Record<keyof KnownEntry, RegExp> = {
  rule: /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
  page: /^\/[A-Za-z0-9._~\/{}-]{0,200}$/,
  ticket: /^[A-Za-z0-9._\/-]{1,80}#[0-9]{1,7}$/,
  reason: /^.{10,500}$/,
};
const MAX_FILE = 256 * 1024;

function scalar(raw: string, where: string): string {
  const text = raw.trim();
  if (text.startsWith('"')) {
    if (!/^"[^"\\]*"$/.test(text)) throw new SyntaxError(`${where}: quoted value without escapes expected`);
    return text.slice(1, -1);
  }
  if (/^[\[{&*!|>'%@`]/.test(text) || / #/.test(text)) throw new SyntaxError(`${where}: plain value or "quoted" value expected`);
  return text;
}

/**
 * Read a11y-known.yaml: a YAML list of flat mappings with exactly the fields rule, page,
 * ticket (`<repo>#<number>`) and reason, plain or double-quoted values, comments on own lines.
 */
export function parseKnownList(text: string): KnownEntry[] {
  if (text.length > MAX_FILE) throw new RangeError("a11y-known.yaml: larger than 256 KiB");
  const entries: Partial<KnownEntry>[] = [];
  text.split("\n").forEach((line, index) => {
    const where = `a11y-known.yaml line ${index + 1}`;
    if (/^\s*(#.*)?$/.test(line)) return;
    const m = /^(- |  )([a-z_]+):(?: (.*))?$/.exec(line);
    if (!m) throw new SyntaxError(`${where}: expected "- key: value" or "  key: value"`);
    const [, lead, key = "", value = ""] = m;
    if (lead === "- ") entries.push({});
    const entry = entries.at(-1);
    if (!entry) throw new SyntaxError(`${where}: entry must start with "- "`);
    if (!(key in FIELDS)) throw new SyntaxError(`${where}: unknown field ${key}`);
    const field = key as keyof KnownEntry;
    if (entry[field] !== undefined) throw new SyntaxError(`${where}: field ${key} given twice`);
    entry[field] = scalar(value, where);
  });
  const seen = new Set<string>();
  return entries.map((entry, i) => {
    for (const [field, pattern] of Object.entries(FIELDS) as [keyof KnownEntry, RegExp][]) {
      const value = entry[field];
      if (value === undefined) throw new SyntaxError(`a11y-known.yaml entry ${i + 1}: missing ${field}`);
      if (!pattern.test(value)) throw new SyntaxError(`a11y-known.yaml entry ${i + 1}: ${field} has the wrong form`);
    }
    const key = `${entry.rule} ${entry.page}`;
    if (seen.has(key)) throw new SyntaxError(`a11y-known.yaml entry ${i + 1}: duplicate rule and page`);
    seen.add(key);
    return entry as KnownEntry;
  });
}

function graded(v: AxeViolation): boolean {
  return v.tags.some((t) => AXE_TAGS.includes(t));
}

/** Apply the baseline to the axe runs of every page, theme and state. */
export function evaluateAxe(runs: AxeRun[], known: KnownEntry[]): AxeEvaluation {
  const result: AxeEvaluation = { ok: true, blocking: [], unlisted: [], listed: [], reportOnly: [], stale: [] };
  const used = new Set<KnownEntry>();
  for (const run of runs) {
    for (const v of run.violations) {
      const item: Listed = { ...v, page: run.page, theme: run.theme, state: run.state };
      if (!graded(v)) {
        if (v.tags.some((t) => REPORT_TAGS.includes(t))) result.reportOnly.push(item);
        continue;
      }
      if (v.impact !== null && BLOCKING.has(v.impact)) {
        result.blocking.push(item);
        continue;
      }
      const entry = known.find((k) => k.rule === v.id && k.page === run.page);
      if (entry) {
        used.add(entry);
        result.listed.push(item);
      } else result.unlisted.push(item);
    }
  }
  result.stale = known.filter((k) => !used.has(k));
  result.ok = result.blocking.length === 0 && result.unlisted.length === 0;
  return result;
}
