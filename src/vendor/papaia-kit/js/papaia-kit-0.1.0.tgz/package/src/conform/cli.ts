// Command lines of pk-conform and pk-audit. Arguments are checked before a browser starts.
import { readFileSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";

import { KIT_VERSION } from "../index.ts";
import { evaluateAxe, parseKnownList } from "./a11y.ts";
import { platformDir, REFIMG_MODULES } from "./refimg.ts";
import { readJson, runAudit, runConform, runDesign, type Theme, type Viewports } from "./run.ts";

export const EXIT_OK = 0;
export const EXIT_FAIL = 1;
export const EXIT_USAGE = 2;
export const EXIT_INCOMPLETE = 3;

const DEFAULT_KIT_DIR = fileURLToPath(new URL("../../..", import.meta.url));

interface Contract {
  tools: { playwright: string; axe_core: string };
  viewports: Viewports;
}

class UsageError extends Error {}

/** Origin of the module under test: http(s), no credentials, no path beyond "/". */
export function checkBaseUrl(raw: string): string {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new UsageError("--base-url is not a URL");
  }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
    throw new UsageError("--base-url must be http(s)://host[:port] without credentials, query or fragment");
  }
  if (url.pathname !== "/") throw new UsageError("--base-url must not carry a path");
  return url.origin;
}

/** A page path of the module: absolute, no scheme-relative form, no dot segments. */
export function checkPath(raw: string): string {
  if (!/^\/(?!\/)[A-Za-z0-9._~\/%-]{0,200}$/.test(raw) || /(^|\/)\.\.?(\/|$)/.test(raw)) {
    throw new UsageError(`page path ${JSON.stringify(raw.slice(0, 40))} must be an absolute path of the module`);
  }
  return raw;
}

function themes(raw: string | undefined): Theme[] {
  const list = (raw ?? "light,dark").split(",");
  if (!list.length || list.some((t) => t !== "light" && t !== "dark") || new Set(list).size !== list.length) {
    throw new UsageError("--themes must be light, dark or light,dark");
  }
  return list as Theme[];
}

function lang(raw: string | undefined): "de" | "en" {
  if (raw !== undefined && raw !== "de" && raw !== "en") throw new UsageError("--lang must be de or en");
  return raw ?? "de";
}

// The kit version (K5 f, reference image set) is the version of this package, not a field of the
// expected files: a release cut then cannot leave them stale.
function contract(kitDir: string): Contract {
  const expected = readJson<Contract & { format: string }>(resolve(kitDir, "contract", "specimen-expected.light.json"));
  if (expected.format !== "papaia.specimen-expected/1") {
    throw new UsageError("contract/specimen-expected.light.json has the wrong format");
  }
  return expected;
}

function playwrightVersion(): string {
  const require = createRequire(import.meta.url);
  return readJson<{ version: string }>(require.resolve("playwright-core/package.json")).version;
}

async function launch(): Promise<import("playwright-core").Browser> {
  const { chromium } = await import("playwright-core");
  return chromium.launch();
}

function write(path: string | undefined, report: unknown): void {
  const text = JSON.stringify(report, null, 2) + "\n";
  if (path) writeFileSync(path, text, "utf-8");
  else process.stdout.write(text);
}

const CONFORM_HELP = `usage: pk-conform --base-url URL --module ID [--lang de|en] [--themes light,dark]
                  [--storage-state FILE] [--kit-dir DIR] [--images compare|skip] [--report FILE]
       pk-conform --design --base-url URL --page PATH [--page PATH ...] [--known a11y-known.yaml]
                  [--lang de|en] [--themes light,dark] [--storage-state FILE] [--kit-dir DIR] [--report FILE]
Checks /_kit/specimen of a running module against the kit (contract/specimen.md), or with
--design any page against the design rules (contract/design-review.md).
Exit: 0 pass, 1 deviation, 2 usage, 3 reference images not checked.`;

const MAX_PAGES = 200;

interface DesignArgs {
  "base-url"?: string | undefined;
  page?: string[] | undefined;
  known?: string | undefined;
  lang?: string | undefined;
  themes?: string | undefined;
  "storage-state"?: string | undefined;
  "kit-dir"?: string | undefined;
  report?: string | undefined;
  module?: string | undefined;
  images?: string | undefined;
}

/** pk-conform --design: the visual quality gate a module's CI calls for its pages. */
async function designMain(values: DesignArgs): Promise<number> {
  if (values.module !== undefined || values.images !== undefined) throw new UsageError("--design takes --page, not --module or --images");
  if (!values["base-url"] || !values.page?.length) throw new UsageError("--design needs --base-url and at least one --page");
  if (values.page.length > MAX_PAGES) throw new UsageError(`at most ${MAX_PAGES} pages`);
  const baseUrl = checkBaseUrl(values["base-url"]);
  const paths = values.page.map(checkPath);
  const language = lang(values.lang);
  const themeList = themes(values.themes);
  const known = values.known ? parseKnownList(readFileSync(values.known, "utf-8")) : [];
  const spec = contract(resolve(values["kit-dir"] ?? DEFAULT_KIT_DIR));
  const browser = await launch();
  try {
    const report = await runDesign({
      browser,
      baseUrl,
      paths,
      lang: language,
      themes: themeList,
      ...(values["storage-state"] ? { storageState: values["storage-state"] } : {}),
      axeVersion: spec.tools.axe_core,
      known,
    });
    write(values.report, report);
    for (const page of report.pages) {
      for (const f of page.findings) console.error(`${page.page} (${page.theme}, ${page.viewport}) ${f.check}: ${f.message}`);
    }
    for (const v of [...report.a11y.blocking, ...report.a11y.unlisted]) {
      console.error(`${v.impact ?? "?"} ${v.id} on ${v.page} (${v.theme}, ${v.state}), ${v.nodes} node(s)`);
    }
    return report.status === "pass" ? EXIT_OK : EXIT_FAIL;
  } finally {
    await browser.close();
  }
}

export async function conformMain(argv: string[]): Promise<number> {
  try {
    const { values } = parseArgs({
      args: argv,
      strict: true,
      options: {
        "base-url": { type: "string" },
        module: { type: "string" },
        lang: { type: "string" },
        themes: { type: "string" },
        "storage-state": { type: "string" },
        "kit-dir": { type: "string" },
        images: { type: "string" },
        report: { type: "string" },
        design: { type: "boolean" },
        page: { type: "string", multiple: true },
        known: { type: "string" },
        help: { type: "boolean" },
      },
    });
    if (values.help) {
      console.log(CONFORM_HELP);
      return EXIT_OK;
    }
    if (values.design) return await designMain(values);
    if (values.page !== undefined || values.known !== undefined) throw new UsageError("--page and --known belong to --design");
    if (!values["base-url"] || !values.module) throw new UsageError("--base-url and --module are required");
    if (!REFIMG_MODULES.includes(values.module)) throw new UsageError(`--module must be one of ${REFIMG_MODULES.join(", ")}`);
    const images = values.images ?? "compare";
    if (images !== "compare" && images !== "skip") throw new UsageError("--images must be compare or skip");
    const baseUrl = checkBaseUrl(values["base-url"]);
    const language = lang(values.lang);
    const themeList = themes(values.themes);
    const kitDir = resolve(values["kit-dir"] ?? DEFAULT_KIT_DIR);
    const spec = contract(kitDir);
    const version = playwrightVersion();
    if (version !== spec.tools.playwright) throw new UsageError(`playwright-core ${version}, the kit pins ${spec.tools.playwright}`);
    let platform: string | null;
    try {
      platform = platformDir(process.platform, process.arch);
    } catch {
      platform = null;
    }
    const browser = await launch();
    try {
      const report = await runConform({
        browser,
        baseUrl,
        kitDir,
        kitVersion: KIT_VERSION,
        module: values.module,
        lang: language,
        themes: themeList,
        ...(values["storage-state"] ? { storageState: values["storage-state"] } : {}),
        images,
        platform,
        playwrightVersion: version,
        viewports: spec.viewports,
      });
      write(values.report, report);
      return report.status === "pass" ? EXIT_OK : report.status === "fail" ? EXIT_FAIL : EXIT_INCOMPLETE;
    } finally {
      await browser.close();
    }
  } catch (error) {
    console.error(`pk-conform: ${error instanceof Error ? error.message : String(error)}`);
    return error instanceof UsageError || (error as { code?: string }).code?.startsWith("ERR_PARSE_ARGS") ? EXIT_USAGE : EXIT_FAIL;
  }
}

const AUDIT_HELP = `usage: pk-audit --base-url URL --page PATH [--page PATH ...] [--known a11y-known.yaml]
                [--lang de|en] [--themes light,dark] [--storage-state FILE] [--kit-dir DIR] [--report FILE]
Runs axe-core (WCAG 2.1 A/AA; 2.2 AA as report only) on every page, theme and state.
Exit: 0 no critical or serious violation and every other one listed, 1 otherwise, 2 usage.`;

export async function auditMain(argv: string[]): Promise<number> {
  try {
    const { values } = parseArgs({
      args: argv,
      strict: true,
      options: {
        "base-url": { type: "string" },
        page: { type: "string", multiple: true },
        known: { type: "string" },
        lang: { type: "string" },
        themes: { type: "string" },
        "storage-state": { type: "string" },
        "kit-dir": { type: "string" },
        report: { type: "string" },
        help: { type: "boolean" },
      },
    });
    if (values.help) {
      console.log(AUDIT_HELP);
      return EXIT_OK;
    }
    if (!values["base-url"] || !values.page?.length) throw new UsageError("--base-url and at least one --page are required");
    if (values.page.length > 200) throw new UsageError("at most 200 pages");
    const baseUrl = checkBaseUrl(values["base-url"]);
    const paths = values.page.map(checkPath);
    const language = lang(values.lang);
    const themeList = themes(values.themes);
    const known = values.known ? parseKnownList(readFileSync(values.known, "utf-8")) : [];
    const spec = contract(resolve(values["kit-dir"] ?? DEFAULT_KIT_DIR));
    const browser = await launch();
    try {
      const runs = await runAudit({
        browser,
        baseUrl,
        paths,
        lang: language,
        themes: themeList,
        ...(values["storage-state"] ? { storageState: values["storage-state"] } : {}),
        axeVersion: spec.tools.axe_core,
        viewport: spec.viewports.desktop,
      });
      const result = evaluateAxe(runs, known);
      write(values.report, { format: "papaia.pk-audit/1", axe_core: spec.tools.axe_core, ...result, runs });
      for (const v of [...result.blocking, ...result.unlisted]) {
        console.error(`${v.impact ?? "?"} ${v.id} on ${v.page} (${v.theme}, ${v.state}), ${v.nodes} node(s)`);
      }
      for (const e of result.stale) console.error(`stale entry in the known list: ${e.rule} on ${e.page}`);
      return result.ok ? EXIT_OK : EXIT_FAIL;
    } finally {
      await browser.close();
    }
  } catch (error) {
    console.error(`pk-audit: ${error instanceof Error ? error.message : String(error)}`);
    return error instanceof UsageError || error instanceof SyntaxError || (error as { code?: string }).code?.startsWith("ERR_PARSE_ARGS")
      ? EXIT_USAGE
      : EXIT_FAIL;
  }
}
