// Reference image comparison (K5 d, contract/specimen.md): a pixel differs when its colour
// distance in YIQ space exceeds the threshold 0.1 and it is not an anti-aliased edge pixel;
// an image matches when at most 0.5 % of its pixels differ.

export interface Image {
  width: number;
  height: number;
  /** RGBA, 8 bits per channel, row by row */
  data: Uint8Array;
}

export const THRESHOLD = 0.1;
export const MAX_DIFF_RATIO = 0.005;
// Largest possible YIQ distance (black against white) with the weights below.
const MAX_DELTA = 35215;

export interface DiffResult {
  differing: number;
  total: number;
  ratio: number;
  sizeMismatch: boolean;
}

export interface CompareResult extends DiffResult {
  ok: boolean;
}

function rgbAt(img: Image, index: number): [number, number, number] {
  const o = index * 4;
  const alpha = img.data[o + 3]! / 255;
  // Blend with white so that transparent pixels compare as what a page shows behind them.
  const blend = (c: number): number => 255 + (c - 255) * alpha;
  return [blend(img.data[o]!), blend(img.data[o + 1]!), blend(img.data[o + 2]!)];
}

function luma([r, g, b]: [number, number, number]): number {
  return r * 0.29889531 + g * 0.58662247 + b * 0.11448223;
}

/** Perceived colour distance in YIQ space (weights after Kotsarenko and Ramos). */
export function yiqDelta(a: [number, number, number], b: [number, number, number]): number {
  const dy = luma(a) - luma(b);
  const di = a[0] * 0.59597799 - a[1] * 0.2741761 - a[2] * 0.32180189 - (b[0] * 0.59597799 - b[1] * 0.2741761 - b[2] * 0.32180189);
  const dq = a[0] * 0.21147017 - a[1] * 0.52261711 + a[2] * 0.31114694 - (b[0] * 0.21147017 - b[1] * 0.52261711 + b[2] * 0.31114694);
  return 0.5053 * dy * dy + 0.299 * di * di + 0.1957 * dq * dq;
}

function samePixel(img: Image, i: number, j: number): boolean {
  const a = i * 4;
  const b = j * 4;
  return img.data[a] === img.data[b] && img.data[a + 1] === img.data[b + 1] && img.data[a + 2] === img.data[b + 2] && img.data[a + 3] === img.data[b + 3];
}

function neighbours(img: Image, x: number, y: number): number[] {
  const out: number[] = [];
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      const nx = x + dx;
      const ny = y + dy;
      if ((dx || dy) && nx >= 0 && ny >= 0 && nx < img.width && ny < img.height) out.push(ny * img.width + nx);
    }
  }
  return out;
}

function flat(img: Image, index: number): boolean {
  const x = index % img.width;
  const y = Math.floor(index / img.width);
  return neighbours(img, x, y).filter((n) => samePixel(img, index, n)).length >= 3;
}

// An edge pixel of anti-aliasing lies between a darker and a brighter neighbour, has at most
// two neighbours of its own colour, and its darkest and brightest neighbours sit in flat areas
// of both images (a smoothed edge, not a changed shape).
function antiAliased(img: Image, other: Image, x: number, y: number): boolean {
  const index = y * img.width + x;
  const own = luma(rgbAt(img, index));
  let equal = 0;
  let darkest = -1;
  let brightest = -1;
  let low = 0;
  let high = 0;
  for (const n of neighbours(img, x, y)) {
    if (samePixel(img, index, n)) {
      equal++;
      continue;
    }
    const delta = luma(rgbAt(img, n)) - own;
    if (delta < low) {
      low = delta;
      darkest = n;
    } else if (delta > high) {
      high = delta;
      brightest = n;
    }
  }
  if (equal > 2 || darkest < 0 || brightest < 0) return false;
  return (flat(img, darkest) && flat(other, darkest)) || (flat(img, brightest) && flat(other, brightest));
}

/** Count the differing pixels of two images of the same size. */
export function diffImages(actual: Image, expected: Image, threshold = THRESHOLD): DiffResult {
  const total = expected.width * expected.height;
  if (actual.width !== expected.width || actual.height !== expected.height) {
    return { differing: total, total, ratio: 1, sizeMismatch: true };
  }
  const limit = MAX_DELTA * threshold * threshold;
  let differing = 0;
  for (let y = 0; y < expected.height; y++) {
    for (let x = 0; x < expected.width; x++) {
      const index = y * expected.width + x;
      if (yiqDelta(rgbAt(actual, index), rgbAt(expected, index)) <= limit) continue;
      if (antiAliased(actual, expected, x, y) || antiAliased(expected, actual, x, y)) continue;
      differing++;
    }
  }
  return { differing, total, ratio: differing / total, sizeMismatch: false };
}

/** Compare a screenshot with its reference image: at most 0.5 % differing pixels. */
export function compareImages(actual: Image, expected: Image): CompareResult {
  const result = diffImages(actual, expected);
  return { ...result, ok: !result.sizeMismatch && result.ratio <= MAX_DIFF_RATIO };
}
