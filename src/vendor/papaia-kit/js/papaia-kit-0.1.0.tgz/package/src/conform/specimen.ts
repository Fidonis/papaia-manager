// Comparison rule of the specimen page (contract/specimen.md): what the browser reports is
// normalised before it is compared with contract/specimen-expected.<theme>.json, which the
// Python side writes with the same rule from the token file.

export const COLOR_PROPS: ReadonlySet<string> = new Set([
  "background-color",
  "color",
  "border-top-color",
  "outline-color",
]);
export const LENGTH_PROPS: ReadonlySet<string> = new Set([
  "font-size",
  "line-height",
  "border-top-left-radius",
  "padding-top",
  "padding-left",
  "outline-width",
  "outline-offset",
]);
export const READ_PROPS: readonly string[] = [
  ...COLOR_PROPS,
  ...LENGTH_PROPS,
  "font-family",
  "font-weight",
  "outline-style",
  "opacity",
];

const ROOT_FONT_PX = 16;
const MAX_VALUE = 256;

export interface SpecimenExpected {
  format: "papaia.specimen-expected/1";
  theme: "light" | "dark";
  tools: { playwright: string; axe_core: string };
  viewports: { desktop: { width: number; height: number }; narrow: { width: number; height: number } };
  states: Record<string, "rest" | "hover" | "focus" | "disabled" | "invalid">;
  selectors: Record<string, string>;
  elements: Record<string, Record<string, string>>;
  tokens: Record<string, string>;
}

export interface ObservedSpecimen {
  /** Computed styles per element; null when the page has no such element. */
  elements: Record<string, Record<string, string> | null>;
  /** Computed values of the custom properties on :root. */
  tokens: Record<string, string>;
}

export interface Deviation {
  kind: "style" | "token" | "missing" | "unknown";
  name: string;
  property?: string;
  expected?: string;
  actual?: string;
}

function number(value: number): string {
  return Number.isInteger(value) ? String(value) : String(Number(value.toFixed(2)));
}

function clampByte(value: number): number {
  return Math.min(255, Math.max(0, Math.round(value)));
}

function rgba(r: number, g: number, b: number, alpha: number): string {
  const a = Math.round(Math.min(1, Math.max(0, alpha)) * 100) / 100;
  return `rgba(${clampByte(r)},${clampByte(g)},${clampByte(b)},${number(a)})`;
}

function part(raw: string, scale: number): number {
  const text = raw.trim();
  if (text === "none") return 0;
  const value = text.endsWith("%") ? (Number.parseFloat(text) / 100) * scale : Number.parseFloat(text);
  if (!Number.isFinite(value)) throw new RangeError("not a number");
  return value;
}

function alphaOf(raw: string | undefined): number {
  return raw === undefined ? 1 : part(raw, 1);
}

function gamma(linear: number): number {
  const x = Math.min(1, Math.max(0, linear));
  return x <= 0.0031308 ? 12.92 * x : 1.055 * x ** (1 / 2.4) - 0.055;
}

// OKLab to sRGB with the matrices of CSS Color Module Level 4.
function oklabToRgb(l: number, a: number, b: number): [number, number, number] {
  const l1 = (l + 0.3963377774 * a + 0.2158037573 * b) ** 3;
  const m1 = (l - 0.1055613458 * a - 0.0638541728 * b) ** 3;
  const s1 = (l - 0.0894841775 * a - 1.291485548 * b) ** 3;
  return [
    gamma(4.0767416621 * l1 - 3.3077115913 * m1 + 0.2309699292 * s1) * 255,
    gamma(-1.2684380046 * l1 + 2.6097574011 * m1 - 0.3413193965 * s1) * 255,
    gamma(-0.0041960863 * l1 - 0.7034186147 * m1 + 1.707614701 * s1) * 255,
  ];
}

function splitArgs(inner: string): { parts: string[]; alpha: string | undefined } {
  const [main = "", alpha] = inner.split("/");
  const legacy = main.includes(",");
  const parts = legacy ? main.split(",") : main.trim().split(/\s+/);
  if (legacy && alpha === undefined && parts.length === 4) return { parts: parts.slice(0, 3), alpha: parts[3] };
  return { parts, alpha };
}

/** `rgba(r,g,b,a)` with 8 bits per channel and alpha in two decimals, or null. */
export function normalizeColor(raw: string): string | null {
  const text = raw.trim().toLowerCase();
  if (text.length > MAX_VALUE) return null;
  if (text === "transparent") return "rgba(0,0,0,0)";
  const hex = /^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/.exec(text);
  if (hex) {
    let digits = hex[1]!;
    if (digits.length <= 4) digits = [...digits].map((c) => c + c).join("");
    const byte = (i: number): number => Number.parseInt(digits.slice(i, i + 2), 16);
    return rgba(byte(0), byte(2), byte(4), digits.length === 8 ? byte(6) / 255 : 1);
  }
  const fn = /^(rgba?|oklch|oklab|color)\((.*)\)$/.exec(text);
  if (!fn) return null;
  try {
    const [, name, inner = ""] = fn;
    if (name === "color") {
      const { parts, alpha } = splitArgs(inner);
      if (parts[0] !== "srgb" || parts.length !== 4) return null;
      const [r, g, b] = parts.slice(1).map((p) => part(p, 1) * 255) as [number, number, number];
      return rgba(r, g, b, alphaOf(alpha));
    }
    const { parts, alpha } = splitArgs(inner);
    if (parts.length !== 3) return null;
    if (name === "rgb" || name === "rgba") {
      const [r, g, b] = parts.map((p) => part(p, 255)) as [number, number, number];
      return rgba(r, g, b, alphaOf(alpha));
    }
    const l = part(parts[0]!, 1);
    if (name === "oklab") {
      const [r, g, b] = oklabToRgb(l, part(parts[1]!, 0.4), part(parts[2]!, 0.4));
      return rgba(r, g, b, alphaOf(alpha));
    }
    const chroma = part(parts[1]!, 0.4);
    const hue = (part(parts[2]!.replace(/deg$/, ""), 1) * Math.PI) / 180;
    const [r, g, b] = oklabToRgb(l, chroma * Math.cos(hue), chroma * Math.sin(hue));
    return rgba(r, g, b, alphaOf(alpha));
  } catch {
    return null;
  }
}

function roundHalf(value: number): string {
  return number(Math.floor(value * 2 + 0.5) / 2);
}

export function normalizeLength(raw: string): string | null {
  const m = /^(-?\d+(?:\.\d+)?)(px|rem)$/.exec(raw.trim());
  if (!m) return null;
  const value = Number.parseFloat(m[1]!) * (m[2] === "rem" ? ROOT_FONT_PX : 1);
  return `${roundHalf(value)}px`;
}

export function firstFamily(raw: string): string {
  return (raw.split(",", 1)[0] ?? "").trim().replace(/^["']|["']$/g, "").toLowerCase();
}

const WEIGHTS: Record<string, string> = { normal: "400", bold: "700" };

/** Normalise one computed value of a read property with the comparison rule. */
export function normalizeValue(prop: string, raw: string): string {
  const text = raw.trim();
  if (COLOR_PROPS.has(prop)) return normalizeColor(text) ?? text;
  if (LENGTH_PROPS.has(prop)) return normalizeLength(text) ?? text;
  if (prop === "font-family") return firstFamily(text);
  if (prop === "font-weight") return WEIGHTS[text] ?? String(Math.round(Number.parseFloat(text)));
  if (prop === "opacity") return number(Math.round(Number.parseFloat(text) * 100) / 100);
  return text;
}

/** Normalise a custom property value of :root the way the Python side writes it. */
export function normalizeToken(name: string, raw: string): string {
  const text = raw.trim().split(/\s+/).join(" ");
  if (name.startsWith("--pk-font-")) return firstFamily(text);
  return normalizeColor(text) ?? normalizeLength(text) ?? text;
}

function channels(value: string): number[] | null {
  const m = /^rgba\((\d+),(\d+),(\d+),([\d.]+)\)$/.exec(value);
  return m ? m.slice(1).map(Number) : null;
}

function sameColor(expected: string, actual: string): boolean {
  const a = channels(expected);
  const b = channels(actual);
  if (!a || !b) return expected === actual;
  return a[3] === b[3] && [0, 1, 2].every((i) => Math.abs(a[i]! - b[i]!) <= 1);
}

/** Expected (normalised) and observed (raw) value are equal under the comparison rule. */
export function sameValue(prop: string, expected: string, observed: string): boolean {
  const actual = normalizeValue(prop, observed);
  return COLOR_PROPS.has(prop) ? sameColor(expected, actual) : expected === actual;
}

/** Every deviation of an observed specimen page from the expected values of one theme. */
export function compareSpecimen(expected: SpecimenExpected, observed: ObservedSpecimen): Deviation[] {
  const found: Deviation[] = [];
  for (const [name, props] of Object.entries(expected.elements)) {
    const seen = observed.elements[name];
    if (!seen) {
      found.push({ kind: "missing", name });
      continue;
    }
    for (const [property, value] of Object.entries(props)) {
      const raw = seen[property] ?? "";
      if (!sameValue(property, value, raw)) {
        found.push({ kind: "style", name, property, expected: value, actual: normalizeValue(property, raw) });
      }
    }
  }
  for (const name of Object.keys(observed.elements)) {
    if (!(name in expected.elements)) found.push({ kind: "unknown", name });
  }
  for (const [name, value] of Object.entries(expected.tokens)) {
    const raw = observed.tokens[name];
    const actual = raw === undefined ? "" : normalizeToken(name, raw);
    const equal = value.startsWith("rgba(") ? sameColor(value, actual) : value === actual;
    if (!equal) found.push({ kind: "token", name, expected: value, actual });
  }
  return found;
}
