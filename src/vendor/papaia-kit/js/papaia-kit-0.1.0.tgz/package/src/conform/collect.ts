// Functions that run inside the page (page.evaluate). Each is self-contained: Playwright
// sends its source text to the browser, so nothing from module scope is visible there.
import type { LandmarkSnapshot } from "./landmarks.ts";

export interface StyleRequest {
  selectors: Record<string, string>;
  props: readonly string[];
}

/** Computed styles of the named elements; null for a selector without match. */
export function collectStyles(req: StyleRequest): Record<string, Record<string, string> | null> {
  const out: Record<string, Record<string, string> | null> = {};
  for (const [name, selector] of Object.entries(req.selectors)) {
    const el = document.querySelector(selector);
    if (!el) {
      out[name] = null;
      continue;
    }
    const style = getComputedStyle(el);
    out[name] = Object.fromEntries(req.props.map((p) => [p, style.getPropertyValue(p)]));
  }
  for (const el of document.querySelectorAll("[data-pk-specimen]")) {
    const name = el.getAttribute("data-pk-specimen") ?? "";
    if (!(name in out)) out[name] = {};
  }
  return out;
}

/** Wait until every running transition and finite animation of the document has ended
 * (an endless one, such as a turning loading symbol, never ends and is not waited for). */
export async function settle(): Promise<void> {
  await document.fonts.ready;
  const finite = document.getAnimations().filter((a) => a.effect?.getTiming().iterations !== Infinity);
  await Promise.all(finite.map((a) => a.finished.catch(() => undefined)));
}

/** Computed values of custom properties on :root. */
export function collectTokens(names: string[]): Record<string, string> {
  const style = getComputedStyle(document.documentElement);
  return Object.fromEntries(names.map((n) => [n, style.getPropertyValue(n)]));
}

/** Structure of the page for the landmark checks. */
export function collectLandmarks(): LandmarkSnapshot {
  const visible = (el: Element): boolean => {
    const s = getComputedStyle(el);
    return s.display !== "none" && s.visibility !== "hidden" && !el.closest("[hidden], dialog:not([open])");
  };
  const focusable = [
    ...document.querySelectorAll<HTMLElement>(
      'a[href], button, input, select, textarea, summary, [tabindex]:not([tabindex="-1"])',
    ),
  ].filter((el) => !(el as HTMLButtonElement).disabled && el.tabIndex >= 0);
  const first = focusable[0];
  const nameOf = (el: Element): string => {
    const label = el.getAttribute("aria-label");
    if (label) return label;
    const ids = (el.getAttribute("aria-labelledby") ?? "").split(/\s+/).filter(Boolean);
    return ids.map((id) => document.getElementById(id)?.textContent ?? "").join(" ").trim();
  };
  const rect = (selector: string): DOMRect | null => document.querySelector(selector)?.getBoundingClientRect() ?? null;
  const sidebar = rect(".pk-sidebar");
  const wide = window.innerWidth >= 1024;
  const zoneLeft: Record<string, number> = {};
  for (const zone of ["brand", "switcher", "footer"]) {
    const r = rect(`[data-pk-zone="${zone}"]`);
    if (r) zoneLeft[zone] = r.left;
  }
  return {
    lang: document.documentElement.lang,
    title: document.title,
    kitMeta: document.querySelector('meta[name="papaia-kit"]')?.getAttribute("content") ?? null,
    firstFocusable: first
      ? { tag: first.tagName.toLowerCase(), className: first.className, href: first.getAttribute("href") }
      : null,
    mains: document.querySelectorAll('main, [role="main"]').length,
    navs: [...document.querySelectorAll('nav, [role="navigation"]')].map((n) => ({ name: nameOf(n) })),
    headings: [...document.querySelectorAll("h1, h2, h3, h4, h5, h6")]
      .filter(visible)
      .map((h) => Number(h.tagName.slice(1))),
    zones: [...document.querySelectorAll("[data-pk-zone]")].map((z) => z.getAttribute("data-pk-zone") ?? ""),
    sidebarWidth: wide && sidebar ? sidebar.width : null,
    zoneLeft: wide ? zoneLeft : {},
    primaryInHeader: document.querySelectorAll('[data-pk-zone="page-header"] [data-pk-variant="primary"]').length,
  };
}

/** Width of the document against the viewport (reflow, 1.4.10). */
export function collectReflow(): { scrollWidth: number; innerWidth: number } {
  return { scrollWidth: document.documentElement.scrollWidth, innerWidth: window.innerWidth };
}

/** Snapshot of a page for the design checks (design.ts). Self-contained like every collector. */
export function collectDesign(): import("./design.ts").DesignSnapshot {
  const INTERACTIVE = 'a[href], button, input:not([type="hidden"]), select, textarea, summary, [tabindex]:not([tabindex="-1"])';
  const PER_FAMILY = 20;
  const main = document.getElementById("pk-main");
  const shown = (el: Element): boolean => {
    const style = getComputedStyle(el);
    const box = el.getBoundingClientRect();
    return (
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      box.width > 0 &&
      box.height > 0 &&
      !el.closest("[hidden], dialog:not([open]), details:not([open]) > :not(summary)")
    );
  };
  const names = new Map<Element, string>();
  const describe = (el: Element): string => {
    let name = names.get(el);
    if (name === undefined) {
      const label = (el.getAttribute("aria-label") ?? el.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 40);
      const cls = el.classList[0] ? `.${el.classList[0]}` : "";
      name = `${el.tagName.toLowerCase()}${cls}#${names.size + 1}${label ? ` "${label}"` : ""}`;
      names.set(el, name);
    }
    return name;
  };
  const firstFamily = (raw: string): string => (raw.split(",", 1)[0] ?? "").trim().replace(/^["']|["']$/g, "").toLowerCase();
  const root = getComputedStyle(document.documentElement);
  const kitFonts = ["--pk-font-body", "--pk-font-brand", "--pk-font-mono"].map((n) => firstFamily(root.getPropertyValue(n))).filter(Boolean);

  // Text: every element with a text node of its own, at most PER_FAMILY places per family.
  const texts: { where: string; family: string }[] = [];
  const perFamily = new Map<string, number>();
  for (const el of document.body.querySelectorAll("*")) {
    if (el.closest("svg, script, style, template, noscript") || !shown(el)) continue;
    const own = [...el.childNodes].some((n) => n.nodeType === Node.TEXT_NODE && (n.textContent ?? "").trim() !== "");
    if (!own) continue;
    const family = firstFamily(getComputedStyle(el).fontFamily);
    const seen = perFamily.get(family) ?? 0;
    if (seen >= PER_FAMILY) continue;
    perFamily.set(family, seen + 1);
    texts.push({ where: describe(el), family });
  }

  // Vertical gaps between block siblings stacked on top of each other inside #pk-main.
  const gaps: { where: string; gap: number }[] = [];
  const inFlow = (el: Element): boolean => {
    const style = getComputedStyle(el);
    return (
      shown(el) &&
      !["absolute", "fixed"].includes(style.position) &&
      !style.display.startsWith("inline") &&
      !style.display.startsWith("table") &&
      style.display !== "contents" &&
      !el.classList.contains("pk-sr-only")
    );
  };
  // Only block flow and column flex boxes stack their children by margin or gap; in a grid or a
  // row of flex items the offsets come from alignment, not from spacing.
  for (const parent of main ? [main, ...main.querySelectorAll("*")] : []) {
    const box = getComputedStyle(parent);
    const flow =
      ["block", "flow-root", "list-item"].includes(box.display) ||
      (box.display.endsWith("flex") && box.flexDirection.startsWith("column"));
    if (parent.closest("svg") || !flow) continue;
    const children = [...parent.children].filter(inFlow);
    for (let i = 1; i < children.length; i++) {
      const a = children[i - 1]!.getBoundingClientRect();
      const b = children[i]!.getBoundingClientRect();
      const stacked = b.top >= a.bottom - 0.5 && b.left < a.right && b.right > a.left;
      if (stacked) gaps.push({ where: `${describe(children[i - 1]!)} + ${describe(children[i]!)}`, gap: b.top - a.bottom });
    }
  }

  // Interactive elements in #pk-main. A checkbox or radio inside its label is measured with
  // the label; links inside running text are exempt (WCAG 2.5.8, inline targets); the items
  // of one open menu panel form one control and are not measured against each other.
  const targets: import("./design.ts").Box[] = [];
  const candidates = main ? [...main.querySelectorAll(INTERACTIVE)].filter(shown) : [];
  for (const el of candidates) {
    const style = getComputedStyle(el);
    if (el.tagName === "A" && !el.classList.contains("pk-btn") && style.display === "inline") continue;
    const choice = el instanceof HTMLInputElement && (el.type === "checkbox" || el.type === "radio");
    const label = choice ? el.closest("label") : null;
    const box = (label ?? el).getBoundingClientRect();
    const outer = el.parentElement?.closest(INTERACTIVE);
    const panel = el.closest(".pk-menu-panel, [role='menu']");
    targets.push({
      where: describe(el),
      left: box.left,
      top: box.top,
      right: box.right,
      bottom: box.bottom,
      ...(outer && candidates.includes(outer) ? { inside: describe(outer) } : {}),
      ...(panel ? { group: describe(panel) } : {}),
    });
  }

  // Paragraphs: widest line in characters of the paragraph's own font ("0", the ch unit).
  const paragraphs: { where: string; chars: number }[] = [];
  const canvas = document.createElement("canvas").getContext("2d");
  for (const p of main ? main.querySelectorAll("p") : []) {
    if (!shown(p) || !canvas) continue;
    const style = getComputedStyle(p);
    canvas.font = `${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
    const ch = canvas.measureText("0").width;
    const range = document.createRange();
    range.selectNodeContents(p);
    const lines = new Map<number, { left: number; right: number }>();
    for (const r of range.getClientRects()) {
      if (r.width === 0) continue;
      const key = Math.round(r.top);
      const line = lines.get(key);
      lines.set(key, line ? { left: Math.min(line.left, r.left), right: Math.max(line.right, r.right) } : { left: r.left, right: r.right });
    }
    const widest = Math.max(0, ...[...lines.values()].map((l) => l.right - l.left));
    if (ch > 0 && widest > 0) paragraphs.push({ where: describe(p), chars: widest / ch });
  }

  // Text boxes in #pk-main: every element with a text node of its own, its width, the width of
  // its parent and the number of lines its text runs over. Visually hidden texts (clipped to
  // 1 px for screen readers) are not drawn and not measured. Table cells share the width of
  // their table by content (and the table scrolls on its own): their wrapping is the table's
  // layout, not a squeezed column of a page.
  const textBoxes: { where: string; width: number; parentWidth: number; lines: number }[] = [];
  for (const el of main ? main.querySelectorAll("*") : []) {
    if (el.closest("svg, script, style, template, .pk-sr-only, td, th, caption") || !shown(el)) continue;
    const own = [...el.childNodes].filter((n) => n.nodeType === Node.TEXT_NODE && (n.textContent ?? "").trim() !== "");
    if (own.length === 0) continue;
    const style = getComputedStyle(el);
    if (style.display.startsWith("inline") && style.display !== "inline-block" && style.display !== "inline-flex") continue;
    const box = el.getBoundingClientRect();
    if (box.width <= 2 || (style.clipPath !== "none" && style.clipPath !== "")) continue;
    const parent = el.parentElement;
    const tops = new Set<number>();
    for (const node of own) {
      const range = document.createRange();
      range.selectNodeContents(node);
      for (const r of range.getClientRects()) if (r.width > 0) tops.add(Math.round(r.top));
    }
    textBoxes.push({
      where: describe(el),
      width: box.width,
      parentWidth: parent ? parent.getBoundingClientRect().width : box.width,
      lines: tops.size,
    });
  }

  // Outlines on elements without focus: a focus ring is drawn on focus only.
  const outlines: { where: string; style: string; width: number }[] = [];
  const focused = document.activeElement;
  for (const el of document.body.querySelectorAll("*")) {
    if (el.closest("svg") || el === focused || !shown(el)) continue;
    const style = getComputedStyle(el);
    const width = parseFloat(style.outlineWidth) || 0;
    if (style.outlineStyle !== "none" && width > 0) outlines.push({ where: describe(el), style: style.outlineStyle, width });
  }

  // Appearance switches anywhere on the page: the shell's footer button and every button or
  // link of a console whose label names a light or dark mode, theme or design. Controls that
  // carry their state (aria-pressed, aria-checked, a switch or checkbox role) are settings,
  // not actions, and are left out. The shown appearance is data-theme (or a light/dark class
  // on the root), otherwise prefers-color-scheme.
  const MODE_WORDS = /(?<![\p{L}])(modus|mode|theme|design|darstellung|ansicht|erscheinungsbild|appearance)(?![\p{L}])/iu;
  const rootEl = document.documentElement;
  const theme = rootEl.getAttribute("data-theme");
  const shownAppearance: "light" | "dark" =
    theme === "light" || theme === "dark"
      ? theme
      : rootEl.classList.contains("dark")
        ? "dark"
        : rootEl.classList.contains("light")
          ? "light"
          : matchMedia("(prefers-color-scheme: dark)").matches
            ? "dark"
            : "light";
  const appearanceSwitches: import("./design.ts").AppearanceSwitch[] = [];
  for (const el of document.body.querySelectorAll('button, a[href], summary, [role="button"], [role="menuitem"]')) {
    if (el.closest("template") || el.hasAttribute("aria-pressed") || el.hasAttribute("aria-checked")) continue;
    if (["switch", "checkbox", "menuitemcheckbox", "menuitemradio", "radio"].includes(el.getAttribute("role") ?? "")) continue;
    const label = (el.getAttribute("aria-label") ?? el.textContent ?? "").replace(/\s+/g, " ").trim();
    const shell = el.matches('button[name="appearance"]');
    if (!label || (!shell && !MODE_WORDS.test(label))) continue;
    appearanceSwitches.push({ where: describe(el), label, shown: shownAppearance });
  }

  return {
    kitFonts,
    texts,
    gaps,
    targets,
    primaryInHeader: document.querySelectorAll('[data-pk-zone="page-header"] [data-pk-variant="primary"]').length,
    paragraphs,
    textBoxes,
    outlines,
    appearanceSwitches,
  };
}
