// Layout of the reference images (contract/specimen.md, Ä-33): one set per kit version (the kit
// release that carries them), Playwright version, platform and module, made only in a kit
// release with the test branding of contract/shell/inputs/branding/.

export interface Shot {
  /** file name stem without theme */
  name: string;
  /** selector of the zone that is photographed */
  zone: string;
  /** selector of a details element that is opened first, if any */
  open?: string;
}

export const REFIMG_SHOTS: readonly Shot[] = [
  { name: "brand-rest", zone: '[data-pk-zone="brand"]' },
  { name: "switcher-closed", zone: '[data-pk-zone="switcher"]' },
  { name: "switcher-open", zone: '[data-pk-zone="switcher"]', open: '[data-pk-zone="switcher"]' },
  { name: "footer-rest", zone: '[data-pk-zone="footer"]' },
  { name: "account-open", zone: '[data-pk-zone="footer"]', open: '[data-pk-zone="footer"] details.pk-account' },
];

/** Selector of the current module's name, masked in every shot. */
export const MASK = '[data-pk-zone="switcher"] summary .pk-label, [data-pk-zone="switcher"] [aria-current="page"]';

export const REFIMG_MODULES: readonly string[] = ["studio", "data", "flow", "assistant", "me", "manager"];

const VERSION = /^\d{1,4}\.\d{1,4}\.\d{1,4}$/;
const PLATFORM = /^linux-(arm64|amd64)$/;

export interface RefimgKey {
  playwright: string;
  platform: string;
  module: string;
  shot: string;
  theme: "light" | "dark";
}

/** Platform directory for the running process (only the pinned Linux containers). */
export function platformDir(platform: string, arch: string): string {
  const name = `${platform}-${arch === "x64" ? "amd64" : arch}`;
  if (!PLATFORM.test(name)) throw new RangeError(`platform ${name}: reference images exist only for linux-arm64 and linux-amd64`);
  return name;
}

/** Path of one reference image relative to the kit root. */
export function refimgPath(key: RefimgKey): string {
  if (!VERSION.test(key.playwright)) throw new RangeError("playwright version must be x.y.z");
  if (!PLATFORM.test(key.platform)) throw new RangeError("platform must be linux-arm64 or linux-amd64");
  if (!REFIMG_MODULES.includes(key.module)) throw new RangeError(`module must be one of ${REFIMG_MODULES.join(", ")}`);
  if (!REFIMG_SHOTS.some((s) => s.name === key.shot)) throw new RangeError(`unknown shot ${key.shot}`);
  if (key.theme !== "light" && key.theme !== "dark") throw new RangeError("theme must be light or dark");
  return `refimg/${key.playwright}/${key.platform}/${key.module}/${key.shot}-${key.theme}.png`;
}

/** Widths of the reference images of whole pages (Ä-33) and of the design checks; reflow at 320 px. */
export const DESIGN_VIEWPORTS = {
  desktop: { width: 1440, height: 900 },
  phone: { width: 390, height: 844 },
  reflow: { width: 320, height: 640 },
} as const;

/** Viewports of the whole-page reference images. */
export const PAGE_SHOT_VIEWPORTS = { desktop: DESIGN_VIEWPORTS.desktop, phone: DESIGN_VIEWPORTS.phone } as const;
export type PageShotViewport = keyof typeof PAGE_SHOT_VIEWPORTS;

/** Whole pages photographed in German: the specimen and the composed reference pages. */
export const PAGE_SHOTS: readonly string[] = ["specimen", "overview", "settings", "list", "state", "data"];

export interface PageShotKey {
  playwright: string;
  platform: string;
  page: string;
  viewport: PageShotViewport;
  theme: "light" | "dark";
}

/** Path of one whole-page reference image relative to the kit root. */
export function pageShotPath(key: PageShotKey): string {
  if (!VERSION.test(key.playwright)) throw new RangeError("playwright version must be x.y.z");
  if (!PLATFORM.test(key.platform)) throw new RangeError("platform must be linux-arm64 or linux-amd64");
  if (!PAGE_SHOTS.includes(key.page)) throw new RangeError(`page must be one of ${PAGE_SHOTS.join(", ")}`);
  if (!(key.viewport in PAGE_SHOT_VIEWPORTS)) throw new RangeError("viewport must be desktop or phone");
  if (key.theme !== "light" && key.theme !== "dark") throw new RangeError("theme must be light or dark");
  return `refimg/${key.playwright}/${key.platform}/pages/${key.page}-${key.viewport}-${key.theme}.png`;
}
