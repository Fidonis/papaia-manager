// Base layer check (contract/base.md): computed styles of the fixture page against
// contract/base-expected.<theme>.json, with the comparison rule of the specimen page extended
// by the properties the base layer sets. The Python side (papaia_kit.ui.base) writes the
// expected values with the same rule.
import { readFileSync } from "node:fs";
import { join } from "node:path";

import { normalizeColor, normalizeLength, firstFamily } from "./specimen.ts";

export const BASE_COLOR_PROPS: ReadonlySet<string> = new Set([
  "background-color",
  "color",
  "border-top-color",
  "border-left-color",
  "text-decoration-color",
  "accent-color",
]);
export const BASE_LENGTH_PROPS: ReadonlySet<string> = new Set([
  "font-size",
  "line-height",
  "margin-top",
  "margin-bottom",
  "margin-left",
  "padding-top",
  "padding-left",
  "border-top-width",
  "border-left-width",
  "border-top-left-radius",
  "height",
  "width",
  "max-width",
  "text-underline-offset",
  "text-decoration-thickness",
]);
export const BASE_KEYWORD_PROPS: ReadonlySet<string> = new Set([
  "border-top-style",
  "border-left-style",
  "display",
  "box-sizing",
  "list-style-type",
  "text-decoration-line",
]);
export const BASE_READ_PROPS: readonly string[] = [
  ...BASE_COLOR_PROPS,
  ...BASE_LENGTH_PROPS,
  ...BASE_KEYWORD_PROPS,
  "font-family",
  "font-weight",
  "opacity",
];

export type BaseState = "rest" | "hover" | "active" | "disabled";

export interface BaseExpected {
  format: "papaia.base-expected/1";
  theme: "light" | "dark";
  viewports: { desktop: { width: number; height: number }; narrow: { width: number; height: number } };
  states: Record<string, BaseState>;
  selectors: Record<string, string>;
  not_default: Record<string, string[]>;
  elements: Record<string, Record<string, string>>;
}

export interface BaseDeviation {
  kind: "style" | "missing" | "default";
  name: string;
  property?: string;
  expected?: string;
  actual?: string;
}

export function loadBaseExpected(kitDir: string, theme: "light" | "dark"): BaseExpected {
  const expected = JSON.parse(readFileSync(join(kitDir, "contract", `base-expected.${theme}.json`), "utf-8")) as BaseExpected;
  if (expected.format !== "papaia.base-expected/1" || expected.theme !== theme) {
    throw new Error(`base-expected.${theme}.json has the wrong format or theme`);
  }
  return expected;
}

function number(value: number): string {
  return Number.isInteger(value) ? String(value) : String(Number(value.toFixed(2)));
}

const WEIGHTS: Record<string, string> = { normal: "400", bold: "700" };

/** Normalise one computed value of a base property with the comparison rule. */
export function normalizeBaseValue(prop: string, raw: string): string {
  const text = raw.trim();
  if (BASE_COLOR_PROPS.has(prop)) return normalizeColor(text) ?? text;
  if (BASE_LENGTH_PROPS.has(prop)) return normalizeLength(text) ?? text;
  if (prop === "font-family") return firstFamily(text);
  if (prop === "font-weight") return WEIGHTS[text] ?? String(Math.round(Number.parseFloat(text)));
  if (prop === "opacity") return number(Math.round(Number.parseFloat(text) * 100) / 100);
  return text;
}

function sameColor(expected: string, actual: string): boolean {
  const parse = (v: string): number[] | null => {
    const m = /^rgba\((\d+),(\d+),(\d+),([\d.]+)\)$/.exec(v);
    return m ? m.slice(1).map(Number) : null;
  };
  const a = parse(expected);
  const b = parse(actual);
  if (!a || !b) return expected === actual;
  return a[3] === b[3] && [0, 1, 2].every((i) => Math.abs(a[i]! - b[i]!) <= 1);
}

/** Every deviation of observed computed styles (raw) from the expected values of one theme. */
export function compareBase(
  expected: BaseExpected,
  observed: Record<string, Record<string, string> | null>,
): BaseDeviation[] {
  const found: BaseDeviation[] = [];
  for (const [name, props] of Object.entries(expected.elements)) {
    const seen = observed[name];
    if (!seen) {
      found.push({ kind: "missing", name });
      continue;
    }
    for (const [property, value] of Object.entries(props)) {
      const actual = normalizeBaseValue(property, seen[property] ?? "");
      const equal = BASE_COLOR_PROPS.has(property) ? sameColor(value, actual) : value === actual;
      if (!equal) found.push({ kind: "style", name, property, expected: value, actual });
    }
  }
  return found;
}

/**
 * Properties of `not_default` whose value with the kit stylesheet equals the value without it:
 * the element kept the browser default there.
 */
export function compareDefaults(
  expected: BaseExpected,
  styled: Record<string, Record<string, string> | null>,
  unstyled: Record<string, Record<string, string> | null>,
): BaseDeviation[] {
  const found: BaseDeviation[] = [];
  for (const [name, props] of Object.entries(expected.not_default)) {
    const a = styled[name];
    const b = unstyled[name];
    if (!a || !b) {
      found.push({ kind: "missing", name });
      continue;
    }
    for (const property of props) {
      const kit = normalizeBaseValue(property, a[property] ?? "");
      const browser = normalizeBaseValue(property, b[property] ?? "");
      if (kit === browser) found.push({ kind: "default", name, property, actual: kit });
    }
  }
  return found;
}
