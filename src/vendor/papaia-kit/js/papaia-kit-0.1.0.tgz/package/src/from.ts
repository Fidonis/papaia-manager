/**
 * Return path: resolve a `from` parameter to an address of a catalog target
 * (oberflaeche 2.5). Same rule and same vectors as `resolve_from` in Python
 * (`contract/vectors/from.json`):
 *
 *     from = <module>:<target>:<key>
 *     key  = "-"               target pattern without placeholder
 *          | <id>              one placeholder, id = [A-Za-z0-9-]{1,64}
 *          | <id>~<version>    two placeholders, version = [1-9][0-9]{0,8}
 *
 * The target `admin` stands for the module's `adminUrl` when the module names
 * no target of that name. The module must be in the catalog; a stopped module
 * still resolves, with `running` false, so the shell shows the locked link of
 * interface spec 2.4 instead of a link.
 * Everything else is discarded (`null`): no breadcrumb, no redirect, no
 * message. An address passed as a parameter is never evaluated; the result is
 * always the catalog's `publicUrl` joined with the catalog's pattern.
 */
import { findSurface, type Catalog, type Surface, type Text } from "./catalog.ts";

/** Longest `from` value that is parsed at all. */
export const MAX_FROM_LENGTH = 256;

/** Target name that stands for `adminUrl`. */
export const ADMIN_TARGET = "admin";

/** Where the breadcrumb "Zurück zu <title>" leads. */
export interface ReturnTarget {
  /** Switcher id of the calling module. */
  readonly module: string;
  /** Target name in that module. */
  readonly target: string;
  /** Module title from the catalog. */
  readonly title: Text;
  /** Absolute address of the object in the calling module. */
  readonly url: string;
  /** Absolute address of the target's `after_done` path, if the target names one. */
  readonly afterDone: string | null;
  /** False for a stopped module: the shell shows a locked link (interface spec 2.4). */
  readonly running: boolean;
}

const FROM = /^([a-z0-9][a-z0-9._-]{0,127}):([a-z][a-z0-9_]{0,39}):([A-Za-z0-9~-]{1,74})$/;
const ID = /^[A-Za-z0-9-]{1,64}$/;
const VERSION = /^[1-9][0-9]{0,8}$/;
const PLACEHOLDER = /\{[a-z][a-z0-9_]{0,39}\}/g;
const LIST_KEY = "-";

function target(surface: Surface, name: string): { pattern: string; afterDone: string | null } | null {
  const named = Object.prototype.hasOwnProperty.call(surface.targets, name) ? surface.targets[name] : undefined;
  if (named !== undefined) {
    return named;
  }
  if (name === ADMIN_TARGET && surface.adminUrl !== null) {
    return { pattern: surface.adminUrl, afterDone: null };
  }
  return null;
}

function keyValues(key: string, placeholders: number): string[] | null {
  if (placeholders === 0) {
    return key === LIST_KEY ? [] : null;
  }
  if (placeholders === 1) {
    return key !== LIST_KEY && ID.test(key) ? [key] : null;
  }
  if (placeholders === 2) {
    const at = key.indexOf("~");
    if (at < 0) {
      return null;
    }
    const ident = key.slice(0, at);
    const version = key.slice(at + 1);
    if (ident === LIST_KEY || !ID.test(ident) || !VERSION.test(version)) {
      return null;
    }
    return [ident, version];
  }
  return null;
}

/** Return address for `value` of the `from` parameter, or `null` to discard it. */
export function resolveFrom(catalog: Catalog, value: string | null | undefined): ReturnTarget | null {
  if (value === null || value === undefined) {
    return null;
  }
  if (typeof value !== "string") {
    throw new TypeError("from must be a string");
  }
  if (value.length > MAX_FROM_LENGTH) {
    return null;
  }
  const match = FROM.exec(value);
  if (match === null) {
    return null;
  }
  const [, moduleId = "", targetName = "", key = ""] = match;
  const surface = findSurface(catalog, moduleId);
  if (surface === null) {
    return null;
  }
  const found = target(surface, targetName);
  if (found === null) {
    return null;
  }
  const values = keyValues(key, (found.pattern.match(PLACEHOLDER) ?? []).length);
  if (values === null) {
    return null;
  }
  let next = 0;
  const path = found.pattern.replace(PLACEHOLDER, () => values[next++] ?? "");
  const base = surface.publicUrl.replace(/\/+$/, "");
  return Object.freeze({
    module: surface.id,
    target: targetName,
    title: surface.title,
    url: base + path,
    afterDone: found.afterDone === null ? null : base + found.afterDone,
    running: surface.running,
  });
}
