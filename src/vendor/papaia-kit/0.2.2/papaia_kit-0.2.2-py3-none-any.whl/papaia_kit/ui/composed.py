"""Composed reference pages: how a real page of a module looks (oberflaeche 3.5, 3.8, UXB-P12).

Five pages, each built only from the macros of ``pk/components.html`` with the
test branding of the reference input and synthetic data: ``overview`` (module
tiles in three states, task list with count and due weekday, group cards),
``settings`` (fieldsets, checkbox and radio groups, an ordered choice with up
and down buttons, form actions, error summary), ``list`` (table with an actions
menu per row and a pager), ``state`` (not found, empty) and ``data`` (what the
modules keep about a person: cards in a grid, one description list per category
with whole sentences as values, one module unreachable). They are the visual
target of a module pull request (``contract/design-review.md``); the files
``contract/examples/pages/<page>.<lang>.html`` hold them as rendered, and
``papaia-kit specimen pages --check`` keeps the files current.
"""

from __future__ import annotations

import copy
import json
from typing import Any

from markupsafe import Markup

from papaia_kit._resources import contract_dir
from papaia_kit.ui import messages
from papaia_kit.ui.shell import parse_shell_input, render_shell
from papaia_kit.ui.specimen import (
    REFERENCE_CSRF,
    REFERENCE_INPUT,
    SpecimenError,
    reference_environment,
)
from papaia_kit.ui.tokens import THEMES

__all__ = ["MODULE", "PAGES", "composed_body", "composed_page", "page_files"]

PAGES = ("overview", "settings", "list", "state", "data")
# The pages belong to Mein Bereich, whose overview is the entry page of the installation.
MODULE = "me"
TIME_ZONE = "Europe/Berlin"

TEXTS: dict[str, dict[str, str]] = {
    "de": {
        "overview": "Übersicht",
        "work": "Arbeiten",
        "settings": "Einstellungen",
        "list": "Rechnungen",
        "modules": "Ihre Module",
        "modules_text": "Öffnen Sie ein Modul, um dort weiterzuarbeiten.",
        "tasks": "Meine Aufgaben",
        "all_tasks": "Alle Aufgaben",
        "due": "Fällig:",
        "groups": "Meine Gruppen",
        "members": "Mitglieder",
        "open_tasks": "Offene Aufgaben",
        "notify": "Benachrichtigungen",
        "mail": "Mail-Adresse für Erinnerungen",
        "mail_error": (
            "Geben Sie eine vollständige Mail-Adresse ein, zum Beispiel name@example.org."
        ),
        "channels": "Erinnern per",
        "channels_hint": "Sie können mehrere Wege wählen.",
        "display": "Darstellung",
        "theme": "Erscheinungsbild",
        "lang": "Sprache",
        "order": "Reihenfolge der Module",
        "order_hint": "So erscheinen die Module auf Ihrer Übersicht.",
        "up": "Nach oben",
        "down": "Nach unten",
        "save": "Speichern",
        "invoices": "Rechnungen",
        "invoices_text": "Eingegangene Rechnungen, die nächste Fälligkeit zuerst.",
        "number": "Nummer",
        "supplier": "Lieferant",
        "due_on": "Fällig am",
        "amount": "Betrag (EUR)",
        "pages": "Seiten der Rechnungen",
        "open": "Öffnen",
        "delete": "Löschen",
        "actions_for": "Weitere Aktionen für",
        "new_invoice": "Rechnung erfassen",
        "export": "Als CSV exportieren",
        "recent": "Zuletzt geöffnet",
        "recent_empty": "Hier erscheinen die Seiten, die Sie zuletzt geöffnet haben.",
        "to_overview": "Zur Übersicht",
        "data": "Meine Daten",
        "data_text": (
            "Welche Daten die Module über Sie speichern, wozu und wie lange. "
            "Von hier aus exportieren, berichtigen und löschen Sie sie."
        ),
        "export_all": "Alle Daten exportieren",
        "data_modules": "Module",
        "correct": "Korrigieren oder löschen",
        "count": "Anzahl",
        "purpose": "Wozu",
        "retention": "Wie lange",
        "deletion": "Löschen",
        "incomplete": "Die Übersicht ist deshalb unvollständig.",
    },
    "en": {
        "overview": "Overview",
        "work": "Work",
        "settings": "Settings",
        "list": "Invoices",
        "modules": "Your modules",
        "modules_text": "Open a module to continue working there.",
        "tasks": "My tasks",
        "all_tasks": "All tasks",
        "due": "Due:",
        "groups": "My groups",
        "members": "Members",
        "open_tasks": "Open tasks",
        "notify": "Notifications",
        "mail": "Mail address for reminders",
        "mail_error": "Enter a complete mail address, for example name@example.org.",
        "channels": "Remind by",
        "channels_hint": "You can choose more than one way.",
        "display": "Display",
        "theme": "Appearance",
        "lang": "Language",
        "order": "Order of the modules",
        "order_hint": "This is how the modules appear on your overview.",
        "up": "Move up",
        "down": "Move down",
        "save": "Save",
        "invoices": "Invoices",
        "invoices_text": "Incoming invoices, the next due date first.",
        "number": "Number",
        "supplier": "Supplier",
        "due_on": "Due on",
        "amount": "Amount (EUR)",
        "pages": "Pages of the invoices",
        "open": "Open",
        "delete": "Delete",
        "actions_for": "More actions for",
        "new_invoice": "Record invoice",
        "export": "Export as CSV",
        "recent": "Recently opened",
        "recent_empty": "The pages you opened last appear here.",
        "to_overview": "To the overview",
        "data": "My data",
        "data_text": (
            "What the modules keep about you, what for and how long. "
            "From here you export, correct and delete it."
        ),
        "export_all": "Export all data",
        "data_modules": "Modules",
        "correct": "Correct or delete",
        "count": "Count",
        "purpose": "What for",
        "retention": "How long",
        "deletion": "Deletion",
        "incomplete": "The overview is therefore incomplete.",
    },
}

# Synthetic data only: invented names, example domains, no person or organisation of record.
_DATA: dict[str, dict[str, Any]] = {
    "de": {
        "tiles": [
            {
                "state": "open",
                "name": "Flow",
                "symbol": "flow",
                "href": "/flow/",
                "purpose": "Abläufe planen und automatisch starten.",
                "example": "Rechnungen jeden Montag prüfen.",
            },
            {
                "state": "no_access",
                "name": "Data",
                "symbol": "data",
                "contact": "Leitung Buchhaltung",
            },
            {"state": "stopped", "name": "Studio", "symbol": "studio"},
        ],
        "tasks": [
            {
                "title": "Rechnung 2026-0042 freigeben",
                "href": "/tasks/42",
                "due": "2026-03-09T12:00:00+01:00",
            },
            {
                "title": "Urlaubsantrag von Ben Muster prüfen",
                "href": "/tasks/43",
                "due": "2026-03-10T09:30:00+01:00",
            },
            {
                "title": "Quartalsbericht ergänzen",
                "href": "/tasks/44",
                "due": "2026-03-13T16:00:00+01:00",
            },
        ],
        "groups": [
            {"name": "Buchhaltung", "href": "/groups/accounting", "members": "4", "open": "2"},
            {"name": "Vertrieb Süd", "href": "/groups/sales-south", "members": "7", "open": "1"},
            {"name": "Projekt Umzug", "href": "/groups/move", "members": "3", "open": "0"},
        ],
        "mail": "anna.beispiel@",
        "channels": [
            {"value": "mail", "label": "Mail"},
            {"value": "me", "label": "Hinweis in Mein Bereich"},
        ],
        "themes": [
            {"value": "light", "label": "Hell"},
            {"value": "dark", "label": "Dunkel"},
            {"value": "system", "label": "Wie das System"},
        ],
        "languages": [
            {"value": "de", "label": "Deutsch"},
            {"value": "en", "label": "Englisch"},
        ],
        "lang": "de",
        "order": [
            {"id": "flow", "name": "Flow", "symbol": "flow"},
            {"id": "data", "name": "Data", "symbol": "data"},
            {"id": "studio", "name": "Studio", "symbol": "studio"},
        ],
        "invoices": [
            {
                "id": "2026-0042",
                "supplier": "Bürobedarf Muster GmbH",
                "due": "2026-03-09T12:00:00+01:00",
                "amount": "1249.90",
            },
            {
                "id": "2026-0043",
                "supplier": "Druckerei Beispiel",
                "due": "2026-03-12T12:00:00+01:00",
                "amount": "86.5",
            },
            {
                "id": "2026-0044",
                "supplier": "Reinigung Sauber & Co.",
                "due": "2026-03-16T12:00:00+01:00",
                "amount": "420",
            },
        ],
        "total": 42,
        "reference": "c7a1e2f4",
        "data_modules": [
            {
                "id": "flow",
                "name": "Abläufe",
                "categories": [
                    {
                        "title": "Einstellungen",
                        "count": "3",
                        "purpose": "Ihre Benachrichtigungen und Ihre Vertretung.",
                        "retention": "Bis Sie sie ändern oder Ihr Konto gelöscht wird.",
                        "deletion": (
                            "Sie können diese Daten selbst löschen; die Vertretung endet "
                            "zum angegebenen Tag."
                        ),
                    },
                    {
                        "title": "Freigaben",
                        "count": "27",
                        "purpose": "Nachweis, wer welche Rechnung wann freigegeben hat.",
                        "retention": "Zehn Jahre nach Ende des Geschäftsjahres.",
                        "deletion": (
                            "Wird wegen der Aufbewahrungspflicht nicht auf Antrag gelöscht."
                        ),
                    },
                ],
            },
            {
                "id": "assistant",
                "name": "Assistant",
                "categories": [
                    {
                        "title": "Gedächtnis",
                        "count": "12",
                        "purpose": "Was sich der Assistant über Ihre Arbeitsweise gemerkt hat.",
                        "retention": "Bis Sie einen Eintrag löschen.",
                        "deletion": (
                            "Sie können jeden Eintrag einzeln oder alle auf einmal löschen."
                        ),
                    },
                ],
            },
        ],
        "data_unreachable": "Dokumente",
    },
    "en": {
        "tiles": [
            {
                "state": "open",
                "name": "Flow",
                "symbol": "flow",
                "href": "/flow/",
                "purpose": "Plan workflows and start them automatically.",
                "example": "Check invoices every Monday.",
            },
            {
                "state": "no_access",
                "name": "Data",
                "symbol": "data",
                "contact": "Head of accounting",
            },
            {"state": "stopped", "name": "Studio", "symbol": "studio"},
        ],
        "tasks": [
            {
                "title": "Approve invoice 2026-0042",
                "href": "/tasks/42",
                "due": "2026-03-09T12:00:00+01:00",
            },
            {
                "title": "Check leave request from Ben Sample",
                "href": "/tasks/43",
                "due": "2026-03-10T09:30:00+01:00",
            },
            {
                "title": "Complete the quarterly report",
                "href": "/tasks/44",
                "due": "2026-03-13T16:00:00+01:00",
            },
        ],
        "groups": [
            {"name": "Accounting", "href": "/groups/accounting", "members": "4", "open": "2"},
            {"name": "Sales South", "href": "/groups/sales-south", "members": "7", "open": "1"},
            {"name": "Office move", "href": "/groups/move", "members": "3", "open": "0"},
        ],
        "mail": "anna.sample@",
        "channels": [
            {"value": "mail", "label": "Mail"},
            {"value": "me", "label": "Notice in My area"},
        ],
        "themes": [
            {"value": "light", "label": "Light"},
            {"value": "dark", "label": "Dark"},
            {"value": "system", "label": "Like the system"},
        ],
        "languages": [
            {"value": "de", "label": "German"},
            {"value": "en", "label": "English"},
        ],
        "lang": "en",
        "order": [
            {"id": "flow", "name": "Flow", "symbol": "flow"},
            {"id": "data", "name": "Data", "symbol": "data"},
            {"id": "studio", "name": "Studio", "symbol": "studio"},
        ],
        "invoices": [
            {
                "id": "2026-0042",
                "supplier": "Sample Office Supplies Ltd",
                "due": "2026-03-09T12:00:00+01:00",
                "amount": "1249.90",
            },
            {
                "id": "2026-0043",
                "supplier": "Example Print Shop",
                "due": "2026-03-12T12:00:00+01:00",
                "amount": "86.5",
            },
            {
                "id": "2026-0044",
                "supplier": "Clean & Co. Services",
                "due": "2026-03-16T12:00:00+01:00",
                "amount": "420",
            },
        ],
        "total": 42,
        "reference": "c7a1e2f4",
        "data_modules": [
            {
                "id": "flow",
                "name": "Workflows",
                "categories": [
                    {
                        "title": "Settings",
                        "count": "3",
                        "purpose": "Your notifications and your deputy.",
                        "retention": "Until you change them or your account is deleted.",
                        "deletion": (
                            "You can delete this data yourself; the deputy ends on the day you set."
                        ),
                    },
                    {
                        "title": "Approvals",
                        "count": "27",
                        "purpose": "Record of who approved which invoice and when.",
                        "retention": "Ten years after the end of the financial year.",
                        "deletion": "Not deleted on request because of the retention duty.",
                    },
                ],
            },
            {
                "id": "assistant",
                "name": "Assistant",
                "categories": [
                    {
                        "title": "Memory",
                        "count": "12",
                        "purpose": "What the Assistant remembers about the way you work.",
                        "retention": "Until you delete an entry.",
                        "deletion": "You can delete each entry on its own or all at once.",
                    },
                ],
            },
        ],
        "data_unreachable": "Documents",
    },
}


def _check(name: str, lang: str) -> None:
    if name not in PAGES:
        raise SpecimenError(f"page must be one of {list(PAGES)}")
    if lang not in TEXTS:
        raise SpecimenError(f"lang must be one of {sorted(TEXTS)}")


def composed_body(name: str, lang: str) -> Markup:
    """Content of ``main`` of one composed page, rendered from the kit's macros."""
    _check(name, lang)
    module = (
        reference_environment()
        .get_template("pk/pages.html")
        .make_module({"pk_lang": lang, "pk_csrf": REFERENCE_CSRF})
    )
    data = {**_DATA[lang], "time_zone": TIME_ZONE}
    body: Markup = getattr(module, name)(TEXTS[lang], data)
    return body


def _title(name: str, lang: str) -> str:
    if name == "state":
        return messages.load_texts("states", lang)["not_found.title"]
    return TEXTS[lang][name]


def composed_page(name: str, *, lang: str, theme: str) -> str:
    """The whole document of one composed page inside the shell of the reference input."""
    _check(name, lang)
    if theme not in THEMES:
        raise SpecimenError(f"theme must be one of {list(THEMES)}")
    texts = TEXTS[lang]
    doc: dict[str, Any] = copy.deepcopy(
        json.loads(
            (contract_dir() / "shell" / "inputs" / REFERENCE_INPUT).read_text(encoding="utf-8")
        )
    )
    surface = next(
        ui
        for service in doc["catalog"]["services"]
        for ui in service.get("ui", [])
        if ui["id"] == MODULE
    )
    doc["module"] = {"id": MODULE, "title": surface["title"], "icon": surface["icon"]}
    doc.update(locale=lang, theme=theme)
    page: dict[str, Any] = {"title": _title(name, lang)}
    if name != "overview":
        page["breadcrumb"] = [
            {"label": texts["overview"], "href": "/"},
            {"label": page["title"]},
        ]
    if name == "list":
        # Page header of interface spec 2.1: one primary button, the rest in the menu.
        page["primary_action"] = {"label": texts["new_invoice"], "href": "/invoices/new"}
        page["more_actions"] = [{"label": texts["export"], "href": "/invoices/export"}]
    doc["page"] = page
    paths = {
        "overview": "/",
        "settings": "/settings",
        "list": "/invoices",
        "state": "/missing",
        "data": "/data",
    }
    doc["nav"] = {
        "current": paths[name],
        # The shell puts "Übersicht" / "Overview" first by itself (Ä-30).
        "groups": [
            {
                "label": texts["work"],
                "items": [
                    {"label": texts["list"], "href": "/invoices"},
                    {"label": texts["settings"], "href": "/settings"},
                ],
            }
        ],
    }
    return render_shell(parse_shell_input(doc), composed_body(name, lang))


def page_files() -> dict[str, str]:
    """``examples/pages/<page>.<lang>.html`` (relative to the contract) and their content."""
    return {
        f"examples/pages/{name}.{lang}.html": composed_page(name, lang=lang, theme="light")
        for name in PAGES
        for lang in sorted(TEXTS)
    }
