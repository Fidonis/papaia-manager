"""Kit versions in a suite bill of materials (interface spec 3.6, UXB-P13).

Modules may carry different kit versions of one major version (KE-31), but a
suite may combine two kit versions only when no release between them carries
a ``visual`` change: otherwise two modules of one suite render the same
element differently (PLT-83-A4).

The compatibility matrix ``contract/versions.yaml`` (``papaia.kit-versions/1``)
lists every kit release in ascending order with its ``visual`` flag: ``true``
when its changelog entry marks a change of how existing markup renders.
:func:`check_bom` applies the rule to the kit versions of a bill of materials
(``papaia.kit-bom/1``, schema ``contract/kit-bom.schema.json``):

- all versions have the same major version;
- every version is in the matrix (a newer version needs the newer kit's
  matrix, so an unknown version is refused, never passed);
- no release ``r`` with ``lowest < r <= highest`` is ``visual``.

Problems name the place, the versions and the modules; they never quote free
text of the file.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

import yaml
from jsonschema import Draft202012Validator

from papaia_kit._resources import contract_dir

__all__ = [
    "BOM_FORMAT",
    "MATRIX_FORMAT",
    "MAX_BOM_BYTES",
    "MAX_MODULES",
    "BomError",
    "Release",
    "check_bom",
    "load_bom",
    "load_matrix",
]

BOM_FORMAT = "papaia.kit-bom/1"
MATRIX_FORMAT = "papaia.kit-versions/1"
MAX_BOM_BYTES = 256 * 1024
MAX_MODULES = 64
_MAX_MATRIX_BYTES = 64 * 1024
_MAX_RELEASES = 1000
_MAX_PROBLEMS = 20
_VERSION = re.compile(r"^(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})$")


class BomError(ValueError):
    """A bill of materials or the matrix failed a check. ``problems`` lists place and rule."""

    def __init__(self, problems: Iterable[str]) -> None:
        self.problems = tuple(problems)[:_MAX_PROBLEMS] or ("invalid",)
        super().__init__("; ".join(self.problems))


@dataclass(frozen=True, order=True)
class Release:
    """One kit release of the matrix; ordered by version."""

    key: tuple[int, int, int]
    visual: bool

    @classmethod
    def parse(cls, version: str, *, visual: bool) -> Release:
        found = _VERSION.fullmatch(version)
        if not found:
            raise BomError(["release version must be MAJOR.MINOR.PATCH"])
        major, minor, patch = (int(part) for part in found.groups())
        return cls((major, minor, patch), visual)

    @property
    def text(self) -> str:
        return ".".join(str(part) for part in self.key)


class _UniqueKeyLoader(yaml.SafeLoader):
    """Safe loader that rejects a mapping key written twice."""


def _mapping(loader: _UniqueKeyLoader, node: yaml.MappingNode) -> dict[Any, Any]:
    keys = [loader.construct_object(k) for k, _ in node.value]
    if len(keys) != len(set(map(repr, keys))):
        raise yaml.constructor.ConstructorError(None, None, "duplicate key", node.start_mark)
    return loader.construct_mapping(node)


_UniqueKeyLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)


def _read(data: bytes, source: str, limit: int) -> Any:
    if len(data) > limit:
        raise BomError([f"{source}: larger than {limit} bytes"])
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        raise BomError([f"{source}: not UTF-8"]) from None
    try:
        return yaml.load(text, Loader=_UniqueKeyLoader)  # noqa: S506 (safe loader subclass)
    except yaml.constructor.ConstructorError as exc:
        if exc.problem == "duplicate key":
            raise BomError([f"{source}: duplicate key"]) from None
        raise BomError([f"{source}: not valid YAML or JSON"]) from None
    except yaml.YAMLError:
        raise BomError([f"{source}: not valid YAML or JSON"]) from None


# --- matrix -----------------------------------------------------------------------


def load_matrix(
    data: bytes | None = None, *, source: str = "contract/versions.yaml"
) -> tuple[Release, ...]:
    """Read the compatibility matrix; the kit's own file when ``data`` is ``None``."""
    if data is None:
        data = (contract_dir() / "versions.yaml").read_bytes()
    document = _read(data, source, _MAX_MATRIX_BYTES)
    if not isinstance(document, dict) or set(document) != {"format", "releases"}:
        raise BomError([f"{source}: exactly the fields format and releases"])
    if document["format"] != MATRIX_FORMAT:
        raise BomError([f"{source}: format must be {MATRIX_FORMAT}"])
    rows = document["releases"]
    if not isinstance(rows, list) or not 1 <= len(rows) <= _MAX_RELEASES:
        raise BomError([f"{source}: releases must list at least one release"])
    releases: list[Release] = []
    for index, row in enumerate(rows):
        where = f"{source}: releases/{index}"
        if not isinstance(row, dict) or set(row) - {"version", "visual"}:
            raise BomError([f"{where}: unknown field, only version and visual"])
        if not isinstance(row.get("visual"), bool):
            raise BomError([f"{where}: visual must be true or false"])
        version = row.get("version")
        if not isinstance(version, str) or not _VERSION.fullmatch(version):
            raise BomError([f"{where}: version must be MAJOR.MINOR.PATCH"])
        release = Release.parse(version, visual=row["visual"])
        if releases and release.key <= releases[-1].key:
            raise BomError([f"{where}: versions must be strictly ascending"])
        releases.append(release)
    return tuple(releases)


# --- bill of materials ------------------------------------------------------------


@lru_cache(maxsize=1)
def _validator() -> Draft202012Validator:
    schema = json.loads((contract_dir() / "kit-bom.schema.json").read_text(encoding="utf-8"))
    return Draft202012Validator(schema)


def _place(path: Iterable[Any]) -> str:
    return "/".join(str(part) for part in path) or "(top)"


def load_bom(data: bytes, *, source: str = "bom") -> list[tuple[str, str]]:
    """Check a bill of materials and return ``(module, kit version)`` in file order."""
    document = _read(data, source, MAX_BOM_BYTES)
    if not isinstance(document, dict):
        raise BomError([f"{source}: must be a mapping with format and modules"])
    problems = []
    for error in sorted(_validator().iter_errors(document), key=lambda e: list(e.path)):
        place = _place(error.absolute_path)
        if error.validator == "additionalProperties":
            extra = sorted(set(error.instance) - set(error.schema.get("properties", {})))
            problems.append(f"{source}: {place}: unknown field {', '.join(extra)}")
        elif error.validator == "required":
            missing = sorted(set(error.validator_value) - set(error.instance))
            problems.append(f"{source}: {place}: missing field {', '.join(missing)}")
        else:
            # The rule, not the value: values of the file are never quoted.
            problems.append(f"{source}: {place}: breaks the rule {error.validator}")
    if problems:
        raise BomError(problems)
    entries = [(m["name"], m["kit"]) for m in document["modules"]]
    seen: set[str] = set()
    for index, (name, _) in enumerate(entries):
        if name in seen:
            problems.append(f"{source}: modules/{index}: {name} listed twice")
        seen.add(name)
    if problems:
        raise BomError(problems)
    return entries


def check_bom(entries: Sequence[tuple[str, str]], matrix: Sequence[Release]) -> list[str]:
    """Problems of combining the kit versions of ``entries``; empty when allowed."""
    by_version: dict[tuple[int, int, int], list[str]] = {}
    for name, version in entries:
        by_version.setdefault(Release.parse(version, visual=False).key, []).append(name)
    known = {release.key: release for release in matrix}
    newest = matrix[-1].text if matrix else "none"

    def _text(key: tuple[int, int, int]) -> str:
        return ".".join(str(part) for part in key)

    def _who(key: tuple[int, int, int]) -> str:
        return ", ".join(by_version[key])

    problems = [
        f"kit {_text(key)} is not in the compatibility matrix ({_who(key)}); the matrix ends "
        f"at {newest}, check with the kit that knows it"
        for key in sorted(by_version)
        if key not in known
    ]
    if problems:
        return problems
    low, high = min(by_version), max(by_version)
    if low[0] != high[0]:
        return [
            f"kit {_text(low)} ({_who(low)}) and {_text(high)} ({_who(high)}) differ in the "
            "major version"
        ]
    for key in sorted(by_version)[1:]:
        lower = max(k for k in by_version if k < key)
        between = [r for r in matrix if lower < r.key <= key and r.visual]
        if between:
            problems.append(
                f"kit {_text(lower)} ({_who(lower)}) and {_text(key)} ({_who(key)}) must not be "
                f"combined: {between[0].text} is visual"
            )
    return problems
