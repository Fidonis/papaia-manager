# Platform catalog and group list

Normative description of two files the core renders into
`$PAPAIA_CONFIG_DIR/platform/`:

| File | Format | Schema |
|---|---|---|
| `services.json` | `papaia.platform-services/1` | `schemas/platform-services.v1.schema.json` |
| `groups.json` | `papaia.platform-groups/1` | `schemas/platform-groups.v1.schema.json` |

Examples that validate: `contract/examples/platform-services.example.json`,
`contract/examples/platform-groups.example.json`.

**The catalog is an offer, not a permission.** It grants no right, lowers no
data class and activates nothing by itself. Every field a module uses for
display (`visible_for_roles`, `role_hint`) is display only; the target checks
rights server-side on every call.

## 1. What the contract covers

| Topic | Rule |
|---|---|
| Discovery | Add-ons declare `exposes:` in their manifest, core profiles in `exposes.yaml`. The core renders `services.json` on `setup`, `start`, every `addon` operation and when branding or groups change in the manager. Installed modules stay in the catalog while stopped (`state: stopped`); modules that are not installed are absent. |
| Capability description | Per entry: `id`, `kind` (`mcp`, `rest`, `ui`, `me`), `title` and `description` in German and English, internal `address`, `ca` (kritis only), `audience`, permitted identity kinds `identity` (`person`, `service`), `operations[]`, `events[]`, `ui[]`. Per operation: `name`, `effect`, `retry`, `input_schema`, `output_schema`, `data_class_max`, `role_hint` (display only). |
| Read and write | Every operation carries exactly one `effect`: `read`, `write`, `send`, `delete` or `check`. A tool a server reports at runtime but the entry does not declare counts as the highest data class and as not writable in every module. |
| Identity propagation | The token of the acting person for exactly the `audience` of the entry, obtained by token exchange. A service identity only where `identity` contains `service` and the call has no person (event-started runs). A token is never passed on to a third service; `downstream` names the only permitted chained exchanges. |
| Rights check | Server-side at the target on every call (`rights_check`: `server`, or `server_and_check_access` when the caller also asks `check_access` first). A module may narrow (app rights, data class), never widen. `standard_operations` lists `describe_access` and `check_access` where the server offers them. |
| Data classes | One scale of eight levels, ordered: `public` < `internal` < `partner_contact` < `personal` < `employee` < `confidential` < `special` < `professional_secret`. |
| Audit | Every operation with effect `write`, `send` or `delete` produces one `papaia.audit/1` row at the caller and at the server, carrying the correlation id. The catalog itself carries no audit data. |
| Error model | Errors use the shared envelope (`code`, `class`, `message`, `hint`, `correlation_id`, `retryable`); "not found" and "not allowed" are indistinguishable for objects. A vanished entry is reported as class `upstream_unavailable`. |
| Versioning | `format` ends in `/<n>`; `n` grows only with an incompatible change. Handling `exposes:` is contract generation 7 (`addon_api` ≥ 7). Every entry carries `content_hash`; approvals in modules bind to it. |

## 2. `services.json`

### 2.1 Top level

| Field | Required | Meaning |
|---|---|---|
| `format` | yes | `papaia.platform-services/1` |
| `generated_at` | yes | Render time, UTC (`2026-11-20T09:00:00Z`) |
| `addon_api` | yes | Contract generation of the rendering core, at least 7 |
| `security_profile` | no | `standard` or `kritis`; `ca` in an entry is allowed only under `kritis` |
| `identity` | yes | `issuer` (public https), `token_endpoint_internal`, `jwks_uri_internal` (internal network) |
| `services` | yes | Entries, at most 500 |
| `models` | yes | Model aliases: `alias` (`papaia-…`), `features`, `context`, `max_class`, `test_backend` |
| `branding` | no | The single source of the installation's brand: `name` (≤ 60), `suffix` (≤ 60), `logo_sha256`, `contact {name, mail?, phone?}`. The logo is the file `platform/brand-logo` next to the catalog; each module serves it from its own origin under `/_kit/brand/logo` and checks the digest. No add-on carries its own branding. |
| `platform_notices` | no | Set by the core only (test mode, emergency stop, maintenance): `{id, level, text {de, en}}` with `level` `info` or `warning`, at most 20. No module keeps notices of its own. |
| `approvals` | no (`kritis`: yes) | `four_eyes` (`on`/`off`, default `off`; `kritis`: always `on`), the only four-eyes setting of the platform, see 2.7 |
| `delegations` | no | Delegation lifetime in effect for the installation: `idle_days` and `max_days`, defaults by security profile (90 / 180, `kritis` 7 / 30), see 2.6 |

### 2.2 Entry

| Field | Required | Meaning |
|---|---|---|
| `id` | yes | Stable across versions, `^[a-z0-9][a-z0-9._-]{0,127}$`; equals the knowledge source id where one exists |
| `provider` | yes | Add-on name or `core:<profile>` |
| `version` | yes | Version of the providing add-on or profile |
| `kind` | yes | `mcp`, `rest`, `ui` or `me` (personal-area API) |
| `title`, `description` | yes / no | `{de, en}`, each 1–200 characters |
| `state` | for `ui` | `running` or `stopped`, set by `papaia-ctl addon start` / `stop` |
| `trust` | yes | `platform` only for entries of the suite's bill of materials, otherwise `addon`; set by the core, never declared |
| `content_hash` | yes | `sha256:` + SHA-256 over the RFC 8785 canonical form of the entry without `content_hash` |
| `address` | for `mcp`, `rest`, `me` | Resolved internal address |
| `audience` | for `mcp`, `rest`, `me` | `mcp-<name>`, `papaia-<name>`, or the existing names `flow`, `assist-api` |
| `azp` | no | Caller clients approved for this audience; rendered from approvals, never from manifests |
| `identity` | yes | Non-empty set of `person`, `service` |
| `operations` | for `mcp` | At most 200, see 2.3 |
| `events` | no | `{name, version, title, payload_schema, data_class_max}`, triggers for flows |
| `ui` | for `ui` | At least one surface, see 2.4 |
| `downstream` | no | Catalog ids or `{kind: catalog_sources}` this entry may exchange onward to |
| `standard_operations` | no | `describe_access`, `check_access` |
| `roles` | no | Realm roles the entry declares: `{name, title, description?}` |

Manifest fields that serve the core alone stay out of the catalog: `storage`,
`delegation`, `header_identity`, `service_accounts`, `volumes`, `export`,
`requires` and `models.needs`. (The top-level `delegations` block is not the manifest field
`delegation`: it is the installation's setting, see 2.6.) The catalog is mounted into every consuming module, so it carries
no account owners, no credential references and no backup or retention detail.

### 2.3 Operation

| Field | Required | Meaning |
|---|---|---|
| `name` | yes | Tool name or `operationId` |
| `version` | yes | Integer ≥ 1 |
| `title` | yes | `{de, en}` |
| `via` | yes | `tools` (MCP) or `rest`; `rest` requires `method` and `path` (path pattern with `{placeholder}`), `tools` forbids both |
| `effect` | yes | `read`, `write`, `send`, `delete`, `check` |
| `retry` | yes | `safe`, `idempotent`, `at_most_once` |
| `input_schema`, `output_schema` | yes | JSON Schema 2020-12 |
| `data_class_max` | yes | Highest data class the operation returns or writes |
| `resource` | for `write`, `delete`, `check` | `{type, id_field}`: kind of the resource and the input field holding its id |
| `rights_check` | yes | `server` or `server_and_check_access` |
| `role_hint` | no | ≤ 80 characters, display only |
| `timeout` | no | digits followed by `ms`, `s` or `m` |

### 2.4 User interface surface (`ui[]`)

| Field | Required | Meaning |
|---|---|---|
| `id` | yes | Switcher id (`chat`, `studio`, `data`, `flow`, `assistant`, `me`, `manager`, …) |
| `title` | yes | `{de, en}` |
| `summary` | no | `{de, en}`, at most 15 words each; switcher and start page |
| `example` | no | `{de, en}`, example sentence of the start page |
| `icon` | yes | Symbol name of the kit sprite |
| `order` | yes | 0–1000; switcher order, ties by `id` |
| `host_key`, `path` | no | Host key from the ingress declaration and the module's start path |
| `public_url` | yes | Rendered browser address, https only |
| `visible_for_roles` | yes | Role names; empty list = every signed-in person |
| `targets` | no | `{<name>: {pattern, after_done?}}`; `pattern` is an own path with `{placeholder}` segments, `after_done` an own path |
| `admin_url` | no | Own path of the module's administration |
| `opens_in` | yes | `same_tab` or `new_tab` |

A module shows a surface in the switcher only when its entry has
`state: running` and `visible_for_roles` is empty or shares a role with the
roles of the module's own token.

### 2.5 No secrets, no open redirects

- No field holds a secret, a token or a credential; the schema has no such field
  and rejects unknown fields at every level.
- Addresses (`address`, `public_url`, `issuer`, `token_endpoint_internal`,
  `jwks_uri_internal`) carry no user information, no query and no fragment.
- `path`, `admin_url`, `targets.*` are own paths only: they start with a single
  `/` and can never be an absolute or protocol-relative URL.
- Every pattern also rejects a trailing line break, in ECMA-262 and in Python
  regular expressions alike.

### 2.6 Delegation lifetime

A delegation (offline session of a person at `flow-engine` or `assist-gate`)
expires after `idle_days` without use or `max_days` after the grant, whichever
comes first. Both values are one setting per installation: the administration
changes them without a code change, the core writes them to the realm (Offline
Session Idle, Offline Session Max) and publishes them here on every render.

| Field | Default | Bounds |
|---|---|---|
| `delegations.idle_days` | 90 (`kritis`: 7) | 1–365 (`kritis`: 1–7) |
| `delegations.max_days` | 180 (`kritis`: 30) | 1–365 (`kritis`: 1–30) |

- `idle_days` is never greater than `max_days`. The schema enforces the bounds
  and the `kritis` upper limits (a `kritis` catalog with 30 / 180 is invalid);
  the catalog reader rejects a catalog whose `idle_days` is greater than
  `max_days` once defaults are applied
  (`delegations/idle_days: greater than max_days`).
- A missing value means the default of the security profile in the table. The
  core publishes both values; the defaults exist so that a catalog of a core
  without the setting stays valid and means the contract defaults. Defaults
  are filled per field, so a partial block can be invalid: `{"max_days": 60}`
  in `standard` or `{"max_days": 6}` in `kritis` leaves `idle_days` at its
  default (90 or 7), which is greater than `max_days`, and the reader rejects
  the catalog. A shorter `max_days` therefore always comes with an
  `idle_days` that is not greater.
- Holders and the personal area compute every expiry date they show (card,
  receipt, list of delegations) from these values with the kit's
  `Catalog.delegation_lifetime` (`DelegationLifetime.expires_at`), never from a
  number of their own and never from `max_idle_days` / `max_age_days` of their
  manifest. A shortened setting takes effect on existing delegations at their
  next renewal; the shown dates follow the catalog in use.
- The values are no secret and no personal data; a change of the setting is
  the audit event `delegation_lifetime_changed` of the core, with the old and
  new values in `detail` (`contract/audit.md`).

### 2.7 Four-eyes setting

One setting decides for every module whether an approval needs a second
person: publishing a Studio app, setting a Data figure to "reviewed",
activating a Flow run definition, approving a connection and the approvals of
the core that follow the setting (E-18). Approvals that need two persons
whatever the setting says (resolving pseudonyms, the deletion lock, the audit
person query, Flow run approvals) are not governed by it.

| Field | Default | Values |
|---|---|---|
| `approvals.four_eyes` | `off` (`kritis`: always `on`) | `on`, `off` |

- In security profile `kritis` the core always publishes `"four_eyes": "on"`;
  the schema rejects a `kritis` catalog without the field or with `off`, and
  the setting cannot be switched off. In every other profile the default is
  `off`, and the administration switches it on or off for the whole
  installation.
- `on`: an approval needs a second person who holds the module's reviewer
  role or the platform role `papaia-confirm`; the submitter's own approval is
  refused with `PK-REVIEW-SELF` (pattern 8 of the interface specification,
  naming the missing second person) or its module alias.
- `off`: the submitter may approve their own object if they hold the
  approving role. The audit row of that approval carries
  `"selbstfreigabe": true` in `detail`, and the interface shows "selbst
  geprüft". `PK-REVIEW-SELF` is not used while the setting is off.
- Modules read the setting with the kit helper and keep no setting of their
  own: no environment variable, database flag, preset or size profile, and no
  rule that depends on the number of administrators.
  `four_eyes_required(catalog)` is `True` in `kritis` or with `on`, and also
  when the catalog is missing or was not checked by the reader (fail closed);
  `review_decision(catalog, submitter=…, approver=…)` applies the person rule
  and returns the error code or the audit flag. The module still checks the
  approver's role server-side on every request.
- The setting is no secret and no personal data. Every change is the audit
  event `four_eyes_changed` of the core with the old and new value in
  `detail`; a refused attempt to switch it off in `kritis` is stored with
  result `denied` (`contract/audit.md`).
- The earlier field `approvals.single_admin_exception` is gone; a catalog that
  carries it is invalid.

## 3. `groups.json`

Groups of the platform realm that a module may offer when a person shares
something. The core writes the file next to `services.json` on every
`catalog render` and every 15 minutes, from the realm declaration, the group
mapping and the identity provider's groups.

| Field | Required | Meaning |
|---|---|---|
| `format` | yes | `papaia.platform-groups/1` |
| `generated_at` | yes | Render time, UTC |
| `groups[]` | yes | At most 5000 groups |
| `groups[].id` | yes | Group id of the identity provider |
| `groups[].path` | yes | Full group path, for example `/sales/south` |
| `groups[].display_name` | yes | `{de, en}` |
| `groups[].technical` | yes | `true` for role bundles and groups with attribute `papaia.technical=true`; never offered for sharing |

The file carries **no member data and no personal data**: no member lists or
counts, no sub-group trees, no attributes, no role mappings. The schema accepts
exactly the four fields above per group and nothing else. Group ids must be
unique; JSON Schema cannot express this, so the catalog reader checks it.

## 4. Consumer rules

- Mount both files read-only; never write them.
- Read them with the kit's catalog reader. An invalid file keeps the last valid
  state in use; the error is logged and reported by `doctor`.
- A new entry is "offered", never active. A changed `content_hash` suspends
  approvals bound to the old hash until approved again. A vanished entry is
  `upstream_unavailable` ("connection removed").
- New entries appear within 60 s (file watch or polling every 30 s).

The reader and its checks are described in `catalog-reader.md`.

## 5. Replacement of the earlier draft

An earlier draft of the same name and format (`papaia.platform-services/1`) was
never rendered by any core. This schema replaces it; the format stays `/1`
because no released producer exists. The draft fields map as follows:

| Draft | Here |
|---|---|
| `kind: llm_api` | top-level `models` |
| `kind: task_feed`, `kind: flow_provider` | `kind: rest` with `operations` |
| `suggested_tools` | `operations` |
| `auth`, `token_exchange` | `identity` and `audience` |
| `max_class` | `data_class_max` per operation |
| `context_assertion` | module assertion of the kit |
| `addon`, `profile` | `provider` (`<addon>` or `core:<profile>`) |
| `url` | `address` (internal) or `ui[].public_url` (browser) |
| `consumable`, `reason` | `state` and the consumer rules in section 4 |
| `digest` | `content_hash` per entry |
| `data_owner_group`, `classification_hint`, `links` | not carried over; no counterpart in the shared contract |
