"""Command line entry point ``papaia-kit``."""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import shlex
import subprocess
import sys
import tempfile
from collections.abc import Sequence
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from papaia_kit import __version__, tokens_dir
from papaia_kit.assertion import vectors_path
from papaia_kit.conformance import (
    HEADER_IDENTITY_PROPERTY,
    SKIPPABLE_DIRS,
    CommandDriver,
    HandoverError,
    IssuerTokens,
    KitReaderDriver,
    ManifestError,
    MeTarget,
    MeV2SuiteError,
    ModelSuiteError,
    Provider,
    RealmError,
    ServerSuiteError,
    ServerTarget,
    StaticExceptionError,
    SuiteResult,
    UrllibFetch,
    audiences,
    check_manifest_files,
    check_model_recording_file,
    check_realm,
    check_realm_export_file,
    check_recording_file,
    exchange_clients,
    junit_xml,
    load_calls,
    load_manifest,
    load_me_declaration,
    load_model_needs,
    load_pin_file,
    load_realm_export,
    load_recording,
    load_static_exceptions,
    read_realm_admin,
    record_me_v2_suite,
    record_server_suite,
    recording_digest,
    run_catalog_consumer,
    run_handover_suite,
    run_me_v2_suite,
    run_server_suite,
    run_static,
    select_entry,
)
from papaia_kit.conformance.injection import (
    DEFAULT_ALLOWED_HOSTS,
    Context,
    CorpusError,
    InjectionCommandDriver,
    load_corpus,
    run_injection,
)
from papaia_kit.conformance.injection import DEFAULT_SUBJECT as INJECTION_SUBJECT
from papaia_kit.conformance.me_v2 import ME_CLIENT
from papaia_kit.conformance.result import case
from papaia_kit.conformance.server import (
    DEFAULT_FOREIGN_AUDIENCE,
    DEFAULT_FOREIGN_AZP,
    DEFAULT_SUBJECT,
)
from papaia_kit.licenses import (
    EnvironmentMismatch,
    Exceptions,
    PolicyError,
    Record,
    evaluate,
    json_records,
    load_exceptions,
    load_policy,
    npm_records,
    python_records,
    render_markdown,
)
from papaia_kit.names import InvalidName, Kind, entries, exchange_scope, validate
from papaia_kit.repo import (
    BaselineError,
    Finding,
    check_commits,
    check_reason,
    check_words,
    load_words_baseline,
    scan_files,
    valid_range,
    write_baseline,
)
from papaia_kit.ui import pages_cli, shell_cli, words_cli
from papaia_kit.ui.messages import MessageError, check_message_dir
from papaia_kit.ui.tokens import (
    ContrastPairError,
    TokenError,
    check_contrast,
    contrast_report,
    load_pairs,
    load_tokens,
)

EXIT_OK, EXIT_FAIL, EXIT_USAGE = 0, 1, 2
# Access token of the read-only admin account for ``conformance realm --admin-url``.
ADMIN_TOKEN_ENV = "PAPAIA_KIT_ADMIN_TOKEN"  # noqa: S105 - name of a variable
MAX_ADMIN_TIMEOUT = 300.0
_MAX_TOKEN_FILE = 64 * 1024
_DIGEST = re.compile(r"sha256:[0-9a-f]{64}")
_IMAGE = re.compile(r"[a-z0-9][a-z0-9._/:@-]{0,254}")
_HOST = re.compile(r"[a-z0-9](?:[a-z0-9-]{0,62}\.)*[a-z0-9-]{1,63}")
_MAX_HOST = 253
_SUBJECT = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:@-]{0,254}")


def _license_inputs(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--policy", type=Path, help="policy file (default: the kit's policy)")
    parser.add_argument(
        "--exceptions",
        type=Path,
        help="license-exceptions.toml of the repository (default: ./license-exceptions.toml)",
    )
    parser.add_argument(
        "--python-project",
        type=Path,
        help="uv project whose environment runs this command; every package of its uv.lock "
        "must be installed there at the locked version",
    )
    parser.add_argument("--npm-lock", type=Path, action="append", default=[])
    parser.add_argument("--records", type=Path, action="append", default=[])
    parser.add_argument("--edition", help="standalone edition rule from the policy")


def _tokens_parser(groups: Any) -> None:
    """Arguments of ``tokens``; ``groups`` is the top-level subparsers action."""
    tokens = groups.add_parser("tokens", help="design tokens")
    tok = tokens.add_subparsers(dest="command", required=True)
    contrast = tok.add_parser("contrast", help="WCAG contrast of the colour pairs, both themes")
    contrast.add_argument("--tokens", type=Path, help="token file (default: the kit's)")
    contrast.add_argument("--pairs", type=Path, help="pair list (default: the kit's)")


def _messages_parser(groups: Any) -> None:
    """Arguments of ``messages``; ``groups`` is the top-level subparsers action."""
    messages = groups.add_parser("messages", help="fixed texts of states and patterns")
    msg = messages.add_subparsers(dest="command", required=True)
    check = msg.add_parser("check", help="forbidden patterns and language parity of message files")
    check.add_argument("--dir", type=Path, help="message directory (default: the kit's)")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="papaia-kit", description=__doc__)
    parser.add_argument("--version", action="version", version=f"papaia-kit {__version__}")
    groups = parser.add_subparsers(dest="group", required=True)

    licenses = groups.add_parser("licenses", help="dependency license policy")
    lic = licenses.add_subparsers(dest="command", required=True)
    check = lic.add_parser("check", help="fail on any dependency the policy does not allow")
    _license_inputs(check)
    check.add_argument("--report", type=Path, help="write a JSON report")
    render = lic.add_parser("render", help="write THIRD_PARTY_LICENSES.md")
    _license_inputs(render)
    render.add_argument("--output", type=Path, default=Path("THIRD_PARTY_LICENSES.md"))
    render.add_argument("--check", action="store_true", help="fail if the file is not current")

    repo = groups.add_parser("repo", help="repository discipline")
    rep = repo.add_subparsers(dest="command", required=True)
    words = rep.add_parser("words", help="denied terms in tracked and new files")
    words.add_argument("--root", type=Path, default=Path())
    words.add_argument(
        "--baseline",
        type=Path,
        help="frozen baseline of this repository: listed hits pass, other hits and stale "
        "entries fail",
    )
    words.add_argument(
        "--write-baseline",
        action="store_true",
        help="create the --baseline file once from the current hits (refuses an existing file)",
    )
    words.add_argument("--reason", help="reason written into every entry with --write-baseline")
    commits = rep.add_parser("commits", help="author, committer, sign-off and message")
    commits.add_argument("--root", type=Path, default=Path())
    commits.add_argument("--email-domain", default="fidonis.de")
    commits.add_argument("range", help="revision range, e.g. origin/main..HEAD or HEAD")

    _names_parser(groups)
    words_cli.add_parser(groups)

    _tokens_parser(groups)
    shell_cli.add_parser(groups)
    pages_cli.add_parser(groups)
    _messages_parser(groups)

    _assertion_parser(groups)

    conformance = groups.add_parser("conformance", help="conformance suites of the contract")
    suites = conformance.add_subparsers(dest="command", required=True)
    manifest = suites.add_parser(
        "manifest", help="exposes: against schema, naming register and the checks beyond it"
    )
    manifest.add_argument("manifest", type=Path, nargs="+", help="papaia-app.yaml or exposes.yaml")
    manifest.add_argument("--compose", type=Path, help="compose file of the module (one manifest)")
    manifest.add_argument(
        "--core-profile",
        action="store_true",
        help="the files are exposes.yaml of core profiles (no name, no module prefix)",
    )
    consumer = suites.add_parser(
        "catalog-consumer", help="shared catalog reader vectors against a reader"
    )
    consumer.add_argument(
        "--driver",
        help="driver command of the reader under test (line protocol); default: the kit reader",
    )
    consumer.add_argument("--timeout", type=float, default=10.0, help="seconds per driver reply")
    recording = suites.add_parser("recording", help="provider recording against format and pin")
    recording.add_argument("recording", type=Path)
    recording.add_argument("--pin", help="pinned digest sha256:<hex> of the recording")
    static = _static_parser(suites)
    realm = _realm_parser(suites)
    injection = _injection_parser(suites)
    servers = _server_parser(suites)
    model = _model_parser(suites)
    parsers = (manifest, consumer, recording, static, realm, model, _handover_parser(suites))
    for suite in (*parsers, servers, injection, _me_v2_parser(suites)):
        suite.add_argument("--junit", type=Path, help="write the result as JUnit XML")
    return parser


def _names_parser(
    groups: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    """Arguments of ``names``."""
    names = groups.add_parser("names", help="naming register")
    nam = names.add_subparsers(dest="command", required=True)
    kinds = [k.value for k in Kind]
    listing = nam.add_parser("list", help="print the register as JSON")
    listing.add_argument("--kind", choices=kinds)
    check_names = nam.add_parser("check", help="fail on any name that breaks the register")
    check_names.add_argument("--kind", choices=kinds, required=True)
    check_names.add_argument("name", nargs="+")
    scope = nam.add_parser("scope", help="print the exchange scope of one audience")
    scope.add_argument("audience")


def _model_parser(suites: Any) -> argparse.ArgumentParser:
    """Arguments of ``conformance model``; ``suites`` is the subparsers action."""
    model: argparse.ArgumentParser = suites.add_parser(
        "model", help="recorded model requests of a module against the allowed features"
    )
    model.add_argument("recording", type=Path, help="request recording of the kit test model")
    model.add_argument(
        "--manifest", type=Path, required=True, help="papaia-app.yaml with models.needs"
    )
    model.add_argument("--id", help="catalog id of one entry (default: the needs of all entries)")
    return model


def _assertion_parser(
    groups: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    """Arguments of ``assertion``."""
    assertion = groups.add_parser("assertion", help="module context assertion")
    asr = assertion.add_subparsers(dest="command", required=True)
    vectors = asr.add_parser("vectors", help="print the path of the shared test vectors")
    vectors.add_argument(
        "--compare", type=Path, help="fail unless this copy is byte for byte the kit's vectors"
    )


def _static_parser(
    suites: argparse._SubParsersAction[argparse.ArgumentParser],
) -> argparse.ArgumentParser:
    """Arguments of ``conformance static``."""
    static = suites.add_parser(
        "static",
        help="server code: generated code execution, built queries and scopes, model names",
    )
    static.add_argument("path", type=Path, nargs="+", help="server source files or directories")
    static.add_argument(
        "--root", type=Path, default=Path(), help="repository root; paths are reported from it"
    )
    static.add_argument(
        "--exceptions",
        type=Path,
        help="exception list (default: static-exceptions.toml in the root, if present)",
    )
    static.add_argument(
        "--include-dir",
        action="append",
        default=[],
        choices=sorted(SKIPPABLE_DIRS),
        metavar="NAME",
        help="also read directories with this name (for example site-packages in an image)",
    )
    static.add_argument(
        "--require-approved",
        action="store_true",
        help=(
            "reject exceptions whose approved_by does not name the security officer "
            "or says pending (joint acceptance)"
        ),
    )
    return static


def _realm_parser(
    suites: argparse._SubParsersAction[argparse.ArgumentParser],
) -> argparse.ArgumentParser:
    """Arguments of ``conformance realm``."""
    realm = suites.add_parser(
        "realm", help="clients with token exchange versus audiences (separation rule)"
    )
    source = realm.add_mutually_exclusive_group(required=True)
    source.add_argument("--export", type=Path, help="realm export file (JSON)")
    source.add_argument(
        "--admin-url",
        help="base URL of the identity provider; reads the realm through the admin API",
    )
    realm.add_argument("--realm", default="papaia", help="realm name (default: papaia)")
    realm.add_argument(
        "--token-file",
        type=Path,
        help="file with the access token of a read-only admin account "
        f"(default: ${ADMIN_TOKEN_ENV})",
    )
    realm.add_argument(
        "--timeout",
        type=_admin_timeout,
        default=10.0,
        help=f"seconds per admin request (above 0, at most {MAX_ADMIN_TIMEOUT:g})",
    )
    return realm


def _injection_parser(
    suites: argparse._SubParsersAction[argparse.ArgumentParser],
) -> argparse.ArgumentParser:
    """Arguments of ``conformance injection``."""
    injection = suites.add_parser(
        "injection", help="the shared corpus of injected instructions against a module"
    )
    mode = injection.add_mutually_exclusive_group(required=True)
    mode.add_argument("--driver", help="driver command of the module under test (line protocol)")
    mode.add_argument(
        "--list",
        action="store_true",
        help="print the request of every case as one JSON line (to script the test model)",
    )
    injection.add_argument(
        "--cases",
        type=Path,
        action="append",
        default=[],
        help="additional case file of the module (papaia.injection-corpus/1, repeatable)",
    )
    injection.add_argument("--pin", type=_digest, help="pinned corpus digest sha256:<hex>")
    injection.add_argument(
        "--subject",
        type=_subject,
        default=INJECTION_SUBJECT,
        help="sub of the test person the module runs every case as",
    )
    injection.add_argument(
        "--allowed-host",
        type=_host,
        action="append",
        default=[],
        help=f"host of the installation (repeatable; default: {', '.join(DEFAULT_ALLOWED_HOSTS)})",
    )
    injection.add_argument(
        "--timeout", type=_admin_timeout, default=60.0, help="seconds per driver reply"
    )
    return injection


def _host(text: str) -> str:
    if len(text) > _MAX_HOST or not _HOST.fullmatch(text):
        raise argparse.ArgumentTypeError("expected a lower-case host name")
    return text


def _subject(text: str) -> str:
    if not _SUBJECT.fullmatch(text):
        raise argparse.ArgumentTypeError("expected a subject of at most 255 characters")
    return text


def _server_parser(suites: Any) -> argparse.ArgumentParser:
    """Arguments of ``conformance server``; ``suites`` is the subparsers action."""
    server: argparse.ArgumentParser = suites.add_parser(
        "server", help="a running MCP server against its declaration (CI, kit test issuer)"
    )
    server.add_argument("manifest", type=Path, help="papaia-app.yaml with the declaration")
    server.add_argument("--id", help="catalog id of the mcp entry (default: the only one)")
    server.add_argument("--url", required=True, help="MCP endpoint of the running server")
    server.add_argument("--issuer", required=True, help="base URL of the kit test issuer")
    server.add_argument("--azp", required=True, help="client released for the server")
    server.add_argument(
        "--role", action="append", default=[], help="module role the tokens carry (repeatable)"
    )
    server.add_argument(
        "--trust", choices=["addon", "platform"], default="addon", help="trust in the catalog"
    )
    server.add_argument(
        "--calls", type=Path, required=True, help='JSON {"calls": {<operation>: <arguments>}}'
    )
    server.add_argument(
        "--audit-file", type=Path, required=True, help="audit rows of the server (JSON lines)"
    )
    server.add_argument("--subject", default=DEFAULT_SUBJECT, help="sub of the test person")
    server.add_argument(
        "--username",
        help="preferred_username of the test person in every token, for servers that map "
        "the person to a backend user by name (default: the value of --subject)",
    )
    server.add_argument("--foreign-azp", default=DEFAULT_FOREIGN_AZP)
    server.add_argument("--foreign-audience", default=DEFAULT_FOREIGN_AUDIENCE)
    server.add_argument("--timeout", type=_admin_timeout, default=10.0, help="seconds per request")
    server.add_argument(
        "--audit-wait",
        type=_admin_timeout,
        default=5.0,
        help="seconds to wait for the audit rows to appear",
    )
    server.add_argument(
        "--record",
        type=Path,
        help="write the run as provider recording to this file (only when every check passes)",
    )
    server.add_argument(
        "--image-digest",
        type=_digest,
        help="digest sha256:<hex> of the provider image under test (required with --record)",
    )
    server.add_argument("--image", type=_image, help="reference of the provider image (optional)")
    return server


def _handover_parser(suites: Any) -> argparse.ArgumentParser:
    """Arguments of ``conformance handover``; ``suites`` is the subparsers action."""
    handover: argparse.ArgumentParser = suites.add_parser(
        "handover", help="digest of the handover schema against Studio's pin and the bill"
    )
    handover.add_argument("schema", type=Path, help="data-handover-1.json (Data's file or a copy)")
    handover.add_argument(
        "--pin", type=_digest, action="append", default=[], help="pinned digest sha256:<hex>"
    )
    handover.add_argument(
        "--pin-file", type=Path, action="append", default=[], help="file with the pinned digest"
    )
    handover.add_argument("--bom", type=Path, help="bill of materials (YAML, contracts:)")
    return handover


def _me_v2_parser(suites: Any) -> argparse.ArgumentParser:
    """Arguments of ``conformance me-v2``; ``suites`` is the subparsers action."""
    me: argparse.ArgumentParser = suites.add_parser(
        "me-v2", help="a running personal-area module API against its declaration (test instance)"
    )
    me.add_argument("declaration", type=Path, help="file with the personal_settings: declaration")
    me.add_argument(
        "--url", required=True, help="module API {base}, e.g. http://127.0.0.1:8080/api/me"
    )
    me.add_argument("--issuer", required=True, help="base URL of the kit test issuer")
    me.add_argument("--audience", required=True, help="audience of the module's me entry")
    me.add_argument("--azp", default=ME_CLIENT, help=f"client of the tokens (default {ME_CLIENT})")
    me.add_argument("--role", action="append", default=[], help="role of the test person")
    me.add_argument("--subject", default=DEFAULT_SUBJECT, help="sub of the test person")
    me.add_argument("--timeout", type=_admin_timeout, default=10.0, help="seconds per request")
    me.add_argument(
        "--record",
        type=Path,
        help="write the run as provider recording to this file (only when every check passes)",
    )
    me.add_argument(
        "--image-digest",
        type=_digest,
        help="digest sha256:<hex> of the provider image under test (required with --record)",
    )
    me.add_argument("--image", type=_image, help="reference of the provider image (optional)")
    return me


def _digest(text: str) -> str:
    if not _DIGEST.fullmatch(text):
        raise argparse.ArgumentTypeError("expected sha256:<64 lower-case hex digits>")
    return text


def _image(text: str) -> str:
    if not _IMAGE.fullmatch(text):
        raise argparse.ArgumentTypeError(
            "expected a lower-case image reference of at most 255 characters"
        )
    return text


def _check_record_args(parser: argparse.ArgumentParser, args: argparse.Namespace) -> None:
    """``--image-digest`` and ``--image`` belong to ``--record``, which needs the digest."""
    if args.record is None and (args.image_digest is not None or args.image is not None):
        parser.error("--image-digest and --image are only allowed with --record")
    if args.record is not None and args.image_digest is None:
        parser.error("--record needs --image-digest sha256:<hex> of the provider image")


def _admin_timeout(text: str) -> float:
    """A finite number of seconds above 0 and at most ``MAX_ADMIN_TIMEOUT``."""
    try:
        value = float(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"not a number: {text[:32]!r}") from None
    if not math.isfinite(value) or not 0 < value <= MAX_ADMIN_TIMEOUT:
        raise argparse.ArgumentTypeError(
            f"expected seconds above 0 and at most {MAX_ADMIN_TIMEOUT:g}"
        )
    return value


def _collect(args: argparse.Namespace, exceptions: Exceptions) -> list[Record]:
    records: list[Record] = []
    if args.python_project:
        records += python_records(args.python_project, exceptions.verified)
    for lock in args.npm_lock:
        records += npm_records(lock)
    for path in args.records:
        records += json_records(path)
    if not (args.python_project or args.npm_lock or args.records):
        raise PolicyError("no input: pass --python-project, --npm-lock or --records")
    return records


def _exceptions_path(args: argparse.Namespace) -> Path | None:
    if args.exceptions:
        return Path(args.exceptions)
    default = Path("license-exceptions.toml")
    return default if default.is_file() else None


def _licenses(args: argparse.Namespace) -> int:
    policy = load_policy(args.policy)
    exceptions = load_exceptions(_exceptions_path(args))
    records = _collect(args, exceptions)
    if args.command == "render":
        incomplete = [r for r in records if r.problem]
        for record in incomplete:
            print(f"  {record.name} {record.version}: {record.problem}", file=sys.stderr)
        if incomplete:
            print("cannot render from an incomplete environment", file=sys.stderr)
            return EXIT_FAIL
        text = render_markdown(records, exceptions, policy)
        if args.check:
            current = args.output.read_text(encoding="utf-8") if args.output.is_file() else ""
            if current != text:
                print(
                    f"{args.output} is out of date; run papaia-kit licenses render", file=sys.stderr
                )
                return EXIT_FAIL
            return EXIT_OK
        args.output.write_text(text, encoding="utf-8")
        return EXIT_OK

    today = datetime.now(UTC).date()
    results = [
        (r, evaluate(r, policy, exceptions, today=today, edition=args.edition)) for r in records
    ]
    if args.report:
        report = {
            "kit_version": __version__,
            "packages": [{**asdict(r), "violation": reason} for r, reason in results],
        }
        args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    failures = [(r, reason) for r, reason in results if reason]
    for record, reason in failures:
        print(
            f"  {record.name} {record.version} ({record.ecosystem}, {record.scope}): {reason}",
            file=sys.stderr,
        )
    if failures:
        print(f"license check failed: {len(failures)} of {len(records)} packages", file=sys.stderr)
        return EXIT_FAIL
    print(f"license check passed: {len(records)} packages")
    return EXIT_OK


def _print_findings(findings: Sequence[Finding], label: str) -> None:
    for finding in findings:
        print(f"  {finding.location}: {finding.message}", file=sys.stderr)
    if findings:
        print(f"{len(findings)} {label}", file=sys.stderr)


def _verdict(clean: bool, message: str) -> int:
    if not clean:
        return EXIT_FAIL
    print(message)
    return EXIT_OK


def _write_words_baseline(args: argparse.Namespace) -> int:
    if args.baseline is None or args.reason is None:
        print("--write-baseline needs --baseline and --reason", file=sys.stderr)
        return EXIT_USAGE
    try:
        check_reason(args.reason)
        entries = write_baseline(args.root, args.baseline, args.reason)
    except BaselineError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    except FileExistsError:
        print(f"error: {args.baseline} already exists; change it by review", file=sys.stderr)
        return EXIT_USAGE
    except OSError as exc:
        print(f"error: {args.baseline}: {exc.strerror}", file=sys.stderr)
        return EXIT_USAGE
    print(f"repo words: wrote {entries} baseline entries to {args.baseline}")
    return EXIT_OK


def _words(args: argparse.Namespace) -> int:
    if args.write_baseline:
        return _write_words_baseline(args)
    if args.reason is not None:
        print("--reason is only used with --write-baseline", file=sys.stderr)
        return EXIT_USAGE
    if args.baseline is None:
        findings = scan_files(args.root)
        _print_findings(findings, "denied term(s)")
        return _verdict(not findings, "repo words: no findings")
    try:
        baseline = load_words_baseline(args.baseline)
    except BaselineError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    result = check_words(args.root, baseline, args.baseline)
    _print_findings(result.failures, "denied term(s) not in the baseline")
    _print_findings(
        result.stale, "stale baseline entr" + ("y" if len(result.stale) == 1 else "ies")
    )
    clean = not (result.failures or result.stale)
    return _verdict(clean, f"repo words: no findings ({result.baselined} baselined)")


def _repo(args: argparse.Namespace) -> int:
    if args.command == "words":
        return _words(args)
    if not valid_range(args.range):
        print(f"invalid revision range {args.range!r}", file=sys.stderr)
        return EXIT_USAGE
    findings = check_commits(args.root, args.range, args.email_domain)
    _print_findings(findings, "commit rule violation(s)")
    if findings:
        return EXIT_FAIL
    print(f"repo {args.command}: no findings")
    return EXIT_OK


def _names(args: argparse.Namespace) -> int:
    if args.command == "list":
        rows = [{**asdict(e), "kind": e.kind.value} for e in entries(args.kind)]
        print(json.dumps(rows, indent=2))
        return EXIT_OK
    if args.command == "scope":
        try:
            print(exchange_scope(args.audience))
        except InvalidName as exc:
            print(f"error: {exc}", file=sys.stderr)
            return EXIT_FAIL
        return EXIT_OK
    failures: list[InvalidName] = []
    for name in args.name:
        try:
            validate(name, args.kind)
        except InvalidName as exc:
            failures.append(exc)
    for failure in failures:
        print(f"  {failure}", file=sys.stderr)
    if failures:
        print(f"{len(failures)} of {len(args.name)} name(s) invalid", file=sys.stderr)
        return EXIT_FAIL
    print(f"names check: {len(args.name)} name(s) valid")
    return EXIT_OK


def _report(result: SuiteResult, junit: Path | None) -> int:
    if junit is not None:
        junit.write_bytes(junit_xml([result]))
    for item in result.failed:
        for failure in item.failures:
            print(f"  FAIL {item.group} {item.name}: {failure}", file=sys.stderr)
    print(f"conformance {result.name}: {len(result.cases)} checks, {len(result.failed)} failed")
    return EXIT_OK if result.ok else EXIT_FAIL


def _admin_token(path: Path | None) -> str:
    if path is None:
        token = os.environ.get(ADMIN_TOKEN_ENV, "")
        if not token:
            raise RealmError(f"no admin token: pass --token-file or set {ADMIN_TOKEN_ENV}")
        return token.strip()
    try:
        with path.open("rb") as handle:
            raw = handle.read(_MAX_TOKEN_FILE + 1)
    except OSError as exc:
        raise RealmError(f"cannot read the token file: {exc.strerror}") from None
    if len(raw) > _MAX_TOKEN_FILE:
        raise RealmError("token file is too large")
    try:
        return raw.decode("ascii").strip()
    except UnicodeDecodeError:
        raise RealmError("token file is not ASCII") from None


def _realm(args: argparse.Namespace) -> int:
    if args.export is not None:
        try:
            realm = load_realm_export(args.export)
        except RealmError:
            return _report(check_realm_export_file(args.export), args.junit)
    else:
        try:
            realm = read_realm_admin(
                args.admin_url,
                args.realm,
                _admin_token(args.token_file),
                fetch=UrllibFetch(),
                timeout=args.timeout,
            )
        except RealmError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return EXIT_USAGE
    # The intersection is the evidence of the separation rule (RE-01); names only.
    shared = sorted(exchange_clients(realm) & audiences(realm).keys())
    print(
        f"realm {realm.name}: exchange clients and audiences intersect in {{{', '.join(shared)}}}"
    )
    return _report(check_realm(realm, source=realm.name), args.junit)


def _server(args: argparse.Namespace) -> int:
    try:
        entry = select_entry(load_manifest(args.manifest), args.id)
        target = ServerTarget(
            url=args.url,
            entry=entry,
            tokens=IssuerTokens(args.issuer, timeout=args.timeout),
            azp=args.azp,
            roles=tuple(args.role),
            calls=load_calls(args.calls, entry),
            audit_file=args.audit_file,
            trust=args.trust,
            subject=args.subject,
            username=args.username,
            foreign_azp=args.foreign_azp,
            foreign_audience=args.foreign_audience,
            timeout=args.timeout,
            audit_wait=args.audit_wait,
        )
        provider = (
            Provider(image_digest=args.image_digest, image=args.image)
            if args.record is not None
            else None
        )
    except (ManifestError, ServerSuiteError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    if provider is None:
        return _report(run_server_suite(target), args.junit)
    result, data = record_server_suite(target, provider)
    return _write_recording(args.record, data, _report(result, args.junit))


def _me_v2(args: argparse.Namespace) -> int:
    try:
        target = MeTarget(
            url=args.url,
            declaration=load_me_declaration(args.declaration),
            tokens=IssuerTokens(args.issuer, timeout=args.timeout),
            audience=args.audience,
            azp=args.azp,
            subject=args.subject,
            roles=tuple(args.role),
            timeout=args.timeout,
        )
        provider = (
            Provider(image_digest=args.image_digest, image=args.image)
            if args.record is not None
            else None
        )
    except (MeV2SuiteError, ServerSuiteError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    if provider is None:
        return _report(run_me_v2_suite(target), args.junit)
    result, data = record_me_v2_suite(target, provider)
    return _write_recording(args.record, data, _report(result, args.junit))


def _handover(args: argparse.Namespace) -> int:
    try:
        pins = [("--pin", value) for value in args.pin]
        pins += [(str(path), load_pin_file(path)) for path in args.pin_file]
        result = run_handover_suite(args.schema, pins=pins, bom=args.bom)
    except HandoverError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    for name, value in result.properties:
        if name == "digest":
            print(f"handover digest: {args.schema.name} {value}")
    return _report(result, args.junit)


def _write_recording(path: Path, data: bytes | None, code: int) -> int:
    """Write a recording of a passing run; remove an earlier file when there is none."""
    if data is None:
        # A file of an earlier run must not pass for the result of this one.
        return _remove_stale(path) or code
    try:
        _write_atomic(path, data)
    except OSError as exc:
        print(f"error: cannot write the recording: {exc.strerror}", file=sys.stderr)
        return _remove_stale(path) or EXIT_FAIL
    print(f"recording written: {path} ({recording_digest(load_recording(data))})")
    return code


def _remove_stale(path: Path) -> int:
    """Remove a recording an earlier run left at ``path``; ``EXIT_FAIL`` when that fails."""
    if not (path.is_file() or path.is_symlink()):
        return EXIT_OK
    try:
        path.unlink()
    except OSError as exc:
        print(f"error: cannot remove the earlier {path}: {exc.strerror}", file=sys.stderr)
        return EXIT_FAIL
    print(f"recording not written; removed the earlier {path}", file=sys.stderr)
    return EXIT_OK


def _write_atomic(path: Path, data: bytes) -> None:
    """``data`` to ``path`` through a temporary file in the same directory and a rename."""
    handle = tempfile.NamedTemporaryFile(  # noqa: SIM115 - closed before the rename
        dir=path.parent, prefix=f".{path.name}.", suffix=".tmp", delete=False
    )
    try:
        with handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        Path(handle.name).replace(path)
    except BaseException:
        Path(handle.name).unlink(missing_ok=True)
        raise


def _injection(args: argparse.Namespace) -> int:
    try:
        corpus = load_corpus(args.cases)
    except CorpusError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    context = Context(args.subject, tuple(args.allowed_host) or DEFAULT_ALLOWED_HOSTS)
    print(
        f"injection corpus: version {corpus.version}, {len(corpus.cases)} cases, {corpus.digest}",
        file=sys.stderr if args.list else sys.stdout,
    )
    if args.pin is not None and args.pin != corpus.digest:
        print(f"error: corpus digest {corpus.digest} is not the pinned {args.pin}", file=sys.stderr)
        return EXIT_FAIL
    if args.list:
        for item in corpus.cases:
            print(json.dumps(item.request(context), ensure_ascii=False, sort_keys=True))
        return EXIT_OK
    try:
        driver = InjectionCommandDriver(shlex.split(args.driver), timeout=args.timeout)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    return _report(run_injection(driver, corpus, context=context), args.junit)


def _static(args: argparse.Namespace) -> int:
    default = args.root / "static-exceptions.toml"
    listed = args.exceptions or (default if default.is_file() else None)
    try:
        result = run_static(
            args.path,
            root=args.root,
            exceptions=load_static_exceptions(listed, require_approved=args.require_approved),
            include_dirs=args.include_dir,
        )
    except (ValueError, StaticExceptionError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    counts = ", ".join(f"{k.removeprefix('skipped.')} {v}" for k, v in result.properties)
    print(f"conformance static: files not read, skipped: {counts}", file=sys.stderr)
    return _report(result, args.junit)


def _model(args: argparse.Namespace) -> int:
    try:
        needs = load_model_needs(load_manifest(args.manifest), args.id)
    except (ManifestError, ModelSuiteError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    return _report(check_model_recording_file(args.recording, needs), args.junit)


def _conformance(args: argparse.Namespace) -> int:
    handlers = {
        "injection": _injection,
        "realm": _realm,
        "server": _server,
        "static": _static,
        "me-v2": _me_v2,
        "handover": _handover,
        "model": _model,
    }
    if (handler := handlers.get(args.command)) is not None:
        return handler(args)
    if args.command == "manifest":
        try:
            result = check_manifest_files(
                args.manifest, compose=args.compose, core_profile=args.core_profile
            )
        except (ValueError, ManifestError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return EXIT_USAGE
        prefix = f"{HEADER_IDENTITY_PROPERTY}."
        for name, ids in result.properties:
            if name.startswith(prefix):
                print(f"conformance manifest: header identity: {name.removeprefix(prefix)}: {ids}")
    elif args.command == "catalog-consumer":
        if args.driver is not None:
            try:
                driver = CommandDriver(shlex.split(args.driver), timeout=args.timeout)
            except ValueError as exc:
                print(f"error: {exc}", file=sys.stderr)
                return EXIT_USAGE
            result = run_catalog_consumer(driver)
        else:
            result = run_catalog_consumer(KitReaderDriver)
    else:
        try:
            problems = check_recording_file(args.recording, pin=args.pin)
        except ValueError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return EXIT_USAGE
        name = "recording"
        result = SuiteResult(name, (case(name, args.recording.name, "recording", problems),))
    return _report(result, args.junit)


def _tokens(args: argparse.Namespace) -> int:
    source = tokens_dir()
    try:
        tokens = load_tokens(args.tokens or source / "papaia.tokens.json")
        results = check_contrast(tokens, load_pairs(args.pairs or source / "contrast-pairs.yaml"))
    except (TokenError, ContrastPairError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    print(contrast_report(results))
    return EXIT_OK if all(r.ok for r in results) else EXIT_FAIL


def _messages(args: argparse.Namespace) -> int:
    try:
        findings = check_message_dir(args.dir)
    except MessageError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    for finding in findings:
        print(f"{finding.location}: {finding.pattern}: {finding.detail}")
    if findings:
        return EXIT_FAIL
    print("messages: no forbidden pattern, languages agree")
    return EXIT_OK


def _assertion(args: argparse.Namespace) -> int:
    shipped = vectors_path()
    if args.compare is None:
        print(shipped)
        return EXIT_OK
    try:
        copy = args.compare.read_bytes()
    except OSError as exc:
        print(f"error: cannot read {args.compare}: {exc.strerror}", file=sys.stderr)
        return EXIT_USAGE
    if copy != shipped.read_bytes():
        print(
            f"{args.compare} differs from {shipped.name} of papaia-kit {__version__}",
            file=sys.stderr,
        )
        return EXIT_FAIL
    print(f"{args.compare} equals {shipped.name} of papaia-kit {__version__}")
    return EXIT_OK


def main(argv: Sequence[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    if args.group == "conformance" and args.command in ("server", "me-v2"):
        _check_record_args(parser, args)
    handlers = {
        "licenses": _licenses,
        "repo": _repo,
        "names": _names,
        "assertion": _assertion,
        "conformance": _conformance,
        "words": words_cli.run,
        "tokens": _tokens,
        "shell": shell_cli.run,
        "pages": pages_cli.run,
        "messages": _messages,
    }
    try:
        return handlers[args.group](args)
    except EnvironmentMismatch as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_FAIL
    except PolicyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    except subprocess.CalledProcessError as exc:
        print(f"error: {' '.join(exc.cmd)} failed: {exc.stderr}", file=sys.stderr)
        return EXIT_USAGE


def words_main(argv: Sequence[str] | None = None) -> int:
    """Entry point ``pk-words``: the same as ``papaia-kit words``."""
    return main(["words", *(sys.argv[1:] if argv is None else argv)])


if __name__ == "__main__":
    sys.exit(main())
