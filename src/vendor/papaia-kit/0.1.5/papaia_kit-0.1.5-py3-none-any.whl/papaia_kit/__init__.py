"""Shared contract package of the papaia platform.

Every module, add-on and server reads the contract (schemas, names, error
classes, audit format) from this package instead of keeping its own copy.
"""

from papaia_kit._resources import (
    contract_dir,
    glossary_dir,
    injection_dir,
    policy_dir,
    schemas_dir,
    tokens_dir,
    ui_dist_dir,
    vectors_dir,
)

__version__ = "0.1.5"

__all__ = [
    "__version__",
    "contract_dir",
    "glossary_dir",
    "injection_dir",
    "policy_dir",
    "schemas_dir",
    "tokens_dir",
    "ui_dist_dir",
    "vectors_dir",
]
