"""Loading and validation of the license policy and a repository's exception list."""

from __future__ import annotations

import re
import tomllib
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from papaia_kit._resources import policy_dir

CLASSES = (
    "permissive",
    "fonts",
    "attribution",
    "weak",
    "strong",
    "network",
    "restricted",
    "proprietary",
)
UNKNOWN = "unknown"
SCOPES = ("runtime", "build", "test", "service")
_CONDITIONAL_KEYS = ("allow_with_exception", "allow_with_obligations", "allow_with_owner_approval")
_SCOPE_KEYS = ("allow", "deny", *_CONDITIONAL_KEYS)
_EDITION_KEYS = ("service_allow", "runtime_allow", "runtime_allow_with_exception")
_MAX_TEXT = 500


class PolicyError(ValueError):
    """A policy, exception list or input file is invalid."""


@dataclass(frozen=True)
class ScopeRule:
    allow: frozenset[str]
    conditional: frozenset[str]  # passes only with an exception entry
    deny: frozenset[str]

    def decision(self, license_class: str) -> str:
        if license_class in self.allow:
            return "allow"
        if license_class in self.conditional:
            return "conditional"
        return "deny"


@dataclass(frozen=True)
class Policy:
    version: int
    classes: Mapping[str, str]  # upper-case SPDX expression -> class
    spdx_ids: Mapping[str, str]  # upper-case -> canonical spelling
    scopes: Mapping[str, ScopeRule]
    editions: Mapping[str, Mapping[str, ScopeRule]]

    def class_of(self, spdx: str) -> str:
        return self.classes.get(spdx.upper(), UNKNOWN)

    def canonical(self, spdx: str) -> str:
        return self.spdx_ids.get(spdx.upper(), spdx)

    def rules(self, edition: str | None = None) -> Mapping[str, ScopeRule]:
        if edition is None:
            return self.scopes
        if edition not in self.editions:
            raise PolicyError(f"unknown edition {edition!r}")
        return {**self.scopes, **self.editions[edition]}


@dataclass(frozen=True)
class ExceptionEntry:
    package: str
    version: str
    license: str
    scope: str
    reason: str
    adr: str
    expires: date
    approved_by: str


@dataclass(frozen=True)
class VerifiedEntry:
    package: str
    version: str
    license: str
    source: str


@dataclass(frozen=True)
class Exceptions:
    exceptions: tuple[ExceptionEntry, ...]
    verified: tuple[VerifiedEntry, ...]


def normalise_name(name: str) -> str:
    """Package names compare like the Python packaging rules (PEP 503)."""
    return re.sub(r"[-_.]+", "-", name).lower()


def _reject_unknown(table: Mapping[str, Any], allowed: tuple[str, ...], where: str) -> None:
    unknown = sorted(set(table) - set(allowed))
    if unknown:
        raise PolicyError(f"{where}: unknown key(s) {', '.join(unknown)}")


def _string_list(value: Any, where: str) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(v, str) and v for v in value):
        raise PolicyError(f"{where}: expected a list of non-empty strings")
    return value


def _class_list(value: Any, where: str) -> frozenset[str]:
    names = _string_list(value, where)
    bad = sorted(set(names) - {*CLASSES, UNKNOWN})
    if bad:
        raise PolicyError(f"{where}: unknown class(es) {', '.join(bad)}")
    return frozenset(names)


def _scope_rule(table: Any, where: str) -> ScopeRule:
    if not isinstance(table, dict):
        raise PolicyError(f"{where}: expected a table")
    _reject_unknown(table, _SCOPE_KEYS, where)
    allow = _class_list(table.get("allow", []), f"{where}.allow")
    deny = _class_list(table.get("deny", []), f"{where}.deny")
    conditional: frozenset[str] = frozenset()
    for key in _CONDITIONAL_KEYS:
        conditional |= _class_list(table.get(key, []), f"{where}.{key}")
    if allow & deny or allow & conditional or deny & conditional:
        raise PolicyError(f"{where}: a class is listed under more than one decision")
    return ScopeRule(allow=allow, conditional=conditional, deny=deny)


def _edition(table: Any, where: str) -> dict[str, ScopeRule]:
    if not isinstance(table, dict):
        raise PolicyError(f"{where}: expected a table")
    _reject_unknown(table, _EDITION_KEYS, where)
    runtime_allow = _class_list(table.get("runtime_allow", []), f"{where}.runtime_allow")
    runtime_cond = _class_list(
        table.get("runtime_allow_with_exception", []), f"{where}.runtime_allow_with_exception"
    )
    service_allow = _class_list(table.get("service_allow", []), f"{where}.service_allow")
    everything = frozenset({*CLASSES, UNKNOWN})
    return {
        "runtime": ScopeRule(
            runtime_allow, runtime_cond, everything - runtime_allow - runtime_cond
        ),
        "service": ScopeRule(service_allow, frozenset(), everything - service_allow),
    }


def load_policy(path: Path | None = None) -> Policy:
    """Load the license policy; without a path the policy shipped with the kit."""
    path = path or policy_dir() / "license-policy.toml"
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise PolicyError(f"{path}: {exc}") from exc
    where = str(path)
    _reject_unknown(data, ("version", "classes", "scope", "standalone"), where)
    if data.get("version") != 1:
        raise PolicyError(f"{where}: unsupported policy version {data.get('version')!r}")
    raw_classes = data.get("classes", {})
    _reject_unknown(raw_classes, CLASSES, f"{where}: classes")
    classes: dict[str, str] = {}
    spdx_ids: dict[str, str] = {}
    for cls, members in raw_classes.items():
        for spdx in _string_list(members, f"{where}: classes.{cls}"):
            key = spdx.upper()
            if key in classes:
                raise PolicyError(f"{where}: {spdx} is listed in more than one class")
            classes[key] = cls
            spdx_ids[key] = spdx
    raw_scopes = data.get("scope", {})
    _reject_unknown(raw_scopes, SCOPES, f"{where}: scope")
    scopes = {
        name: _scope_rule(raw_scopes.get(name, {}), f"{where}: scope.{name}") for name in SCOPES
    }
    editions = {
        name: _edition(table, f"{where}: standalone.{name}")
        for name, table in data.get("standalone", {}).items()
    }
    return Policy(1, classes, spdx_ids, scopes, editions)


def _text(entry: Mapping[str, Any], key: str, where: str) -> str:
    value = entry.get(key)
    if not isinstance(value, str) or not value.strip() or len(value) > _MAX_TEXT:
        raise PolicyError(f"{where}: {key} must be a non-empty string of at most {_MAX_TEXT}")
    return value.strip()


def _entries(data: Mapping[str, Any], key: str, where: str) -> list[Mapping[str, Any]]:
    entries = data.get(key, [])
    if not isinstance(entries, list) or not all(isinstance(e, dict) for e in entries):
        raise PolicyError(f"{where}: [[{key}]] must be an array of tables")
    return entries


def load_exceptions(path: Path | None) -> Exceptions:
    """Load a repository's ``license-exceptions.toml``; no path means no exceptions."""
    if path is None:
        return Exceptions((), ())
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise PolicyError(f"{path}: {exc}") from exc
    where = str(path)
    _reject_unknown(data, ("version", "exception", "verified"), where)
    if data.get("version") != 1:
        raise PolicyError(f"{where}: unsupported version {data.get('version')!r}")
    exceptions = []
    exception_keys = tuple(ExceptionEntry.__dataclass_fields__)
    for i, entry in enumerate(_entries(data, "exception", where)):
        at = f"{where}: exception[{i}]"
        _reject_unknown(entry, exception_keys, at)
        expires = entry.get("expires")
        if not isinstance(expires, date):
            raise PolicyError(f"{at}: expires must be a date (YYYY-MM-DD)")
        scope = _text(entry, "scope", at)
        if scope not in SCOPES:
            raise PolicyError(f"{at}: unknown scope {scope!r}")
        exceptions.append(
            ExceptionEntry(
                package=normalise_name(_text(entry, "package", at)),
                version=_text(entry, "version", at),
                license=_text(entry, "license", at),
                scope=scope,
                reason=_text(entry, "reason", at),
                adr=_text(entry, "adr", at),
                expires=expires,
                approved_by=_text(entry, "approved_by", at),
            )
        )
    verified = []
    for i, entry in enumerate(_entries(data, "verified", where)):
        at = f"{where}: verified[{i}]"
        _reject_unknown(entry, tuple(VerifiedEntry.__dataclass_fields__), at)
        source = _text(entry, "source", at)
        if urlparse(source).scheme != "https":
            raise PolicyError(f"{at}: source must be the https URL where the license was checked")
        verified.append(
            VerifiedEntry(
                package=normalise_name(_text(entry, "package", at)),
                version=_text(entry, "version", at),
                license=_text(entry, "license", at),
                source=source,
            )
        )
    return Exceptions(tuple(exceptions), tuple(verified))
