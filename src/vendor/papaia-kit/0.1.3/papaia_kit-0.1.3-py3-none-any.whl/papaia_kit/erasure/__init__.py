"""Erasure journal writer: the single writer of the erasure journal.

Every module with personal data writes one journal through this package
(sicherheit §4.9, RE-06): one JSON line per deletion or delivery at
``<backup target>/erasure-journal/<module>.jsonl``, a local copy in the volume
``papaia-erasure`` and an optional mirror. Lines carry references only:
``subject_ref`` is ``HMAC-SHA256(erasure-hmac, sub)``, ``object_ref`` names
the object. After a restore, :func:`replay` applies the journal again; only
``papaia-ctl restore``, ``rollback``, ``recover-snapshot`` and the core start
gate call it. Every journal write and every replay is audited as a
``papaia.audit/1`` row without content.
"""

from papaia_kit.erasure._audit import AuditSink, erasure_replayed_event, replay_detail
from papaia_kit.erasure._entry import (
    CORE_SOURCES,
    JOURNAL_SCHEMA,
    ErasureKey,
    JournalConflictError,
    JournalCorruptError,
    JournalEntry,
    JournalError,
    JournalGapError,
    JournalUnavailableError,
    Kind,
    kinds_for,
)
from papaia_kit.erasure._epoch import (
    EPOCH_FILE,
    EPOCH_FORMAT,
    EPOCH_SCHEMA,
    STATE_EPOCH_BEHIND_MESSAGE,
    Epoch,
    EpochState,
    ModuleNotReadyError,
    StartGate,
    StateEpochCheck,
    check_state_epoch,
    read_epoch,
    write_epoch,
)
from papaia_kit.erasure._journal import (
    ErasureJournal,
    JournalRead,
    JournalStatus,
    PlaceState,
    read_journal,
)
from papaia_kit.erasure._lifecycle import (
    LifecycleAction,
    LifecycleHandler,
    LifecycleRequestError,
    LifecycleResponse,
    parse_lifecycle_request,
)
from papaia_kit.erasure._replay import ReplayError, ReplayResult, ReplayTrigger, replay

__all__ = [
    "CORE_SOURCES",
    "EPOCH_FILE",
    "EPOCH_FORMAT",
    "EPOCH_SCHEMA",
    "JOURNAL_SCHEMA",
    "STATE_EPOCH_BEHIND_MESSAGE",
    "AuditSink",
    "Epoch",
    "EpochState",
    "ErasureJournal",
    "ErasureKey",
    "JournalConflictError",
    "JournalCorruptError",
    "JournalEntry",
    "JournalError",
    "JournalGapError",
    "JournalRead",
    "JournalStatus",
    "JournalUnavailableError",
    "Kind",
    "LifecycleAction",
    "LifecycleHandler",
    "LifecycleRequestError",
    "LifecycleResponse",
    "ModuleNotReadyError",
    "PlaceState",
    "ReplayError",
    "ReplayResult",
    "ReplayTrigger",
    "StartGate",
    "StateEpochCheck",
    "check_state_epoch",
    "erasure_replayed_event",
    "kinds_for",
    "parse_lifecycle_request",
    "read_epoch",
    "read_journal",
    "replay",
    "replay_detail",
    "write_epoch",
]
