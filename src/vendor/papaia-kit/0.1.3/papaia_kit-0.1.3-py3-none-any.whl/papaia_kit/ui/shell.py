"""The shell every module renders server-side: input check, context and HTML.

The markup contract is ``contract/shell/shell.md`` (interface spec 2.1-2.3 and
3.4). A module renders its HTML document with :func:`render_shell` or with the
Jinja2 macro ``shell`` from ``pk/shell.html`` and :func:`shell_context`; both
produce the same markup. Every input passes :func:`parse_shell_input` first:
the input schema rejects unknown fields and unsafe links, the catalog reader
checks the embedded catalog.

The shell is display only. Hiding a module in the switcher grants or withholds
nothing; every module checks rights server-side on every request.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from functools import cache
from pathlib import Path
from typing import Any

import jinja2
import yaml
from jsonschema import Draft202012Validator
from markupsafe import Markup

from papaia_kit import __version__
from papaia_kit._resources import contract_dir
from papaia_kit.catalog import Catalog, CatalogError, Surface, parse_services, visible_modules

__all__ = [
    "ASSET_ROOT",
    "INPUT_FORMAT",
    "LOGO_PATH",
    "MAX_INPUT_BYTES",
    "ShellInput",
    "ShellInputError",
    "kit_loader",
    "parse_shell_input",
    "render_shell",
    "shell_context",
    "shell_environment",
    "shell_texts",
]

INPUT_FORMAT = "papaia.shell-input/1"
ASSET_ROOT = f"/_kit/{__version__}"
LOGO_PATH = "/_kit/brand/logo"
MAX_INPUT_BYTES = 1024 * 1024
LANGUAGES = ("de", "en")
LANGUAGE_NAMES = {"de": "Deutsch", "en": "English"}
TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"
_DOCUMENT = '{% from "pk/shell.html" import shell %}{% call shell(pk) %}{{ content }}{% endcall %}'


class ShellInputError(ValueError):
    """The shell input breaks the contract; ``problems`` names each place."""

    def __init__(self, problems: list[str] | tuple[str, ...]) -> None:
        self.problems = tuple(problems)
        super().__init__("; ".join(self.problems) or "invalid shell input")


@dataclass(frozen=True)
class ShellInput:
    """A checked shell input. ``catalog`` is ``None`` for a module without platform."""

    document: Mapping[str, Any]
    catalog: Catalog | None
    branding: Mapping[str, Any]


def parse_shell_input(data: object) -> ShellInput:
    """Check a shell input (decoded JSON object or JSON bytes) and return it."""
    document = _decode(data) if isinstance(data, bytes | bytearray) else data
    if not isinstance(document, Mapping):
        raise ShellInputError(["input: expected a JSON object"])
    problems = [
        f"{_where(error.absolute_path)}: {error.message}"
        for error in sorted(_validator().iter_errors(document), key=lambda e: list(e.path))
    ]
    if problems:
        raise ShellInputError(problems)
    catalog = None
    if document["catalog"] is not None:
        try:
            catalog = parse_services(json.dumps(document["catalog"]).encode("utf-8"))
        except CatalogError as exc:
            raise ShellInputError([f"catalog/{p}" for p in exc.problems]) from None
    branding = (catalog.branding if catalog else None) or document.get("branding")
    if branding is None:
        raise ShellInputError(["branding: required when the catalog carries none"])
    problems = _links(document, catalog)
    if problems:
        raise ShellInputError(problems)
    return ShellInput(document=document, catalog=catalog, branding=branding)


def shell_texts(lang: str) -> dict[str, str]:
    """Fixed shell texts of ``lang`` from ``contract/messages/shell.<lang>.yaml``."""
    if lang not in LANGUAGES:
        raise ValueError(f"unsupported language {lang!r}")
    return dict(_texts(lang))


def kit_loader() -> jinja2.BaseLoader:
    """Loader for the kit templates (``pk/shell.html``), to combine with a module's own."""
    return jinja2.FileSystemLoader(TEMPLATE_DIR)


def shell_environment(loader: jinja2.BaseLoader | None = None) -> jinja2.Environment:
    """Autoescaping environment with the kit templates (and ``loader`` first, if given)."""
    loaders = [loader, kit_loader()] if loader is not None else [kit_loader()]
    return jinja2.Environment(
        loader=jinja2.ChoiceLoader(loaders),
        autoescape=True,
        undefined=jinja2.StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
        keep_trailing_newline=True,
    )


def render_shell(shell_input: ShellInput, content: Markup | str = "") -> str:
    """The HTML document of a page; ``content`` goes into ``main`` (a plain str is escaped)."""
    return _document().render(pk=shell_context(shell_input), content=content)


def shell_context(shell_input: ShellInput) -> dict[str, Any]:
    """Everything the ``shell`` macro renders, derived from a checked input."""
    doc, catalog = shell_input.document, shell_input.catalog
    lang: str = doc["locale"]
    texts = _texts(lang)
    module = _module(doc, catalog, lang)
    sprite = f"{ASSET_ROOT}/icons/sprite.svg"
    branding = shell_input.branding
    me = catalog.surface("me") if catalog else None
    installation: str = branding["name"]
    page = doc["page"]
    theme = doc["theme"]
    dark = theme == "dark"
    collapsed = doc["sidebar"] == "collapsed"
    return {
        "lang": lang,
        "theme": None if theme == "system" else theme,
        "title": f"{page['title']} – {module['title']} – {installation}",
        "kit_version": __version__,
        "css": f"{ASSET_ROOT}/css/papaia-kit.css",
        "js": f"{ASSET_ROOT}/js/shell.js",
        "sprite": sprite,
        "texts": texts,
        "csrf": doc["csrf_token"],
        "sidebar": doc["sidebar"],
        "module": module,
        "brand": {
            "name": installation,
            "suffix": branding.get("suffix"),
            "logo": _logo(branding),
            "href": me.public_url if me else "/",
            "label": texts["brand_label"].format(name=installation),
        },
        "switcher": _switcher(doc, catalog, module, lang, texts),
        "nav": _nav(doc, catalog, lang, texts),
        "footer": {
            "sidebar": {
                "value": "pinned" if collapsed else "collapsed",
                "label": texts["sidebar_expand" if collapsed else "sidebar_collapse"],
                "icon": "sidebar-expand" if collapsed else "sidebar-collapse",
            },
            "appearance": {
                "value": "light" if dark else "dark",
                "label": texts["appearance_light" if dark else "appearance_dark"],
                "icon": "sun" if dark else "moon",
            },
        },
        "account": _account(doc, catalog, me, lang, texts),
        "header": _header(doc, catalog, lang, texts),
        "notices": [
            {"level": n["level"], "text": n["text"][lang]}
            for n in (catalog.data.get("platform_notices", ()) if catalog else ())
        ],
    }


# --- context parts ----------------------------------------------------------------------


def _module(doc: Mapping[str, Any], catalog: Catalog | None, lang: str) -> dict[str, str]:
    given = doc["module"]
    surface = catalog.surface(given["id"]) if catalog else None
    title = surface.title if surface else given["title"]
    return {
        "id": given["id"],
        "title": title[lang],
        "icon": surface.icon if surface else given["icon"],
    }


def _logo(branding: Mapping[str, Any]) -> str | None:
    digest = branding.get("logo_sha256")
    if not digest:
        return None
    return f"{LOGO_PATH}?v={str(digest).removeprefix('sha256:')}"


def _switcher(
    doc: Mapping[str, Any],
    catalog: Catalog | None,
    module: Mapping[str, str],
    lang: str,
    texts: Mapping[str, str],
) -> dict[str, Any] | None:
    if catalog is None:
        return None
    entries = [
        {
            "title": s.title[lang],
            "icon": s.icon,
            "href": s.public_url,
            "new_tab": s.opens_in == "new_tab",
            "current": s.id == module["id"],
        }
        for s in visible_modules(catalog, doc["person"]["roles"])
    ]
    return {
        "label": texts["switcher_label"].format(module=module["title"]),
        "entries": entries,
    }


def _nav(
    doc: Mapping[str, Any], catalog: Catalog | None, lang: str, texts: Mapping[str, str]
) -> dict[str, Any]:
    current = doc["nav"]["current"]
    groups = []
    for index, group in enumerate(doc["nav"]["groups"], start=1):
        items = []
        for item in group["items"]:
            other = _surface(catalog, item.get("module"))
            items.append(
                {
                    "label": item["label"],
                    "href": item["href"],
                    "current": item["href"] == current,
                    "icon": other.icon if other else None,
                    "suffix": texts["in_module"].format(module=other.title[lang])
                    if other
                    else None,
                }
            )
        groups.append({"id": f"pk-nav-g{index}", "label": group["label"], "rows": items})
    return {
        "overview": {"label": texts["overview"], "href": "/", "current": current == "/"},
        "groups": groups,
    }


def _account(
    doc: Mapping[str, Any],
    catalog: Catalog | None,
    me: Surface | None,
    lang: str,
    texts: Mapping[str, str],
) -> dict[str, Any]:
    setting = doc.get("language_setting", "browser")
    options = [
        {
            "value": "browser",
            "label": texts["language_browser"].format(language=LANGUAGE_NAMES[lang]),
        },
        {"value": "de", "label": texts["language_de"]},
        {"value": "en", "label": texts["language_en"]},
    ]
    for option in options:
        option["current"] = option["value"] == setting
    # Without a platform the module links its own page; with a platform but
    # without "me" the entry is left out (interface spec 2.2, 2.3).
    my_area = me.public_url if me else ("/me" if catalog is None else None)
    return {
        "label": texts["account_label"].format(name=doc["person"]["display_name"]),
        "options": options,
        "my_area": my_area,
    }


def _header(
    doc: Mapping[str, Any], catalog: Catalog | None, lang: str, texts: Mapping[str, str]
) -> dict[str, Any]:
    page = doc["page"]
    crumbs: list[dict[str, str | None]] = []
    back = page.get("back")
    if back:
        surface = _surface(catalog, back["module"])
        if surface is None:  # parse_shell_input rejects this; never render a dangling link
            raise ShellInputError(["page/back/module: not a module of the catalog"])
        crumbs.append(
            {"label": texts["back_to"].format(module=surface.title[lang]), "href": back["href"]}
        )
    crumbs += [{"label": c["label"], "href": c.get("href")} for c in page.get("breadcrumb", ())]
    return {"h1": page["title"], "crumbs": crumbs, "primary": page.get("primary_action")}


# --- checks beyond the schema -----------------------------------------------------------


def _links(doc: Mapping[str, Any], catalog: Catalog | None) -> list[str]:
    problems: list[str] = []
    back = doc["page"].get("back")
    if back:
        surface = _surface(catalog, back["module"])
        if surface is None:
            problems.append("page/back/module: not a module of the catalog")
        elif not _below(back["href"], surface.public_url):
            problems.append("page/back/href: not below the public_url of that module")
    for g, group in enumerate(doc["nav"]["groups"]):
        for i, item in enumerate(group["items"]):
            if "module" in item and _surface(catalog, item["module"]) is None:
                problems.append(f"nav/groups/{g}/items/{i}/module: not a module of the catalog")
    return problems


def _below(href: str, public_url: str) -> bool:
    base = public_url if public_url.endswith("/") else public_url + "/"
    return href == base.rstrip("/") or href.startswith(base)


def _surface(catalog: Catalog | None, surface_id: str | None) -> Surface | None:
    if catalog is None or surface_id is None:
        return None
    return catalog.surface(surface_id)


# --- loading ----------------------------------------------------------------------------


def _decode(data: bytes | bytearray) -> object:
    if len(data) > MAX_INPUT_BYTES:
        raise ShellInputError([f"input: too large (more than {MAX_INPUT_BYTES} bytes)"])
    try:
        return json.loads(
            bytes(data).decode("utf-8"),
            object_pairs_hook=_unique_members,
            parse_constant=_reject_constant,
        )
    except (UnicodeDecodeError, ValueError) as exc:
        raise ShellInputError([f"input: not valid JSON ({exc})"]) from None


def _unique_members(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate member {key!r}")
        result[key] = value
    return result


def _reject_constant(name: str) -> Any:
    raise ValueError(f"{name} is not JSON")


def _where(path: Any) -> str:
    parts = [str(p) for p in path]
    return "/".join(parts) if parts else "input"


@cache
def _validator() -> Draft202012Validator:
    schema = json.loads((contract_dir() / "shell" / "input.schema.json").read_text("utf-8"))
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema)


@cache
def _texts(lang: str) -> Mapping[str, str]:
    path = contract_dir() / "messages" / f"shell.{lang}.yaml"
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if (
        not isinstance(raw, dict)
        or raw.get("lang") != lang
        or not isinstance(raw.get("texts"), dict)
    ):
        raise ValueError(f"{path.name}: expected lang {lang!r} and a texts mapping")
    texts = raw["texts"]
    if not all(isinstance(k, str) and isinstance(v, str) for k, v in texts.items()):
        raise ValueError(f"{path.name}: every text is a string")
    return dict(texts)


@cache
def _document() -> jinja2.Template:
    return shell_environment().from_string(_DOCUMENT)
