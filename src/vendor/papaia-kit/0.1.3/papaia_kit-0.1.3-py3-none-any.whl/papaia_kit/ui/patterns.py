"""The nine patterns (``contract/patterns/``): states, mandatory markup and fixed texts.

``patterns.yaml`` lists per pattern its states, the elements each state must
contain and the fixed texts it shows; ``examples/<id>.<lang>.html`` holds the
example markup, one ``<section data-pk-example="<state>">`` per state.
``check_example`` compares parsed markup against a state, so the examples
and any module page that renders a pattern are checked the same way.
"""

from __future__ import annotations

import functools
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Any

import yaml

from papaia_kit._resources import contract_dir
from papaia_kit.ui import messages

PATTERN_COUNT = 9
MAX_EXAMPLE_BYTES = 256 * 1024
_ID = re.compile(r"^[a-z][a-z0-9_]{0,31}$")
_TAG = re.compile(r"^[a-z][a-z0-9]{0,15}$")
_ATTR = re.compile(r"^[a-z][a-z0-9-]{0,63}$")
_TEXT_KEY = re.compile(r"^(?:states\.)?[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)?$")


class PatternError(ValueError):
    """The pattern file or an example is malformed."""


@dataclass(frozen=True)
class Requirement:
    tag: str
    attrs: Mapping[str, str | None]

    def describe(self) -> str:
        parts = [k if v is None else f'{k}="{v}"' for k, v in sorted(self.attrs.items())]
        return f"<{' '.join([self.tag, *parts])}>"

    def matches(self, tag: str, attrs: Mapping[str, str | None]) -> bool:
        if tag != self.tag:
            return False
        for name, wanted in self.attrs.items():
            if name not in attrs:
                return False
            if wanted is None:
                continue
            have = attrs[name] or ""
            if name == "class":
                if not set(wanted.split()) <= set(have.split()):
                    return False
            elif have != wanted:
                return False
        return True


@dataclass(frozen=True)
class State:
    id: str
    require: tuple[Requirement, ...]
    texts: tuple[str, ...]
    shows: Mapping[str, str] | None


@dataclass(frozen=True)
class Pattern:
    number: int
    id: str
    states: Mapping[str, State]


@dataclass
class Example:
    """Parsed markup of one state."""

    elements: list[tuple[str, dict[str, str | None]]] = field(default_factory=list)
    texts: list[str] = field(default_factory=list)
    raw_text: str = ""

    @property
    def attributes(self) -> set[tuple[str, str, str | None]]:
        return {(tag, k, v) for tag, attrs in self.elements for k, v in attrs.items()}

    @property
    def visible_text(self) -> str:
        return re.sub(r"\s+", " ", self.raw_text).strip()


def _fail(text: str) -> PatternError:
    return PatternError(f"patterns: {text}")


def _keys(where: str, data: object, required: set[str], optional: frozenset[str]) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise _fail(f"{where}: expected a mapping")
    if missing := required - set(data):
        raise _fail(f"{where}: missing {sorted(missing)}")
    if unknown := set(data) - required - optional:
        raise _fail(f"{where}: unknown {sorted(unknown)}")
    return data


def _requirement(where: str, raw: object) -> Requirement:
    entry = _keys(where, raw, {"tag"}, frozenset({"attrs"}))
    tag = entry["tag"]
    attrs = entry.get("attrs", {})
    if not isinstance(tag, str) or not _TAG.match(tag) or not isinstance(attrs, dict):
        raise _fail(f"{where}: bad tag or attrs")
    for name, value in attrs.items():
        if not isinstance(name, str) or not _ATTR.match(name):
            raise _fail(f"{where}: bad attribute name")
        if value is not None and not isinstance(value, str):
            raise _fail(f"{where}: attribute {name} must be a string or null")
    return Requirement(tag, dict(attrs))


def _state(where: str, state_id: object, raw: object) -> State:
    if not isinstance(state_id, str) or not _ID.match(state_id):
        raise _fail(f"{where}: bad state id")
    entry = _keys(where, raw, {"require", "texts"}, frozenset({"shows"}))
    require = entry["require"]
    texts = entry["texts"]
    if not isinstance(require, list) or not require:
        raise _fail(f"{where}: require must be a non-empty list")
    if not isinstance(texts, list) or not all(
        isinstance(t, str) and _TEXT_KEY.match(t) for t in texts
    ):
        raise _fail(f"{where}: texts must be a list of message keys")
    for key in texts:
        _template(key, "de")  # the key must exist
    shows = entry.get("shows")
    if shows is not None and (
        not isinstance(shows, dict)
        or set(shows) != set(messages.LANGUAGES)
        or not all(isinstance(v, str) for v in shows.values())
    ):
        raise _fail(f"{where}: shows must hold one text per language")
    return State(
        state_id,
        tuple(_requirement(f"{where}.require[{i}]", r) for i, r in enumerate(require)),
        tuple(texts),
        shows,
    )


def parse_patterns(data: object) -> tuple[Pattern, ...]:
    """The patterns of a ``patterns.yaml`` document, numbered 1 to 9 in order."""
    doc = _keys("patterns.yaml", data, {"version", "timing", "patterns"}, frozenset())
    if doc["version"] != 1:
        raise _fail("patterns.yaml: expected version 1")
    raw = doc["patterns"]
    if not isinstance(raw, list) or len(raw) != PATTERN_COUNT:
        raise _fail(f"patterns.yaml: expected {PATTERN_COUNT} patterns")
    out = []
    for index, item in enumerate(raw, 1):
        entry = _keys(f"pattern {index}", item, {"number", "id", "states"}, frozenset())
        if (
            entry["number"] != index
            or not isinstance(entry["id"], str)
            or not _ID.match(entry["id"])
        ):
            raise _fail(f"pattern {index}: number must be {index} and id a short name")
        states = entry["states"]
        if not isinstance(states, dict) or not states:
            raise _fail(f"pattern {index}: states must be a non-empty mapping")
        out.append(
            Pattern(
                index,
                entry["id"],
                {str(k): _state(f"{entry['id']}.{k}", k, v) for k, v in states.items()},
            )
        )
    if len({p.id for p in out}) != len(out):
        raise _fail("patterns.yaml: pattern ids must be unique")
    return tuple(out)


@functools.cache
def load_patterns() -> tuple[Pattern, ...]:
    """The kit's nine patterns from ``contract/patterns/patterns.yaml``."""
    path = contract_dir() / "patterns" / "patterns.yaml"
    return parse_patterns(yaml.safe_load(path.read_text(encoding="utf-8")))


class _ExampleParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.examples: dict[str, Example] = {}
        self.current: Example | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        if tag == "section" and "data-pk-example" in values:
            state = values["data-pk-example"] or ""
            if self.current is not None or not _ID.match(state) or state in self.examples:
                raise _fail(f"example section {state!r}: nested, malformed or repeated")
            self.current = self.examples[state] = Example()
            return
        if self.current is not None:
            self.current.elements.append((tag, values))

    def handle_endtag(self, tag: str) -> None:
        if tag == "section":
            self.current = None

    def handle_data(self, data: str) -> None:
        if self.current is not None:
            self.current.raw_text += data
            if data.strip():
                self.current.texts.append(re.sub(r"\s+", " ", data).strip())


def parse_example(markup: str) -> dict[str, Example]:
    """The states of one example file, by ``data-pk-example``."""
    if len(markup.encode("utf-8")) > MAX_EXAMPLE_BYTES:
        raise _fail("example larger than the limit")
    parser = _ExampleParser()
    parser.feed(markup)
    parser.close()
    return parser.examples


def load_examples(pattern_id: str, lang: str) -> dict[str, Example]:
    """Example markup of ``pattern_id`` in ``lang`` from ``contract/patterns/examples/``."""
    if lang not in messages.LANGUAGES or pattern_id not in {p.id for p in load_patterns()}:
        raise _fail("unknown pattern or language")
    path = contract_dir() / "patterns" / "examples" / f"{pattern_id}.{lang}.html"
    return parse_example(path.read_text(encoding="utf-8"))


def _template(key: str, lang: str) -> str:
    name, _, rest = key.partition(".") if key.startswith("states.") else ("patterns", "", key)
    texts = messages.load_texts(name, lang)
    if rest not in texts:
        raise _fail(f"unknown text key {key}")
    return texts[rest]


def text_regex(template: str) -> re.Pattern[str]:
    """``template`` as a pattern in which every placeholder stands for any value."""
    pieces = re.split(r"\{[a-z_]+\}", template)
    return re.compile(".+?".join(re.escape(piece) for piece in pieces))


def check_example(example: Example, state: State, lang: str) -> list[str]:
    """Problems of ``example`` against ``state``: missing elements and missing texts."""
    problems = [
        f"missing element {req.describe()}"
        for req in state.require
        if not any(req.matches(tag, attrs) for tag, attrs in example.elements)
    ]
    shown = example.visible_text
    for key in state.texts:
        if not text_regex(_template(key, lang)).search(shown):
            problems.append(f"missing text {key}")
    if state.shows is not None and shown != state.shows[lang]:
        problems.append(f"shows {shown!r}, expected {state.shows[lang]!r}")
    return problems
