# Schema changelog

Each schema carries its version in the top-level keyword `x-papaia-schema-version`
(Semantic Versioning). The major version is part of the file name
(`<name>.v<major>.schema.json`); a minor version adds optional fields, a patch
version tightens documentation or fixes a pattern without changing which
documents are valid on purpose. Newest entry first. `(kit X.Y.Z)` names
the first kit release that ships the version; kit 0.1.0 was an untagged
snapshot.

## task-item.v1 1.0.0 (kit 0.1.3)

- First version: one entry of "Meine Aufgaben" (`papaia.task-item/1`) with
  `format`, `id`, `source`, `kind`, `title`, `href` and `due_at` required, and
  the optional fields Flow serves today (`subject`, `folder`, `created_at`,
  `risk_level`, `ref`, `decide`) plus `open_in` and `app_ref`. `#/$defs/list`
  is the body of `GET /api/v1/me/tasks`, `#/$defs/summary` the body of
  `GET /api/v1/me/tasks/summary`. Unknown fields are rejected.

## platform-services.v1 (kit 0.1.3)

- Optional top-level block `delegations` with `idle_days` and `max_days`,
  each from 1 to 365: the delegation lifetime in effect for the installation,
  published by the core. A missing value means the default of the security
  profile (90 / 180 days, `kritis` 7 / 30); the schema has no `default`
  keyword for them because the default depends on the profile. In security profile
  `kritis` the schema accepts at most 7 and 30 days. `idle_days` greater than
  `max_days` is rejected by the catalog reader. Every catalog valid before
  stays valid.

## exposes.v1 1.2.0 (kit 0.1.3)

- `delegation.max_idle_days` and `delegation.max_age_days` accept up to 365
  days each (before: 30 and 180). `max_idle_days` greater than `max_age_days`
  stays a failure of the manifest conformance check. Every manifest valid
  under 1.1.0 stays valid; a manifest above the old limits is refused by a
  validator of 1.1.0.

## audit.v1 1.3.0 (kit 0.1.3)

- Event type `delegation_lifetime_changed`: a change of the installation's
  delegation lifetime.
- Optional `detail` fields of that event: `idle_days_old`, `idle_days_new`,
  `max_days_old` and `max_days_new`, integers from 1 to 365. The four come
  together or not at all and only with `delegation_lifetime_changed`; a row of
  that event with result `allowed` must carry them. No field became required
  for any other event, so every row valid under 1.2.0 stays valid; a row with the new
  event or fields is refused by a validator of 1.2.0.

## exposes.v1 1.1.0 (kit 0.1.2)

- Optional boolean `header_identity` per entry (default `false`): the service
  accepts a person's identity from a request header set by the edge or a gate.
  The core never publishes a host port for such a service, also not on
  `127.0.0.1`. A marked entry lists `person` in `identity`. Any value other
  than `true` or `false` is rejected. The field serves the core alone and is
  not rendered into `platform-services.v1`. No field became required, so every
  section valid under 1.0.0 stays valid; a section with the marker is refused
  by a validator of 1.0.0.

## me-contract.v2 2.0.0 (kit 0.1.2)

- First version of the personal-area contract generation 2: the declaration
  `personal_settings:` with `api: 2` (groups with roles and the fresh sign-in
  marker `sensitive`, the field types of version 1 plus `multiline_text`,
  `datetime`, `recurrence` and `provenance`, `editable` and `content` per
  field, collection operations `create`, `update`, `delete`, `end`, `renew`
  and `delete_all`, data categories with their deletion route) and the bodies
  of the module API (write results with `operation_id` and `undo_token`,
  deletion receipts, errors with `412 stale` and `428
  precondition_required`, the `Idempotency-Key` value). Address and audience
  come from the `exposes` entry of kind `me`; data classes use the platform
  scale only. Unknown fields are rejected.

## audit.v1 1.2.0 (kit 0.1.2)

- Events `erasure_journaled`, `erasure_journal_flushed` and
  `erasure_renumbering_acknowledged` for the writes of the erasure journal.
- Optional `detail` fields of the erasure journal: `seq`, `kind` (the journal
  kinds of `erasure-journal-entry.v1`), `delivered`, `renumbered`,
  `renumbered_from`, and for `erasure_replayed` `trigger`, `by_kind` (entries
  applied per kind), `replayed_from`, `journal_end` and `journal_behind`. No
  field became required, so every row valid under 1.1.0 stays valid; a row
  with the new events or fields is refused by a validator of 1.1.0.

## injection-corpus.v1 1.0.0 (kit 0.1.2)

- First version: corpus file `papaia.injection-corpus/1` with `version` and
  cases (carrier, marker, data class, delivery, literal, content, obey,
  expect). Unknown fields are rejected.

## audit.v1 1.1.0 (kit 0.1.1)

- Optional fields `token_iat`, `token_auth_time` and `token_remaining_s`
  (integers from 0, or null) for the server's row of an operation: `iat` and
  `auth_time` of the presented token and the seconds from the check to its
  `exp`. A non-null value in any other row (`role` other than `server`, or
  `event` other than `operation`) is rejected. No field became required, so
  every row valid under 1.0.0 stays valid; a row with these fields is refused
  by a validator of 1.0.0.

## erasure-epoch.v1 (kit 0.1.1)

- First version: `<backup target>/erasure-journal/epoch` with `format`
  (`papaia.erasure-epoch/1`), `generation` and the last `seq` per module and
  core source. Unknown fields are rejected.

## erasure-journal-entry.v1 (kit 0.1.1)

- New kinds `revoke` (module journals) and, for the core sources,
  `account_disable`, `account_delete`, `role_revoke`, `session_revoke`,
  `credential_reset` (`identity`) and `key_revoke` (`model-gateway`). The
  schema names the kinds allowed per journal.

## error.v1 1.0.0 (kit 0.1.1)

- The schema now carries `x-papaia-schema-version`; earlier states of the
  file had none and were never released.
- `correlation_id` follows the one correlation id rule of the kit
  (`#/$defs/correlation_id`, identical to the rule in `audit.v1`): besides 1 to
  64 characters out of `A-Z`, `a-z`, `0-9` and `-`, a value shaped like a token
  or a key with a well-known prefix is rejected, and a trailing newline no
  longer passes. `build_envelope` replaces such a value by a new UUIDv7 and
  `parse_envelope` rejects it.

## recording.v1 1.0.0 (kit 0.1.1)

- First version: recording of a provider suite (`papaia.conformance-recording/1`)
  with kit version, suite, schema version, provider catalog id and image
  digest, time of the recording and request and response pairs. Headers that
  carry credentials are rejected.

## audit.v1 1.0.0 (kit 0.1.1)

- First version of the audit event `papaia.audit/1`: submitted form
  (`#/$defs/submission`) and stored form with `source`, `seq`, `prev_hash` and
  `hash`, which only papaia-audit assigns.
- Unknown fields are rejected at every level; every string is a bounded
  identifier.
- Strings shaped like a JSON Web Token, a bearer credential, a PEM block or a
  key with a well-known prefix are rejected in every identifier field,
  including `correlation_id`, `writer`, `catalog_id`, `operation`,
  `object_ref.type` and `source`.
- Size, depth, node, integer and date checks beyond the schema are listed in
  `contract/audit.md`.
- Events of the erasure journal at module start and of the core's lifecycle
  actions: `erasure_replayed`, `post_restore_applied`,
  `lifecycle_request_rejected`, `state_epoch_behind`, `state_epoch_unverified`
  (provisionally ready, result `allowed`), `state_epoch_unknown` (nothing to
  check against or the module's applied `seq` unreadable, never ready, result
  `denied`).

## healthz.v1 1.0.0 (kit 0.1.1)

- First version: response body of `GET /healthz` of every module,
  `{"status": "ok" | "degraded" | "down"}` and nothing else.

## exposes.v1 1.0.0 (kit 0.1.1)

- First version of the manifest section `exposes:` (contract generation 7).
- Entry kinds `mcp`, `rest`, `ui`, `me`; the earlier kind `flow_provider` is
  not accepted and becomes `rest` with operations.
- Capability description per operation: effect (`read`, `write`, `send`,
  `delete`, `check`), retry class, input and output schema, highest data class,
  resource, rights check.
- `ui[]` for the module switcher and entry page, `events[]`, `downstream`,
  `standard_operations`, `roles[]`.
- `service_accounts[]` (`id` = `svc-<module>-<purpose>`, purpose, responsible
  person and deputy, roles, audiences, effects, `realm-management` roles,
  credential `private_key_jwt`).
- Entries of kind `me` accept only `person`.
- Embedded `input_schema`, `output_schema` and `payload_schema` reference
  nothing outside themselves (`$ref` and `$dynamicRef` start with `#`,
  `$schema` is the 2020-12 meta-schema) and contain no `$id`,
  `$recursiveRef` or `$recursiveAnchor` at any depth.
- Every pattern ends at the end of the input; a trailing line feed is
  rejected in Python and ECMA-262 validators alike.
- `delegation.purposes` lists ids of the fixed kit purposes `flow.run`,
  `assist.event`, `assist.room-check`, `assist.tools`; only the holder of a
  purpose (Flow for `flow.*`, the assistant for `assist.*`) may declare
  `delegation`, checked by the manifest conformance check.
- `delegation`, `models.needs`, `requires`, `volumes[].backup`, `export.exit`,
  `storage` (categories with purpose, legal basis, retention, data class and
  erasure path, `on_request`, secrets).
- Unknown fields are rejected everywhere; `trust`, `branding`, `state` and
  `public_url` are set by the core, never by a manifest.
