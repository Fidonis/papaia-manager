"""Delegation lifetime of the installation, as the core publishes it in the catalog.

The administration sets two values per installation (``delegations.idle_days``
and ``delegations.max_days``); the core writes them to the realm as Offline
Session Idle and Offline Session Max and publishes them in ``services.json``.
Holders (Flow, the assistant) and the personal area show expiry dates computed
from these values with :class:`DelegationLifetime`, never from numbers of their
own, so a changed setting changes every card, receipt and list without a code
change. See ``contract/platform-services.md`` section 2.6.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

__all__ = [
    "DELEGATION_DAYS_LIMIT",
    "DelegationLifetime",
    "default_lifetime",
    "resolve_lifetime",
]

# Upper bound of either value in any profile (E-22).
DELEGATION_DAYS_LIMIT = 365


@dataclass(frozen=True, slots=True)
class DelegationLifetime:
    """Days without use (``idle_days``) and days in all (``max_days``) a delegation lives."""

    idle_days: int
    max_days: int

    def __post_init__(self) -> None:
        for name in ("idle_days", "max_days"):
            value = getattr(self, name)
            # bool is an int subclass; True must not pass as one day.
            if type(value) is not int or not 1 <= value <= DELEGATION_DAYS_LIMIT:
                raise ValueError(f"{name} must be an integer from 1 to {DELEGATION_DAYS_LIMIT}")
        if self.idle_days > self.max_days:
            raise ValueError("idle_days must not be greater than max_days")

    def max_expires_at(self, granted_at: datetime) -> datetime:
        """End of the delegation however often it is used."""
        return _aware(granted_at, "granted_at") + timedelta(days=self.max_days)

    def idle_expires_at(self, last_used_at: datetime) -> datetime:
        """End of the delegation if it is not used again after ``last_used_at``."""
        return _aware(last_used_at, "last_used_at") + timedelta(days=self.idle_days)

    def expires_at(self, granted_at: datetime, last_used_at: datetime | None = None) -> datetime:
        """The earlier of both ends; without a use yet the idle period runs from the grant."""
        granted = _aware(granted_at, "granted_at")
        used = granted if last_used_at is None else _aware(last_used_at, "last_used_at")
        if used < granted:
            raise ValueError("last_used_at lies before the grant")
        return min(self.idle_expires_at(used), self.max_expires_at(granted))


_DEFAULTS: Mapping[str, DelegationLifetime] = {
    "standard": DelegationLifetime(idle_days=90, max_days=180),
    "kritis": DelegationLifetime(idle_days=7, max_days=30),
}


def default_lifetime(security_profile: str | None) -> DelegationLifetime:
    """Contract default of a security profile; a catalog without a profile is ``standard``."""
    profile = "standard" if security_profile is None else security_profile
    try:
        return _DEFAULTS[profile]
    except KeyError:
        raise ValueError("unknown security profile") from None


def resolve_lifetime(document: Mapping[str, Any]) -> DelegationLifetime:
    """Lifetime of a schema-checked catalog document: published values, else profile defaults.

    Raises :class:`ValueError` when the published values contradict each other
    (``idle_days`` greater than ``max_days``).
    """
    default = default_lifetime(document.get("security_profile"))
    block = document.get("delegations") or {}
    return DelegationLifetime(
        idle_days=block.get("idle_days", default.idle_days),
        max_days=block.get("max_days", default.max_days),
    )


def _aware(value: object, name: str) -> datetime:
    if not isinstance(value, datetime) or value.utcoffset() is None:
        raise ValueError(f"{name} needs a time zone")
    return value
