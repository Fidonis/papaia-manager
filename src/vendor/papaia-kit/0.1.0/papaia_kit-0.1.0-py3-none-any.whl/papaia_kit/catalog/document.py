"""Parse and check the catalog files ``services.json`` and ``groups.json``.

Every check the contract asks of a consumer happens here, before a module sees
a single value:

- at most 1 MiB, strict UTF-8, strict JSON (no duplicate member names, no NaN or
  infinities, no number outside the range of a double, at most 64 levels deep);
- the kit schema (``platform-services.v1``, ``platform-groups.v1``), which
  rejects unknown fields at every level;
- what JSON Schema cannot express: unique entry ids, unique switcher ids, unique
  group ids, per entry a ``content_hash`` that matches the entry (an entry
  without an RFC 8785 canonical form, such as a lone surrogate or an integer a
  double cannot hold, is invalid), and a delegation lifetime whose
  ``idle_days`` is not greater than its ``max_days`` once the profile defaults
  are applied.

A file that fails any check raises :class:`CatalogError`; its messages name the
place and the rule, never the offending value, so they can be logged as they are.
The parsed result is immutable: mappings are read-only views, lists are tuples.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from enum import StrEnum
from functools import lru_cache
from types import MappingProxyType
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from papaia_kit._resources import schemas_dir
from papaia_kit.catalog.canonical import content_hash
from papaia_kit.catalog.delegations import DelegationLifetime, resolve_lifetime

__all__ = [
    "GROUPS_FORMAT",
    "MAX_BYTES",
    "MAX_DEPTH",
    "SERVICES_FORMAT",
    "Catalog",
    "CatalogError",
    "Entry",
    "Group",
    "GroupList",
    "State",
    "Surface",
    "parse_groups",
    "parse_services",
]

SERVICES_FORMAT = "papaia.platform-services/1"
GROUPS_FORMAT = "papaia.platform-groups/1"
SERVICES_SCHEMA = "platform-services.v1.schema.json"
GROUPS_SCHEMA = "platform-groups.v1.schema.json"

# Upper bound of a rendered catalog file (architecture V-02 rule 1).
MAX_BYTES = 1024 * 1024
# Bound on the number of problems reported for one file.
_MAX_PROBLEMS = 20
# Deepest nesting of objects and arrays a catalog file may use.
MAX_DEPTH = 64


class CatalogError(ValueError):
    """A catalog file failed a check. ``problems`` lists place and rule, no values."""

    def __init__(self, problems: Iterable[str]) -> None:
        self.problems = tuple(problems)[:_MAX_PROBLEMS] or ("invalid",)
        super().__init__("; ".join(self.problems))


class State(StrEnum):
    """Run state of an installed module, set by ``papaia-ctl addon start|stop``."""

    RUNNING = "running"
    STOPPED = "stopped"


@dataclass(frozen=True)
class Surface:
    """One user interface surface (``ui[]`` item) together with its entry's state."""

    id: str
    entry_id: str
    state: State | None
    title: Mapping[str, str]
    icon: str
    order: int
    public_url: str
    visible_for_roles: tuple[str, ...]
    opens_in: str
    data: Mapping[str, Any]

    @property
    def running(self) -> bool:
        return self.state is State.RUNNING


@dataclass(frozen=True)
class Entry:
    """One catalog entry. ``data`` holds every field as read, immutable."""

    id: str
    kind: str
    provider: str
    version: str
    state: State | None
    content_hash: str
    data: Mapping[str, Any]


@dataclass(frozen=True)
class Catalog:
    """A checked ``services.json``.

    ``digest`` is ``sha256:`` over the file bytes and identifies the file as a
    whole; ``Entry.content_hash`` identifies one entry and is what approvals
    bind to.
    """

    digest: str
    generated_at: str
    entries: Mapping[str, Entry]
    surfaces: tuple[Surface, ...]
    data: Mapping[str, Any]
    delegation_lifetime: DelegationLifetime
    """Lifetime in effect for delegations: published values, else the profile defaults."""

    def entry(self, entry_id: str) -> Entry | None:
        return self.entries.get(entry_id)

    def surface(self, surface_id: str) -> Surface | None:
        return next((s for s in self.surfaces if s.id == surface_id), None)

    @property
    def branding(self) -> Mapping[str, Any] | None:
        value = self.data.get("branding")
        return value if isinstance(value, Mapping) else None


@dataclass(frozen=True)
class Group:
    id: str
    path: str
    display_name: Mapping[str, str]
    technical: bool


@dataclass(frozen=True)
class GroupList:
    """A checked ``groups.json``."""

    digest: str
    generated_at: str
    groups: tuple[Group, ...]

    def offerable(self) -> tuple[Group, ...]:
        """Groups a module may offer for sharing: never the technical ones."""
        return tuple(group for group in self.groups if not group.technical)


def parse_services(data: bytes) -> Catalog:
    """Check ``services.json`` bytes and return the immutable catalog."""
    document = _load(data, SERVICES_SCHEMA)
    problems: list[str] = []
    entries: dict[str, Entry] = {}
    surfaces: list[Surface] = []
    seen_surfaces: set[str] = set()
    for index, raw in enumerate(document["services"]):
        where = f"services/{index}"
        if raw["id"] in entries:
            problems.append(f"{where}/id: duplicate entry id")
            continue
        try:
            expected = content_hash(raw)
        except ValueError:
            problems.append(f"{where}/content_hash: entry has no canonical form")
        else:
            if raw["content_hash"] != expected:
                problems.append(f"{where}/content_hash: does not match the entry")
        frozen = _freeze(raw)
        state = State(raw["state"]) if "state" in raw else None
        entries[raw["id"]] = Entry(
            id=raw["id"],
            kind=raw["kind"],
            provider=raw["provider"],
            version=raw["version"],
            state=state,
            content_hash=raw["content_hash"],
            data=frozen,
        )
        for ui_index, ui in enumerate(frozen.get("ui", ())):
            if ui["id"] in seen_surfaces:
                problems.append(f"{where}/ui/{ui_index}/id: duplicate switcher id")
                continue
            seen_surfaces.add(ui["id"])
            surfaces.append(
                Surface(
                    id=ui["id"],
                    entry_id=raw["id"],
                    state=state,
                    title=ui["title"],
                    icon=ui["icon"],
                    order=ui["order"],
                    public_url=ui["public_url"],
                    visible_for_roles=ui["visible_for_roles"],
                    opens_in=ui["opens_in"],
                    data=ui,
                )
            )
    lifetime: DelegationLifetime | None = None
    try:
        lifetime = resolve_lifetime(document)
    except ValueError:
        problems.append("delegations/idle_days: greater than max_days")
    if problems or lifetime is None:
        raise CatalogError(problems)
    return Catalog(
        digest=_digest(data),
        generated_at=document["generated_at"],
        entries=MappingProxyType(entries),
        surfaces=tuple(surfaces),
        data=_freeze(document),
        delegation_lifetime=lifetime,
    )


def parse_groups(data: bytes) -> GroupList:
    """Check ``groups.json`` bytes; group ids must be unique."""
    document = _load(data, GROUPS_SCHEMA)
    problems: list[str] = []
    groups: list[Group] = []
    seen: set[str] = set()
    for index, raw in enumerate(document["groups"]):
        if raw["id"] in seen:
            problems.append(f"groups/{index}/id: duplicate group id")
            continue
        seen.add(raw["id"])
        groups.append(
            Group(
                id=raw["id"],
                path=raw["path"],
                display_name=_freeze(raw["display_name"]),
                technical=raw["technical"],
            )
        )
    if problems:
        raise CatalogError(problems)
    return GroupList(
        digest=_digest(data), generated_at=document["generated_at"], groups=tuple(groups)
    )


def _digest(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _load(data: bytes, schema_file: str) -> Any:
    if not isinstance(data, bytes | bytearray):
        raise TypeError("catalog content must be bytes")
    if len(data) > MAX_BYTES:
        raise CatalogError([f"file: larger than {MAX_BYTES} bytes"])
    try:
        text = bytes(data).decode("utf-8")
    except UnicodeDecodeError:
        raise CatalogError(["file: not UTF-8"]) from None
    try:
        document = json.loads(
            text,
            object_pairs_hook=_unique_members,
            parse_constant=_reject_constant,
            parse_float=_finite_float,
        )
    except _DuplicateMemberError:
        # The name is file content, not a contract field name: never echo it.
        raise CatalogError(["file: duplicate member name"]) from None
    except _NumberOutOfRangeError:
        raise CatalogError(["file: number out of range"]) from None
    except _NotJsonConstantError:
        raise CatalogError(["file: not JSON (NaN or infinity)"]) from None
    except json.JSONDecodeError as exc:
        where = f"line {exc.lineno} column {exc.colno}"
        raise CatalogError([f"file: not JSON ({exc.msg} at {where})"]) from None
    except RecursionError:
        raise CatalogError(["file: nesting too deep"]) from None
    except ValueError:
        # The rejected constants raise ValueError; so does an integer literal
        # longer than the interpreter converts (sys.get_int_max_str_digits).
        raise CatalogError(["file: number out of range"]) from None
    if _depth(document) > MAX_DEPTH:
        raise CatalogError(["file: nesting too deep"])
    problems = [
        f"{'/'.join(str(p) for p in error.absolute_path) or '(root)'}: fails {error.validator}"
        for error in sorted(_validator(schema_file).iter_errors(document), key=_error_order)
    ]
    if problems:
        raise CatalogError(problems)
    return document


class _DuplicateMemberError(ValueError):
    """Two members of one object share a name; carries no part of the file."""


class _NumberOutOfRangeError(ValueError):
    """A number literal outside the finite range of a double (``1e400``)."""


class _NotJsonConstantError(ValueError):
    """``NaN``, ``Infinity`` or ``-Infinity``, which the JSON grammar does not have."""


def _unique_members(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, value in pairs:
        if name in result:
            raise _DuplicateMemberError
        result[name] = value
    return result


def _reject_constant(name: str) -> Any:
    raise _NotJsonConstantError


def _finite_float(literal: str) -> float:
    value = float(literal)
    if not math.isfinite(value):
        raise _NumberOutOfRangeError
    return value


def _depth(document: Any) -> int:
    """Deepest nesting of objects and arrays, without recursion."""
    deepest = 0
    stack: list[tuple[Any, int]] = [(document, 1)]
    while stack:
        value, level = stack.pop()
        if isinstance(value, dict):
            children: Iterable[Any] = value.values()
        elif isinstance(value, list):
            children = value
        else:
            continue
        deepest = max(deepest, level)
        if deepest > MAX_DEPTH:
            return deepest
        stack.extend((child, level + 1) for child in children)
    return deepest


def _error_order(error: Any) -> tuple[str, ...]:
    return tuple(str(part) for part in error.absolute_path)


@lru_cache(maxsize=4)
def _validator(schema_file: str) -> Draft202012Validator:
    schema = json.loads((schemas_dir() / schema_file).read_text(encoding="utf-8"))
    return Draft202012Validator(schema, format_checker=FormatChecker())


def _freeze(value: Any) -> Any:
    if isinstance(value, dict):
        return MappingProxyType({key: _freeze(item) for key, item in value.items()})
    if isinstance(value, list):
        return tuple(_freeze(item) for item in value)
    return value
