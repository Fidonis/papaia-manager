"""Command line of the glossary word check: ``papaia-kit words ...`` (also ``pk-words``)."""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from papaia_kit.ui.glossary import LANGUAGES, GlossaryError, load_glossary
from papaia_kit.ui.runtime import (
    check_pseudo,
    check_rendered,
    parse_nodes,
    pseudo_entries,
)
from papaia_kit.ui.words import (
    DEFAULT_EXCLUDES,
    EXPORT_DIR,
    MAP_FILE,
    MAX_EXPORT_BYTES,
    SOURCES,
    InputError,
    WordFinding,
    check_module,
    load_export,
)

EXIT_OK, EXIT_FAIL, EXIT_USAGE = 0, 1, 2


def add_parser(groups: Any) -> None:
    """Add the ``words`` group to the subparsers action ``groups``."""
    words = groups.add_parser("words", help="glossary word check (pk-words)")
    commands = words.add_subparsers(dest="command", required=True)

    check = commands.add_parser("check", help="check the texts of a module against the glossary")
    check.add_argument("--root", type=Path, default=Path(), help="module repository root")
    check.add_argument(
        "--source",
        action="append",
        choices=SOURCES,
        help="source to check (repeatable; default: all five)",
    )
    check.add_argument("--export-dir", type=Path, default=EXPORT_DIR)
    check.add_argument("--map", type=Path, default=MAP_FILE, dest="map_path")
    check.add_argument(
        "--exclude", action="append", default=[], help="extra glob of files not to read"
    )
    check.add_argument("--report", type=Path, help="write every finding as JSON")

    glossary = commands.add_parser("glossary", help="check the glossary file against its schema")
    glossary.add_argument("--file", type=Path, help="glossary file (default: the kit's)")

    rendered = commands.add_parser(
        "rendered", help="check text nodes read from a running system (L1, L2)"
    )
    rendered.add_argument("nodes", type=Path, help="JSON array of strings or node objects")
    rendered.add_argument("--lang", choices=LANGUAGES)
    rendered.add_argument("--module", help="module id for the module title place")
    rendered.add_argument(
        "--pseudo", action="store_true", help="check the marks of the check locale instead"
    )
    rendered.add_argument("--keys", type=Path, help="catalog export whose key names must not show")

    pseudo = commands.add_parser("pseudo", help="write the check locale x-pk from a catalog export")
    pseudo.add_argument("export", type=Path)
    pseudo.add_argument("--output", type=Path, required=True)


def _write_atomic(path: Path, data: bytes) -> None:
    handle = tempfile.NamedTemporaryFile(  # noqa: SIM115 - closed before the rename
        dir=path.parent, prefix=f".{path.name}.", suffix=".tmp", delete=False
    )
    try:
        with handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        Path(handle.name).replace(path)
    except BaseException:
        Path(handle.name).unlink(missing_ok=True)
        raise


def _json_bytes(data: object) -> bytes:
    return (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _print(findings: Sequence[WordFinding], label: str, ok_message: str) -> int:
    errors = [f for f in findings if f.severity == "error"]
    for finding in findings:
        prefix = "warning: " if finding.severity == "warning" else ""
        print(
            f"  {prefix}{finding.check} {finding.source} {finding.location}: {finding.message}",
            file=sys.stderr,
        )
    if errors:
        print(f"{len(errors)} {label}", file=sys.stderr)
        return EXIT_FAIL
    warnings = len(findings) - len(errors)
    print(ok_message + (f" ({warnings} warning(s))" if warnings else ""))
    return EXIT_OK


def _check(args: argparse.Namespace) -> int:
    findings = check_module(
        args.root,
        sources=tuple(args.source or SOURCES),
        export_dir=args.export_dir,
        map_path=args.map_path,
        excludes=(*DEFAULT_EXCLUDES, *args.exclude),
    )
    if args.report is not None:
        _write_atomic(args.report, _json_bytes([f.as_dict() for f in findings]))
    return _print(findings, "word check finding(s)", "words check: no findings")


def _rendered(args: argparse.Namespace) -> int:
    try:
        raw = json.loads(args.nodes.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise InputError(f"{args.nodes}: not valid JSON (line {exc.lineno})") from exc
    nodes = parse_nodes(raw, str(args.nodes))
    if args.pseudo:
        if args.keys is None:
            raise InputError("--pseudo needs --keys with the catalog export")
        keys = [entry.key for entry in load_export(args.keys)]
        findings = check_pseudo(nodes, keys)
        return _print(findings, "unmarked text node(s)", "words rendered: every text marked")
    if args.lang is None:
        raise InputError("--lang is required unless --pseudo is given")
    findings = check_rendered(nodes, args.lang, module=args.module)
    return _print(findings, "word check finding(s)", "words rendered: no findings")


def _pseudo(args: argparse.Namespace) -> int:
    entries = load_export(args.export)
    data = _json_bytes(pseudo_entries(entries))
    if len(data) > MAX_EXPORT_BYTES:
        raise InputError(f"{args.output}: result larger than {MAX_EXPORT_BYTES} bytes")
    _write_atomic(args.output, data)
    print(f"words pseudo: wrote {len(entries)} entries to {args.output}")
    return EXIT_OK


def run(args: argparse.Namespace) -> int:
    """Run one ``words`` command; input problems exit with 2, findings with 1."""
    try:
        if args.command == "glossary":
            glossary = load_glossary(args.file)
            print(f"words glossary: valid, {len(glossary.entries)} entries")
            return EXIT_OK
        handlers = {"check": _check, "rendered": _rendered, "pseudo": _pseudo}
        return handlers[args.command](args)
    except (GlossaryError, InputError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    except OSError as exc:
        print(f"error: {exc.filename}: {exc.strerror}", file=sys.stderr)
        return EXIT_USAGE
