"""Edge pages: the proxy pages for 404 and 503 and the page after signing out.

Interface spec 2.3 and 2.4 (PLT-29, PLT-73). ``tools/build.py`` renders
``dist/proxy/{404,503}.{de,en}.html`` and ``dist/signed-out.{de,en}.html``
with :func:`render_edge_page`: static, one embedded stylesheet with the kit
values, no script, nothing from another host. The generated pages carry two
slots that the core (proxy pages) or the module (signed-out page) fills with
:func:`fill_edge_page`: name and logo of the installation, and on the 503
page the link to My area. A module that serves the signed-out page under a
content security policy allows the stylesheet by :func:`csp_style_source`.

The pages show no data and grant nothing; they are display only.
"""

from __future__ import annotations

import base64
import hashlib
import re
from urllib.parse import urlsplit

import jinja2
from markupsafe import Markup, escape

from papaia_kit.errors._patterns import has_hidden_characters
from papaia_kit.ui.messages import LANGUAGES, load_texts
from papaia_kit.ui.shell import kit_loader

__all__ = [
    "BRAND_SLOT",
    "EDGE_PAGES",
    "MAX_LOGO_BYTES",
    "MY_AREA_SLOT",
    "EdgePageError",
    "csp_style_source",
    "fill_edge_page",
    "render_edge_page",
]

EDGE_PAGES = ("proxy/404", "proxy/503", "signed-out")
BRAND_SLOT = "<!--pk-slot:brand-->"
MY_AREA_SLOT = "<!--pk-slot:my-area-->"
MAX_LOGO_BYTES = 256 * 1024
MAX_NAME_CHARS = 60  # branding.name in papaia.platform-services/1
MAX_URL_CHARS = 2048
MAX_PAGE_CHARS = 256 * 1024
SIGN_IN_HREF = "/"  # any page of the module starts the sign-in and comes back to it

_SECTIONS = {"proxy/404": "not_installed", "proxy/503": "unavailable", "signed-out": "signed_out"}
_LINES = {"proxy/404": ("text", "todo"), "proxy/503": ("text", "todo"), "signed-out": ("text",)}
_LANG = re.compile(r'<html lang="(de|en)">')
_STYLE = re.compile(r"<style>(.*?)</style>", re.DOTALL)
_PNG = b"\x89PNG\r\n\x1a\n"
_SVG_START = re.compile(rb"^\s*(?:<\?xml[^>]{0,200}\?>\s*)?(?:<!--.{0,500}?-->\s*)*<svg[\s>]", re.S)
_SVG_ACTIVE = re.compile(rb"<script|<foreignObject|javascript:|\son[a-z]+\s*=", re.IGNORECASE)
_URL_UNSAFE = re.compile(r"[\s\"'<>`\\]")


class EdgePageError(ValueError):
    """A value for an edge page or the page itself breaks the contract."""


def _environment() -> jinja2.Environment:
    return jinja2.Environment(
        loader=kit_loader(),
        autoescape=True,
        undefined=jinja2.StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
        keep_trailing_newline=True,
    )


def render_edge_page(page: str, lang: str, style: str) -> str:
    """One generated edge page with its slots; ``style`` is the embedded stylesheet."""
    if page not in _SECTIONS:
        raise EdgePageError(f"page: unknown edge page {page!r}")
    if lang not in LANGUAGES:
        raise EdgePageError(f"lang: unsupported language {lang!r}")
    if "</" in style or "<!--" in style:
        raise EdgePageError("style: must not close the style element")
    section = _SECTIONS[page]
    texts = load_texts("edge", lang)
    link = None
    if page == "signed-out":
        link = {"href": SIGN_IN_HREF, "text": texts[f"{section}.sign_in"]}
    return (
        _environment()
        .get_template("pk/edge.html")
        .render(
            lang=lang,
            page=page,
            title=texts[f"{section}.title"],
            lines=[texts[f"{section}.{key}"] for key in _LINES[page]],
            link=link,
            # Trusted constants: the style is built from the token file and ui/edge.css, the
            # slots are fixed comments.
            style=Markup(style),  # noqa: S704
            brand_slot=Markup(BRAND_SLOT),  # noqa: S704
            my_area_slot=Markup(MY_AREA_SLOT) if page == "proxy/503" else None,  # noqa: S704
        )
    )


def _name(value: object) -> str:
    if not isinstance(value, str) or not 0 < len(value) <= MAX_NAME_CHARS:
        raise EdgePageError(f"name: must be a text of 1 to {MAX_NAME_CHARS} characters")
    if "\n" in value or "\r" in value or has_hidden_characters(value):
        raise EdgePageError("name: holds a line break or a hidden character")
    return value


def _logo(value: object) -> str | None:
    """The logo as a ``data:`` address: PNG or SVG without active content."""
    if value is None:
        return None
    if not isinstance(value, bytes) or not 0 < len(value) <= MAX_LOGO_BYTES:
        raise EdgePageError(f"logo: must be 1 to {MAX_LOGO_BYTES} bytes")
    if value.startswith(_PNG):
        kind = "image/png"
    elif _SVG_START.match(value) and not _SVG_ACTIVE.search(value):
        kind = "image/svg+xml"
    else:
        raise EdgePageError("logo: must be PNG or SVG without script or event handler")
    return f"data:{kind};base64,{base64.b64encode(value).decode('ascii')}"


def https_url(field: str, value: object) -> str:
    """An absolute ``https`` address with a host, no credentials and nothing to break out."""
    if not isinstance(value, str) or not 0 < len(value) <= MAX_URL_CHARS:
        raise EdgePageError(f"{field}: must be a text of 1 to {MAX_URL_CHARS} characters")
    if _URL_UNSAFE.search(value) or has_hidden_characters(value):
        raise EdgePageError(f"{field}: holds white space, quotes or a hidden character")
    try:
        parts = urlsplit(value)
        _ = parts.port  # a port outside 0-65535 raises ValueError
    except ValueError:
        raise EdgePageError(f"{field}: not a valid address") from None
    if parts.scheme != "https" or not parts.hostname or parts.username or parts.password:
        raise EdgePageError(f"{field}: must be https with a host and without credentials")
    return value


def fill_edge_page(
    html: object,
    *,
    name: str,
    logo: bytes | None = None,
    my_area_url: str | None = None,
) -> str:
    """Fill the slots of a generated edge page with the installation's name, logo and My area.

    ``logo`` is the content of ``platform/brand-logo`` (PNG or SVG); it is
    embedded, because a proxy page loads nothing. ``my_area_url`` is the
    ``public_url`` of ``me`` from the catalog; without it the 503 page shows
    no link.
    """
    if not isinstance(html, str) or len(html) > MAX_PAGE_CHARS:
        raise EdgePageError(f"page: must be a text of at most {MAX_PAGE_CHARS} characters")
    lang = _LANG.search(html)
    if lang is None:
        raise EdgePageError("page: no <html lang> of a supported language")
    if html.count(BRAND_SLOT) != 1:
        raise EdgePageError("page: brand slot missing; not a generated edge page")
    brand_name, logo_src = _name(name), _logo(logo)
    brand = ""
    if logo_src is not None:
        brand += f'<img class="pk-edge-logo" src="{logo_src}" alt="">'
    brand += f'<span class="pk-edge-name">{escape(brand_name)}</span>'
    filled = html.replace(BRAND_SLOT, brand)
    slots = filled.count(MY_AREA_SLOT)
    if my_area_url is None:
        return filled.replace(MY_AREA_SLOT, "")
    url = https_url("my_area_url", my_area_url)
    if slots != 1:
        raise EdgePageError("my_area_url: this page has no slot for My area")
    label = load_texts("edge", lang.group(1))["unavailable.my_area"]
    link = (
        f'<p class="pk-edge-action"><a class="pk-link" href="{escape(url)}">{escape(label)}</a></p>'
    )
    return filled.replace(MY_AREA_SLOT, link)


def csp_style_source(html: object) -> str:
    """The ``style-src`` source (``'sha256-…'``) for the one embedded stylesheet of a page."""
    styles = _STYLE.findall(html) if isinstance(html, str) else []
    if len(styles) != 1:
        raise EdgePageError("page: expected exactly one embedded style element")
    digest = hashlib.sha256(styles[0].encode("utf-8")).digest()
    return f"'sha256-{base64.b64encode(digest).decode('ascii')}'"
