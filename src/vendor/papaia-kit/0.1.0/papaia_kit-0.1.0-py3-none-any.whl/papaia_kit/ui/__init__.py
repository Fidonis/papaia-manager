"""User interface contract: design tokens, shell markup, macros, addresses and the page list."""

from papaia_kit.ui.address import delegation_url, target_url
from papaia_kit.ui.macros import MacroError, extend_environment
from papaia_kit.ui.shell import (
    ShellInput,
    ShellInputError,
    kit_loader,
    parse_shell_input,
    render_shell,
    shell_context,
    shell_environment,
)
from papaia_kit.ui.shell_normalize import normalize_shell

__all__ = [
    "MacroError",
    "ShellInput",
    "ShellInputError",
    "delegation_url",
    "extend_environment",
    "kit_loader",
    "normalize_shell",
    "parse_shell_input",
    "render_shell",
    "shell_context",
    "shell_environment",
    "target_url",
]
