"""``papaia-kit specimen``: expected computed styles and the reference specimen page.

``expected`` writes ``contract/specimen-expected.<theme>.json`` from the token
file and ``contract/specimen.yaml``, or with ``--check`` names every file that
differs. ``page`` prints the reference document of ``/_kit/specimen`` for one
module, language and theme (kit release: reference images; browser self test),
or with ``--page`` one of the composed reference pages. ``pages`` writes
``contract/examples/pages/<page>.<lang>.html``, or with ``--check`` names every
file that differs.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

from papaia_kit._resources import contract_dir, tokens_dir
from papaia_kit.ui.composed import PAGES, composed_page, page_files
from papaia_kit.ui.shell import ShellInputError
from papaia_kit.ui.specimen import SpecimenError, expected_text, load_specimen, specimen_page
from papaia_kit.ui.tokens import THEMES, TokenError, load_tokens

__all__ = ["add_parser", "run"]

EXIT_OK, EXIT_FAIL, EXIT_USAGE = 0, 1, 2


def add_parser(groups: Any) -> None:
    """Arguments of ``specimen``; ``groups`` is the top-level subparsers action."""
    specimen = groups.add_parser("specimen", help="specimen page contract")
    sub = specimen.add_subparsers(dest="command", required=True)
    expected = sub.add_parser("expected", help="write or check specimen-expected.<theme>.json")
    expected.add_argument("--check", action="store_true", help="compare instead of writing")
    expected.add_argument("--out", type=Path, help="target directory (default: the kit's contract)")
    page = sub.add_parser("page", help="print the reference specimen document or a composed page")
    target = page.add_mutually_exclusive_group()
    target.add_argument("--module", help="switcher id of the module, e.g. flow (specimen page)")
    target.add_argument("--page", choices=PAGES, help="composed reference page")
    page.add_argument("--lang", choices=("de", "en"), default="de")
    page.add_argument("--theme", choices=THEMES, default="light")
    pages = sub.add_parser("pages", help="write or check contract/examples/pages/")
    pages.add_argument("--check", action="store_true", help="compare instead of writing")
    pages.add_argument("--out", type=Path, help="contract directory (default: the kit's contract)")


def run(args: argparse.Namespace) -> int:
    try:
        if args.command == "page":
            return _page(args)
        if args.command == "pages":
            return _pages(args.out or contract_dir(), check=args.check)
        return _expected(args.out or contract_dir(), check=args.check)
    except (SpecimenError, TokenError, ShellInputError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_FAIL
    except (OSError, UnicodeDecodeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE


def _expected(folder: Path, *, check: bool) -> int:
    tokens = load_tokens(tokens_dir() / "papaia.tokens.json")
    spec = load_specimen(tokens=tokens)
    wanted = {f"specimen-expected.{t}.json": expected_text(spec, tokens, t) for t in THEMES}
    if check:
        problems = [
            f"{'missing' if not (folder / n).is_file() else 'changed'}: {n}"
            for n, text in wanted.items()
            if not (folder / n).is_file() or (folder / n).read_text(encoding="utf-8") != text
        ]
        for problem in problems:
            print(problem, file=sys.stderr)
        if problems:
            print(
                "specimen expected values are not current: run `papaia-kit specimen expected`",
                file=sys.stderr,
            )
            return EXIT_FAIL
        print(f"specimen expected: {len(wanted)} file(s) current")
        return EXIT_OK
    for name, text in wanted.items():
        (folder / name).write_text(text, encoding="utf-8")
    print(f"specimen expected: wrote {len(wanted)} file(s)")
    return EXIT_OK


def _page(args: argparse.Namespace) -> int:
    if args.page is not None:
        sys.stdout.write(composed_page(args.page, lang=args.lang, theme=args.theme))
        return EXIT_OK
    if args.module is None:
        print("error: give --module or --page", file=sys.stderr)
        return EXIT_USAGE
    sys.stdout.write(specimen_page(module=args.module, lang=args.lang, theme=args.theme))
    return EXIT_OK


def _pages(folder: Path, *, check: bool) -> int:
    wanted = page_files()
    if check:
        problems = [
            f"{'missing' if not (folder / n).is_file() else 'changed'}: {n}"
            for n, text in wanted.items()
            if not (folder / n).is_file() or (folder / n).read_text(encoding="utf-8") != text
        ]
        for problem in problems:
            print(problem, file=sys.stderr)
        if problems:
            print(
                "composed pages are not current: run `papaia-kit specimen pages`",
                file=sys.stderr,
            )
            return EXIT_FAIL
        print(f"composed pages: {len(wanted)} file(s) current")
        return EXIT_OK
    for name, text in wanted.items():
        target = folder / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
    print(f"composed pages: wrote {len(wanted)} file(s)")
    return EXIT_OK
