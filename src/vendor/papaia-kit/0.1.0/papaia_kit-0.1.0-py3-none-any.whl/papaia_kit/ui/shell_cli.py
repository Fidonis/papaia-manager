"""``papaia-kit shell``: render, normalise and regenerate the shell reference outputs.

``render`` is the reference implementation of the module command
``render-shell --input <json>`` (K3, interface spec 3.8): it prints the HTML
document for one input. ``normalize`` applies ``contract/shell/normalize.md``.
``expected`` writes ``expected/<input>.html`` for every reference input, or
with ``--check`` names every file that differs.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

from papaia_kit._resources import contract_dir
from papaia_kit.ui.shell import MAX_INPUT_BYTES, ShellInputError, parse_shell_input, render_shell
from papaia_kit.ui.shell_normalize import normalize_shell

__all__ = ["add_parser", "run"]

EXIT_OK, EXIT_FAIL, EXIT_USAGE = 0, 1, 2
MAX_HTML_BYTES = 4 * 1024 * 1024


def add_parser(groups: Any) -> None:
    """Arguments of ``shell``; ``groups`` is the top-level subparsers action."""
    shell = groups.add_parser("shell", help="shell markup contract")
    sub = shell.add_subparsers(dest="command", required=True)
    render = sub.add_parser("render", help="print the shell document for one input")
    render.add_argument("--input", type=Path, required=True, help="papaia.shell-input/1 file")
    normalize = sub.add_parser("normalize", help="print the normalised form of an HTML file")
    normalize.add_argument("html", type=Path)
    expected = sub.add_parser("expected", help="write or check expected/ from inputs/")
    expected.add_argument("--check", action="store_true", help="compare instead of writing")
    expected.add_argument(
        "--contract", type=Path, help="contract/shell directory (default: the kit's)"
    )


def run(args: argparse.Namespace) -> int:
    try:
        if args.command == "render":
            sys.stdout.write(_render(args.input))
            return EXIT_OK
        if args.command == "normalize":
            sys.stdout.write(normalize_shell(_read(args.html, MAX_HTML_BYTES).decode("utf-8")))
            return EXIT_OK
        return _expected(args.contract or contract_dir() / "shell", check=args.check)
    except ShellInputError as exc:
        for problem in exc.problems:
            print(f"  {problem}", file=sys.stderr)
        print("shell input rejected", file=sys.stderr)
        return EXIT_FAIL
    except (OSError, UnicodeDecodeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE


def _render(path: Path) -> str:
    return render_shell(parse_shell_input(_read(path, MAX_INPUT_BYTES)))


def _expected(root: Path, *, check: bool) -> int:
    inputs = sorted((root / "inputs").glob("*.json"))
    if not inputs:
        print(f"error: no inputs under {root / 'inputs'}", file=sys.stderr)
        return EXIT_USAGE
    wanted = {f"{p.stem}.html": normalize_shell(_render(p)) for p in inputs}
    folder = root / "expected"
    present = {p.name for p in folder.glob("*.html")} if folder.is_dir() else set()
    if check:
        problems = [f"missing: {n}" for n in sorted(wanted) if n not in present]
        problems += [f"unexpected: {n}" for n in sorted(present - set(wanted))]
        problems += [
            f"changed: {n}"
            for n in sorted(wanted)
            if n in present and (folder / n).read_text(encoding="utf-8") != wanted[n]
        ]
        for problem in problems:
            print(problem, file=sys.stderr)
        if problems:
            print("expected/ is not current: run `papaia-kit shell expected`", file=sys.stderr)
            return EXIT_FAIL
        print(f"shell expected: {len(wanted)} file(s) current")
        return EXIT_OK
    folder.mkdir(parents=True, exist_ok=True)
    for name in sorted(present - set(wanted)):
        (folder / name).unlink()
    for name, text in wanted.items():
        (folder / name).write_text(text, encoding="utf-8")
    print(f"shell expected: wrote {len(wanted)} file(s)")
    return EXIT_OK


def _read(path: Path, limit: int) -> bytes:
    with path.open("rb") as handle:
        data = handle.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"{path}: larger than {limit} bytes")
    return data
