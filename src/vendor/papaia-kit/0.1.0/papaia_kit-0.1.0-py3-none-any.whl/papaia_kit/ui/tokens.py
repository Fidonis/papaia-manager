"""Design token file (Design Tokens Format Module 2025.10) and contrast pairs.

The token file ``tokens/papaia.tokens.json`` is the one source of colour,
radius, font and layout values. Two groups ``light`` and ``dark`` hold the
theme tokens, every other top-level group is shared by both themes. Each token
becomes one CSS custom property ``--pk-<path>``: the path without the theme
group, joined by ``-``; the DTCG name ``$root`` adds nothing to the path.

The reader is strict: unknown ``$`` fields, unknown token types, colour spaces
other than sRGB, a ``hex`` that disagrees with the ``components``, aliases
anywhere but in the colour of a border, and roles that only one theme defines
are refused. Errors name the token path, never the value.

Besides the roles of the file, every theme gets the interaction colours of
:data:`DERIVED_ROLES` (hover, pressed, disabled, sunken). They are derived from the
theme's own roles by a lightness step in OKLCH and written out as hex, so no
value of the file changes and a module never computes a colour itself.
"""

from __future__ import annotations

import json
import math
import re
from collections.abc import Callable, Iterable, Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

THEMES = ("light", "dark")
EXTENSION = "de.fidonis.papaia-kit"
MAX_FILE_BYTES = 1024 * 1024
MAX_MEASURE = 100_000

_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_HEX = re.compile(r"^#[0-9a-f]{6}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_FONT_FILE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*\.woff2$")
_FONT_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 -]{0,63}$")
_ALIAS = re.compile(r"^\{([a-z0-9.-]+)\}$")
_GENERIC_FAMILIES = frozenset({"serif", "sans-serif", "monospace", "system-ui", "cursive"})
_GROUP_FIELDS = frozenset({"$type", "$description", "$root"})
_TOKEN_FIELDS = frozenset({"$value", "$type", "$description", "$extensions"})
_TYPES = frozenset({"color", "dimension", "duration", "fontFamily", "shadow", "border"})
_SHARED_GROUPS = frozenset(
    {
        "radius",
        "font",
        "text",
        "space",
        "sidebar",
        "content",
        "measure",
        "field",
        "breakpoint",
        "focus",
        "duration",
    }
)
_DIMENSION_UNITS = frozenset({"px", "rem"})
# Line length is a measure in characters; `ch` is accepted in this one group only.
_MEASURE_UNITS = frozenset({"ch"})
_DURATION_UNITS = frozenset({"ms", "s"})
_BORDER_STYLES = frozenset({"solid", "dashed", "dotted"})


class TokenError(ValueError):
    """The token file is not valid; the message names the token path."""


class ContrastPairError(ValueError):
    """The contrast pair list is not valid."""


@dataclass(frozen=True)
class Rgba:
    """An sRGB colour with 8 bits per channel and an alpha between 0 and 1."""

    r: int
    g: int
    b: int
    alpha: float

    @property
    def hex(self) -> str:
        return f"#{self.r:02x}{self.g:02x}{self.b:02x}"

    @property
    def channels(self) -> str:
        """``r g b`` for ``rgb(var(--x-rgb) / <alpha>)``."""
        return f"{self.r} {self.g} {self.b}"

    def css(self) -> str:
        if self.alpha == 1:
            return self.hex
        return f"rgb({self.channels} / {_number(round(self.alpha * 100, 2))}%)"


@dataclass(frozen=True)
class FontFace:
    family: str
    weight: int
    style: str
    file: str
    sha256: str


@dataclass(frozen=True)
class Theme:
    name: str
    colors: dict[str, Rgba]
    variables: dict[str, str]
    derived: dict[str, Rgba] = field(default_factory=dict)
    subtle: dict[str, Rgba] = field(default_factory=dict)


@dataclass(frozen=True)
class TokenSet:
    """The parsed token file: CSS variables per theme and shared, plus font faces."""

    themes: dict[str, Theme]
    shared: dict[str, str]
    font_faces: tuple[FontFace, ...]
    families: dict[str, tuple[str, ...]] = field(default_factory=dict)


# --- reading -------------------------------------------------------------------


def load_tokens(path: Path) -> TokenSet:
    """Read and validate a token file."""
    return parse_tokens(_read_json(path))


def _read_json(path: Path) -> object:
    try:
        size = path.stat().st_size
        if not path.is_file():
            raise TokenError(f"{path.name}: not a regular file")
        if size > MAX_FILE_BYTES:
            raise TokenError(f"{path.name}: larger than {MAX_FILE_BYTES} bytes")
        return json.loads(path.read_bytes().decode("utf-8"))
    except OSError as exc:
        raise TokenError(f"{path.name}: cannot read ({exc.strerror})") from None
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise TokenError(f"{path.name}: not UTF-8 JSON ({type(exc).__name__})") from None


def parse_tokens(doc: object) -> TokenSet:
    """Validate a decoded token document and derive the CSS variables."""
    if not isinstance(doc, dict):
        raise TokenError("token file: top level is not an object")
    for key in doc:
        if key.startswith("$") and key != "$description":
            raise TokenError(f"token file: unknown field {key!r}")
        if not key.startswith("$") and key not in _SHARED_GROUPS and key not in THEMES:
            raise TokenError(f"token file: unknown group {key!r}")
    for theme in THEMES:
        if not isinstance(doc.get(theme), dict):
            raise TokenError(f"token file: theme group {theme!r} is missing")
    parser = _Parser()
    themes: dict[str, Theme] = {}
    for theme in THEMES:
        tokens = parser.walk(doc[theme], (theme,), None)
        themes[theme] = parser.theme(theme, tokens)
    shared_tokens: list[_Token] = []
    for key, group in doc.items():
        if key.startswith("$") or key in THEMES:
            continue
        shared_tokens.extend(parser.walk(group, (key,), None))
    shared = parser.variables(shared_tokens, None)
    light, dark = themes["light"], themes["dark"]
    if set(light.variables) != set(dark.variables):
        only = sorted(set(light.variables) ^ set(dark.variables))
        raise TokenError(f"token file: defined in one theme only: {', '.join(only)}")
    clash = sorted(set(shared) & set(light.variables))
    if clash:
        raise TokenError(f"token file: shared and theme token share a name: {', '.join(clash)}")
    return TokenSet(
        themes=themes,
        shared=shared,
        font_faces=tuple(parser.faces),
        families=dict(parser.families),
    )


@dataclass(frozen=True)
class _Token:
    path: tuple[str, ...]
    type: str
    value: Any


class _Parser:
    def __init__(self) -> None:
        self.faces: list[FontFace] = []
        self.families: dict[str, tuple[str, ...]] = {}

    def walk(self, node: object, path: tuple[str, ...], inherited: str | None) -> list[_Token]:
        where = ".".join(path)
        if not isinstance(node, dict):
            raise TokenError(f"{where}: not an object")
        if "$value" in node:
            return [self._token(node, path, inherited)]
        unknown = sorted(k for k in node if k.startswith("$") and k not in _GROUP_FIELDS)
        if unknown:
            raise TokenError(f"{where}: unknown group field {unknown[0]!r}")
        group_type = node.get("$type", inherited)
        if group_type is not None and group_type not in _TYPES:
            raise TokenError(f"{where}: unsupported $type")
        _description(node, where)
        found: list[_Token] = []
        for key, child in node.items():
            if key in ("$type", "$description"):
                continue
            if key != "$root" and not _NAME.match(key):
                raise TokenError(f"{where}: invalid token name {key!r}")
            found.extend(self.walk(child, (*path, key), group_type))
        if not found:
            raise TokenError(f"{where}: empty group")
        return found

    def _token(self, node: dict[str, Any], path: tuple[str, ...], inherited: str | None) -> _Token:
        where = ".".join(path)
        unknown = sorted(set(node) - _TOKEN_FIELDS)
        if unknown:
            raise TokenError(f"{where}: unknown token field {unknown[0]!r}")
        kind = node.get("$type", inherited)
        if kind not in _TYPES:
            raise TokenError(f"{where}: unsupported or missing $type")
        _description(node, where)
        if "$extensions" in node:
            if kind != "fontFamily":
                raise TokenError(f"{where}: $extensions only on font families")
            self._faces(node["$extensions"], node["$value"], where)
        elif kind == "fontFamily":
            raise TokenError(f"{where}: font family without its font files")
        return _Token(path, kind, node["$value"])

    def _faces(self, extensions: object, value: object, where: str) -> None:
        if not isinstance(extensions, dict) or set(extensions) != {EXTENSION}:
            raise TokenError(f"{where}: $extensions may only hold {EXTENSION!r}")
        data = extensions[EXTENSION]
        if not isinstance(data, dict) or set(data) != {"faces"}:
            raise TokenError(f"{where}: {EXTENSION} holds exactly 'faces'")
        faces = data["faces"]
        if not isinstance(faces, list) or not faces:
            raise TokenError(f"{where}: faces is not a non-empty list")
        family = _font_family(value, where)[0]
        for index, face in enumerate(faces):
            at = f"{where}.faces[{index}]"
            if not isinstance(face, dict) or set(face) != {"weight", "style", "file", "sha256"}:
                raise TokenError(f"{at}: needs exactly weight, style, file, sha256")
            weight, style = face["weight"], face["style"]
            name, digest = face["file"], face["sha256"]
            if type(weight) is not int or weight not in range(100, 1000, 100):
                raise TokenError(f"{at}: weight is not one of 100..900")
            if style not in ("normal", "italic"):
                raise TokenError(f"{at}: style is not normal or italic")
            if not isinstance(name, str) or not _FONT_FILE.match(name):
                raise TokenError(f"{at}: file is not a plain .woff2 name")
            if not isinstance(digest, str) or not _SHA256.match(digest):
                raise TokenError(f"{at}: sha256 is not 64 lowercase hex digits")
            self.faces.append(FontFace(family, weight, style, name, digest))

    def theme(self, name: str, tokens: list[_Token]) -> Theme:
        colors: dict[str, Rgba] = {}
        for token in tokens:
            if token.path[1:2] == ("color",):
                if token.type != "color" or len(token.path) != 3:  # noqa: PLR2004 - theme.color.role
                    raise TokenError(f"{'.'.join(token.path)}: colour roles are flat colours")
                colors[token.path[2]] = _color(token.value, ".".join(token.path))
        variables = self.variables(tokens, name)
        for role, color in colors.items():
            channel = f"--pk-color-{role}-rgb"
            if channel in variables:
                raise TokenError(f"{name}.color.{role}: channel variable name is taken")
            variables[channel] = color.channels
        derived = derive_state_colors(colors, name)
        for role, color in derived.items():
            variable = f"--pk-color-{role}"
            if role in colors or variable in variables:
                raise TokenError(f"{name}.color.{role}: name of a derived colour is taken")
            variables[variable] = color.hex
        subtle = derive_subtle_colors(colors, name)
        for role, color in subtle.items():
            variable = f"--pk-color-{role}"
            if role in colors or variable in variables:
                raise TokenError(f"{name}.color.{role}: name of a derived colour is taken")
            variables[variable] = color.hex
        return Theme(name=name, colors=colors, variables=variables, derived=derived, subtle=subtle)

    def variables(self, tokens: Iterable[_Token], theme: str | None) -> dict[str, str]:
        out: dict[str, str] = {}
        for token in tokens:
            parts = [p for p in token.path[1 if theme else 0 :] if p != "$root"]
            name = "--pk-" + "-".join(parts)
            if name in out:
                raise TokenError(f"{'.'.join(token.path)}: CSS name {name} is used twice")
            out[name] = self._render(token, theme)
            if token.type == "fontFamily":
                self.families[name] = _font_family(token.value, ".".join(token.path))
        return out

    def _render(self, token: _Token, theme: str | None) -> str:
        where = ".".join(token.path)
        renderers: dict[str, Callable[[Any, str], str]] = {
            "color": lambda v, w: _color(v, w).css(),
            "dimension": _dimension,
            "duration": _duration,
            "fontFamily": lambda v, w: ", ".join(_quote_family(f) for f in _font_family(v, w)),
            "shadow": _shadow,
        }
        if token.type == "border":
            return _border(token.value, where, theme)
        return renderers[token.type](token.value, where)


def _description(node: Mapping[str, Any], where: str) -> None:
    text = node.get("$description", "")
    if not isinstance(text, str) or len(text) > 500:  # noqa: PLR2004 - length limit
        raise TokenError(f"{where}: $description is not a string of at most 500 characters")


def _number(value: float) -> str:
    if value == int(value):
        return str(int(value))
    return f"{value:.4f}".rstrip("0").rstrip(".")


def _color(value: object, where: str) -> Rgba:
    if not isinstance(value, dict):
        raise TokenError(f"{where}: colour value is not an object")
    if (
        not {"colorSpace", "components", "hex"}
        <= set(value)
        <= {
            "colorSpace",
            "components",
            "alpha",
            "hex",
        }
    ):
        raise TokenError(f"{where}: colour needs colorSpace, components, hex (alpha optional)")
    if value["colorSpace"] != "srgb":
        raise TokenError(f"{where}: only the srgb colour space is accepted")
    components, hex_value = value["components"], value["hex"]
    alpha = value.get("alpha", 1)
    if (
        not isinstance(components, list)
        or len(components) != 3  # noqa: PLR2004 - r, g, b
        or not all(_unit_number(c) for c in components)
    ):
        raise TokenError(f"{where}: components are not three numbers between 0 and 1")
    if not _unit_number(alpha):
        raise TokenError(f"{where}: alpha is not a number between 0 and 1")
    if not isinstance(hex_value, str) or not _HEX.match(hex_value):
        raise TokenError(f"{where}: hex is not #rrggbb in lowercase")
    channels = [int(hex_value[i : i + 2], 16) for i in (1, 3, 5)]
    if [math.floor(c * 255 + 0.5) for c in components] != channels:
        raise TokenError(f"{where}: hex and components disagree")
    return Rgba(channels[0], channels[1], channels[2], float(alpha))


def _is_number(value: object) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool)


def _unit_number(value: object) -> bool:
    return _is_number(value) and 0 <= value <= 1  # type: ignore[operator]


def _dimension(value: object, where: str) -> str:
    if where.split(".", 1)[0] == "measure":
        return _measure(value, where, _DIMENSION_UNITS | _MEASURE_UNITS)
    return _measure(value, where, _DIMENSION_UNITS)


def _duration(value: object, where: str) -> str:
    return _measure(value, where, _DURATION_UNITS)


def _measure(value: object, where: str, units: frozenset[str]) -> str:
    if not isinstance(value, dict) or set(value) != {"value", "unit"}:
        raise TokenError(f"{where}: needs exactly value and unit")
    number, unit = value["value"], value["unit"]
    if not _is_number(number) or not 0 <= number <= MAX_MEASURE:
        raise TokenError(f"{where}: value is not a number between 0 and {MAX_MEASURE}")
    if unit not in units:
        raise TokenError(f"{where}: unit is not one of {', '.join(sorted(units))}")
    if number == 0 and unit in _DIMENSION_UNITS | _MEASURE_UNITS:
        return "0"
    return f"{_number(number)}{unit}"


def _font_family(value: object, where: str) -> tuple[str, ...]:
    names = [value] if isinstance(value, str) else value
    if (
        not isinstance(names, list)
        or not names
        or not all(isinstance(n, str) and _FONT_NAME.match(n) for n in names)
    ):
        raise TokenError(f"{where}: font family is not a list of plain family names")
    return tuple(names)


def _quote_family(name: str) -> str:
    return name if name in _GENERIC_FAMILIES else f'"{name}"'


def _shadow(value: object, where: str) -> str:
    layers = value if isinstance(value, list) else [value]
    if not layers:
        raise TokenError(f"{where}: shadow without layers")
    rendered = []
    for layer in layers:
        fields = {"color", "offsetX", "offsetY", "blur", "spread"}
        if not isinstance(layer, dict) or set(layer) != fields:
            raise TokenError(f"{where}: shadow layer needs exactly {', '.join(sorted(fields))}")
        parts = [_dimension(layer[k], where) for k in ("offsetX", "offsetY", "blur")]
        spread = _dimension(layer["spread"], where)
        if spread != "0":
            parts.append(spread)
        parts.append(_color(layer["color"], where).css())
        rendered.append(" ".join(parts))
    return ", ".join(rendered)


def _border(value: object, where: str, theme: str | None) -> str:
    if not isinstance(value, dict) or set(value) != {"color", "width", "style"}:
        raise TokenError(f"{where}: border needs exactly color, width, style")
    if value["style"] not in _BORDER_STYLES:
        raise TokenError(f"{where}: border style is not one of solid, dashed, dotted")
    color = value["color"]
    if isinstance(color, str):
        match = _ALIAS.match(color)
        parts = match.group(1).split(".") if match else []
        if theme is None or len(parts) != 3 or parts[:2] != [theme, "color"]:  # noqa: PLR2004
            raise TokenError(f"{where}: border colour may only refer to a colour of its theme")
        rendered = f"var(--pk-color-{parts[2]})"
    else:
        rendered = _color(color, where).css()
    return f"{_dimension(value['width'], where)} {value['style']} {rendered}"


# --- derived interaction colours ----------------------------------------------------

#: Colours every theme gets besides the roles of the token file (KIT-047).
DERIVED_ROLES = (
    "primary-hover",
    "primary-active",
    "error-hover",
    "surface-hover",
    "disabled-bg",
    "disabled-fg",
    "surface-sunken",
)
#: OKLCH lightness step of a filled control per state (hover one step, pressed two).
FILL_STEP = 0.06
#: OKLCH lightness step of a surface towards the text colour.
SURFACE_STEP = 0.05
#: OKLCH lightness step of the sunken surface below the page ground (KIT-048).
SUNKEN_STEP = 0.03
# A fill darker than this gets lighter on hover, a lighter one darker; both keep their label.
_DARK_FILL = 0.4
_DERIVED_FROM = ("primary", "error", "surface-raised", "surface-page", "text", "text-muted")


def oklch(color: Rgba) -> tuple[float, float, float]:
    """OKLCH lightness, chroma and hue (radians) of an sRGB colour (CSS Color 4 matrices)."""
    r, g, b = (_linear(c) for c in (color.r, color.g, color.b))
    lms = (
        0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b,
        0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b,
        0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b,
    )
    l_, m_, s_ = (math.copysign(abs(v) ** (1 / 3), v) for v in lms)
    lightness = 0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_
    a = 1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_
    b_ = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_
    return lightness, math.hypot(a, b_), math.atan2(b_, a)


def _gamma(linear: float) -> float:
    x = min(1.0, max(0.0, linear))
    return 12.92 * x if x <= 0.0031308 else 1.055 * x ** (1 / 2.4) - 0.055  # noqa: PLR2004


def from_oklch(lightness: float, chroma: float, hue: float) -> Rgba:
    """An opaque 8-bit sRGB colour; channels outside the gamut are clipped."""
    lightness = min(1.0, max(0.0, lightness))
    a, b = chroma * math.cos(hue), chroma * math.sin(hue)
    l_ = (lightness + 0.3963377774 * a + 0.2158037573 * b) ** 3
    m_ = (lightness - 0.1055613458 * a - 0.0638541728 * b) ** 3
    s_ = (lightness - 0.0894841775 * a - 1.2914855480 * b) ** 3
    linear = (
        4.0767416621 * l_ - 3.3077115913 * m_ + 0.2309699292 * s_,
        -1.2684380046 * l_ + 2.6097574011 * m_ - 0.3413193965 * s_,
        -0.0041960863 * l_ - 0.7034186147 * m_ + 1.7076147010 * s_,
    )
    r, g, b8 = (min(255, max(0, math.floor(_gamma(v) * 255 + 0.5))) for v in linear)
    return Rgba(r, g, b8, 1.0)


def _fill_step(color: Rgba, steps: int) -> Rgba:
    lightness, chroma, hue = oklch(color)
    delta = FILL_STEP if lightness < _DARK_FILL else -FILL_STEP
    return from_oklch(lightness + steps * delta, chroma, hue)


def _towards(color: Rgba, target: Rgba, step: float) -> Rgba:
    lightness, chroma, hue = oklch(color)
    delta = step if oklch(target)[0] > lightness else -step
    return from_oklch(lightness + delta, chroma, hue)


def _away(color: Rgba, other: Rgba, step: float) -> Rgba:
    lightness, chroma, hue = oklch(color)
    delta = -step if oklch(other)[0] > lightness else step
    return from_oklch(lightness + delta, chroma, hue)


def derive_state_colors(colors: Mapping[str, Rgba], theme: str) -> dict[str, Rgba]:
    """Hover, pressed and disabled colours of one theme, in the order of :data:`DERIVED_ROLES`.

    Filled controls (primary, error) step their lightness by :data:`FILL_STEP`
    per state, lighter for a dark fill and darker for a light one; the surface
    hover and the disabled ground step towards the text colour; the disabled
    text is the muted text without chroma; the sunken surface (wells, unavailable
    cards and tiles) steps the page ground by :data:`SUNKEN_STEP` away from the
    raised surface, one step further from it than the page.
    """
    missing = [r for r in _DERIVED_FROM if r not in colors]
    if missing:
        raise TokenError(f"{theme}.color.{missing[0]}: needed for the derived state colours")
    muted_l, _, muted_h = oklch(colors["text-muted"])
    derived = {
        "primary-hover": _fill_step(colors["primary"], 1),
        "primary-active": _fill_step(colors["primary"], 2),
        "error-hover": _fill_step(colors["error"], 1),
        "surface-hover": _towards(colors["surface-raised"], colors["text"], SURFACE_STEP),
        "disabled-bg": _towards(colors["surface-page"], colors["text"], SURFACE_STEP),
        "disabled-fg": from_oklch(muted_l, 0.0, muted_h),
        "surface-sunken": _away(colors["surface-page"], colors["surface-raised"], SUNKEN_STEP),
    }
    return {role: derived[role] for role in DERIVED_ROLES}


#: Tinted surfaces of the four states (toast, inline alert, error message; KIT-049).
SUBTLE_ROLES = ("info-subtle", "success-subtle", "warning-subtle", "error-subtle")
#: Share of the state colour in its subtle surface, per theme. A dark ground needs more
#: of it to show the tint; both keep text at 4.5 : 1 and the state colour at 3 : 1.
SUBTLE_SHARE = {"light": 0.10, "dark": 0.16}


def _mix(ground: Rgba, color: Rgba, share: float) -> Rgba:
    """``share`` of ``color`` over ``ground`` in sRGB, opaque (CSS ``color-mix(in srgb)``)."""
    channels = (
        math.floor(g + (c - g) * share + 0.5)
        for g, c in ((ground.r, color.r), (ground.g, color.g), (ground.b, color.b))
    )
    r, g, b = channels
    return Rgba(r, g, b, 1.0)


def derive_subtle_colors(colors: Mapping[str, Rgba], theme: str) -> dict[str, Rgba]:
    """The subtle surface of each state: the state colour mixed into ``surface-raised``."""
    needed = ("surface-raised", *(r.removesuffix("-subtle") for r in SUBTLE_ROLES))
    missing = [r for r in needed if r not in colors]
    if missing:
        raise TokenError(f"{theme}.color.{missing[0]}: needed for the subtle state surfaces")
    share = SUBTLE_SHARE[theme]
    return {
        role: _mix(colors["surface-raised"], colors[role.removesuffix("-subtle")], share)
        for role in SUBTLE_ROLES
    }


# --- contrast ------------------------------------------------------------------

#: WCAG 2.1 minimum per kind; a pair file may ask for more, never for less.
WCAG_MINIMUM = {"text": 4.5, "large-text": 3.0, "ui": 3.0}


@dataclass(frozen=True)
class ContrastPair:
    fg: str
    bg: str
    kind: str
    use: str


@dataclass(frozen=True)
class ContrastPairs:
    thresholds: dict[str, float]
    pairs: tuple[ContrastPair, ...]

    def __len__(self) -> int:
        return len(self.pairs)

    def __iter__(self) -> Iterator[ContrastPair]:
        return iter(self.pairs)


@dataclass(frozen=True)
class ContrastResult:
    theme: str
    pair: ContrastPair
    ratio: float
    minimum: float

    @property
    def ok(self) -> bool:
        return self.ratio >= self.minimum


def _linear(channel: int) -> float:
    value = channel / 255
    return value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4  # noqa: PLR2004


def relative_luminance(color: Rgba) -> float:
    """WCAG 2.1 relative luminance of an opaque sRGB colour."""
    return 0.2126 * _linear(color.r) + 0.7152 * _linear(color.g) + 0.0722 * _linear(color.b)


def contrast_ratio(a: Rgba, b: Rgba) -> float:
    """WCAG 2.1 contrast ratio between two opaque colours (1 to 21)."""
    la, lb = relative_luminance(a), relative_luminance(b)
    high, low = max(la, lb), min(la, lb)
    return (high + 0.05) / (low + 0.05)


def load_pairs(path: Path) -> ContrastPairs:
    """Read and validate ``contrast-pairs.yaml``."""
    try:
        if path.stat().st_size > MAX_FILE_BYTES:
            raise ContrastPairError(f"{path.name}: larger than {MAX_FILE_BYTES} bytes")
        doc = yaml.safe_load(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ContrastPairError(f"{path.name}: cannot read ({exc.strerror})") from None
    except (UnicodeDecodeError, yaml.YAMLError) as exc:
        raise ContrastPairError(f"{path.name}: not UTF-8 YAML ({type(exc).__name__})") from None
    return parse_pairs(doc)


def parse_pairs(doc: object) -> ContrastPairs:
    if not isinstance(doc, dict) or set(doc) != {"version", "thresholds", "pairs"}:
        raise ContrastPairError("pairs: needs exactly version, thresholds, pairs")
    if doc["version"] != 1:
        raise ContrastPairError("pairs: unsupported version")
    thresholds = doc["thresholds"]
    if not isinstance(thresholds, dict) or set(thresholds) != set(WCAG_MINIMUM):
        raise ContrastPairError("pairs: thresholds need exactly text, large-text, ui")
    for kind, minimum in WCAG_MINIMUM.items():
        value = thresholds[kind]
        if not _is_number(value) or not minimum <= value <= 21:  # noqa: PLR2004
            raise ContrastPairError(f"pairs: threshold {kind} is below the WCAG minimum")
    entries = doc["pairs"]
    if not isinstance(entries, list) or not entries:
        raise ContrastPairError("pairs: pairs is not a non-empty list")
    pairs = []
    for index, entry in enumerate(entries):
        if not isinstance(entry, dict) or set(entry) != {"fg", "bg", "kind", "use"}:
            raise ContrastPairError(f"pairs[{index}]: needs exactly fg, bg, kind, use")
        if entry["kind"] not in WCAG_MINIMUM:
            raise ContrastPairError(f"pairs[{index}]: kind is not text, large-text or ui")
        if not all(isinstance(entry[k], str) and entry[k] for k in ("fg", "bg", "use")):
            raise ContrastPairError(f"pairs[{index}]: fg, bg and use are non-empty strings")
        pairs.append(ContrastPair(entry["fg"], entry["bg"], entry["kind"], entry["use"]))
    return ContrastPairs({k: float(v) for k, v in thresholds.items()}, tuple(pairs))


def check_contrast(tokens: TokenSet, pairs: ContrastPairs) -> list[ContrastResult]:
    """Contrast of every pair in every theme, in pair order, light first."""
    results = []
    for name in THEMES:
        theme = tokens.themes[name]
        colors = {**theme.colors, **theme.derived, **theme.subtle}
        for index, pair in enumerate(pairs.pairs):
            for role in (pair.fg, pair.bg):
                if role not in colors:
                    raise ContrastPairError(f"pairs[{index}]: {role!r} is not a colour role")
                if colors[role].alpha != 1:
                    raise ContrastPairError(f"pairs[{index}]: {role!r} is not opaque")
            ratio = contrast_ratio(colors[pair.fg], colors[pair.bg])
            results.append(ContrastResult(name, pair, ratio, pairs.thresholds[pair.kind]))
    return results


def contrast_report(results: Sequence[ContrastResult]) -> str:
    """One line per result and a summary line."""
    lines = []
    for r in results:
        mark = "ok  " if r.ok else "FAIL"
        lines.append(
            f"{mark} {r.theme} {r.pair.fg} on {r.pair.bg} ({r.pair.kind}): "
            f"{r.ratio:.2f} : 1, minimum {r.minimum:g} : 1"
        )
    failed = sum(not r.ok for r in results)
    lines.append(f"{len(results)} pairs, {failed} failed")
    return "\n".join(lines)
