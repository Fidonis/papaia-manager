"""``papaia-kit base``: expected computed styles and the fixture page of the base layer.

``expected`` writes ``contract/base-expected.<theme>.json`` from the token file
and ``contract/base.yaml``, or with ``--check`` names every file that differs.
``page`` prints the fixture document (browser test of the base layer).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

from papaia_kit._resources import contract_dir, tokens_dir
from papaia_kit.ui.base import BaseError, base_page, expected_text, load_base
from papaia_kit.ui.shell import ShellInputError
from papaia_kit.ui.tokens import THEMES, TokenError, load_tokens

__all__ = ["add_parser", "run"]

EXIT_OK, EXIT_FAIL, EXIT_USAGE = 0, 1, 2


def add_parser(groups: Any) -> None:
    """Arguments of ``base``; ``groups`` is the top-level subparsers action."""
    base = groups.add_parser("base", help="base layer contract and fixture page")
    sub = base.add_subparsers(dest="command", required=True)
    expected = sub.add_parser("expected", help="write or check base-expected.<theme>.json")
    expected.add_argument("--check", action="store_true", help="compare instead of writing")
    expected.add_argument("--out", type=Path, help="target directory (default: the kit's contract)")
    page = sub.add_parser("page", help="print the fixture document of the base layer")
    page.add_argument("--lang", choices=("de", "en"), default="de")
    page.add_argument("--theme", choices=THEMES, default="light")


def run(args: argparse.Namespace) -> int:
    try:
        if args.command == "page":
            sys.stdout.write(base_page(lang=args.lang, theme=args.theme))
            return EXIT_OK
        return _expected(args.out or contract_dir(), check=args.check)
    except (BaseError, TokenError, ShellInputError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_FAIL
    except (OSError, UnicodeDecodeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE


def _expected(folder: Path, *, check: bool) -> int:
    tokens = load_tokens(tokens_dir() / "papaia.tokens.json")
    base = load_base(tokens=tokens)
    wanted = {f"base-expected.{t}.json": expected_text(base, tokens, t) for t in THEMES}
    if check:
        problems = [
            f"{'missing' if not (folder / n).is_file() else 'changed'}: {n}"
            for n, text in wanted.items()
            if not (folder / n).is_file() or (folder / n).read_text(encoding="utf-8") != text
        ]
        for problem in problems:
            print(problem, file=sys.stderr)
        if problems:
            print(
                "base expected values are not current: run `papaia-kit base expected`",
                file=sys.stderr,
            )
            return EXIT_FAIL
        print(f"base expected: {len(wanted)} file(s) current")
        return EXIT_OK
    for name, text in wanted.items():
        (folder / name).write_text(text, encoding="utf-8")
    print(f"base expected: wrote {len(wanted)} file(s)")
    return EXIT_OK
