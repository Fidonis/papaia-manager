"""Normalisation of shell HTML before the character comparison (``contract/shell/normalize.md``).

The rules make the output independent of the rendering module, of per-request
values and of the module's own content, so that every module's rendering of a
reference input equals ``contract/shell/expected/<input>.html``:

1. Comments are dropped; the doctype is written ``<!doctype html>``.
2. One node per line: start tag, end tag or text. Text whitespace is collapsed
   and trimmed; whitespace-only text is dropped.
3. Attributes are sorted by name; values are written in double quotes with
   ``&``, ``<``, ``>`` and ``"`` escaped; an attribute without a value (such
   as ``defer``) is written as its bare name.
4. Per-request values become placeholders: ``nonce`` → ``{nonce}``, the value
   of ``input[name=pk_csrf]`` → ``{csrf}``, the kit version in
   ``meta[name=papaia-kit]`` and in ``/_kit/<version>/`` → ``{kit}``, and a
   checksum ``?v=<hex>`` in an asset path → ``{hash}``.
5. Module content is removed: the children of ``nav[data-pk-zone=nav]`` and of
   ``main#pk-main``.
6. The current module becomes ``{module}``: in the middle part of ``<title>``,
   in ``aria-label`` of ``nav[data-pk-zone=nav]``, in the ``summary`` (or the
   ``div``) of the switcher zone (text, ``aria-label`` and symbol), and the
   switcher list loses its ``aria-current`` and the ``data-pk-current-mark``
   symbol.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from html.parser import HTMLParser

__all__ = ["normalize_shell"]

VOID = frozenset({"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta",
                  "source", "track", "wbr"})  # fmt: skip
_KIT_PATH = re.compile(r"/_kit/\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?/")
_CHECKSUM = re.compile(r"\?v=[0-9a-f]{8,128}\b")
_ICON = re.compile(r"#pk-icon-[a-z0-9-]+$")
_TITLE_SEP = " – "
_TITLE_PARTS = 3  # page, module, installation


@dataclass
class _Node:
    tag: str
    attrs: list[tuple[str, str | None]] = field(default_factory=list)
    children: list[_Node | str] = field(default_factory=list)


class _TreeBuilder(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.root = _Node("#document")
        self.stack = [self.root]
        self.doctype = False

    def handle_decl(self, decl: str) -> None:
        if decl.lower().startswith("doctype"):
            self.doctype = True

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        node = _Node(tag, attrs)
        self.stack[-1].children.append(node)
        if tag not in VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        # A self-closed element (e.g. <use/>) has no children; it is written as open and close.
        self.stack[-1].children.append(_Node(tag, attrs))

    def handle_endtag(self, tag: str) -> None:
        for depth in range(len(self.stack) - 1, 0, -1):
            if self.stack[depth].tag == tag:
                del self.stack[depth:]
                return

    def handle_data(self, data: str) -> None:
        self.stack[-1].children.append(data)


def normalize_shell(html: str) -> str:
    """Normalised form of a shell document, one node per line, ending with a newline."""
    builder = _TreeBuilder()
    builder.feed(html)
    builder.close()
    root = builder.root
    module = _module_name(root)
    _rewrite(root, module, in_switcher=False)
    lines = ["<!doctype html>"] if builder.doctype else []
    for child in root.children:
        _write(child, lines)
    return "\n".join(lines) + "\n"


def _module_name(root: _Node) -> str | None:
    for node in _walk(root):
        if node.tag == "nav" and _get(node, "data-pk-zone") == "nav":
            return _get(node, "aria-label")
    return None


def _rewrite(node: _Node, module: str | None, *, in_switcher: bool) -> None:
    zone = _get(node, "data-pk-zone")
    if zone == "nav" or (node.tag == "main" and _get(node, "id") == "pk-main"):
        node.children = []
    if node.tag == "title" and module:
        node.children = [_title(_text(node), module)]
    if zone == "nav" and module:
        _set(node, "aria-label", "{module}")
    if zone == "switcher":
        in_switcher = True
        if node.tag == "div" and module:
            _module_part(node, module)
    if in_switcher and node.tag == "summary" and module:
        _module_part(node, module)
    attrs = []
    for name, value in node.attrs:
        if in_switcher and name == "aria-current":
            continue
        attrs.append((name, _value(node, name, value)))
    node.attrs = attrs
    kept: list[_Node | str] = []
    for child in node.children:
        if isinstance(child, _Node):
            if in_switcher and _has(child, "data-pk-current-mark"):
                continue
            _rewrite(child, module, in_switcher=in_switcher)
        kept.append(child)
    node.children = kept


def _module_part(node: _Node, module: str) -> None:
    """Replace the module name in the switcher's own label, text and symbol."""
    label = _get(node, "aria-label")
    if label is not None and label.endswith(module):
        _set(node, "aria-label", label[: len(label) - len(module)] + "{module}")
    for descendant in _walk(node):
        descendant.children = [
            "{module}" if isinstance(c, str) and " ".join(c.split()) == module else c
            for c in descendant.children
        ]
        if descendant.tag == "use" and descendant is _first_use(node):
            href = _get(descendant, "href") or ""
            _set(descendant, "href", _ICON.sub("#pk-icon-{module}", href))


def _first_use(node: _Node) -> _Node | None:
    return next((n for n in _walk(node) if n.tag == "use"), None)


def _title(text: str, module: str) -> str:
    parts = text.rsplit(_TITLE_SEP, _TITLE_PARTS - 1)
    if len(parts) == _TITLE_PARTS and parts[1] == module:
        parts[1] = "{module}"
    return _TITLE_SEP.join(parts)


def _value(node: _Node, name: str, value: str | None) -> str | None:
    if value is None:
        return None
    if name == "nonce":
        return "{nonce}"
    if node.tag == "input" and name == "value" and _get(node, "name") == "pk_csrf":
        return "{csrf}"
    if node.tag == "meta" and name == "content" and _get(node, "name") == "papaia-kit":
        return "{kit}"
    if name in {"href", "src", "action"}:
        value = _KIT_PATH.sub("/_kit/{kit}/", value)
        return _CHECKSUM.sub("?v={hash}", value)
    return value


def _write(item: _Node | str, lines: list[str]) -> None:
    if isinstance(item, str):
        text = " ".join(item.split())
        if text:
            lines.append(_escape_text(text))
        return
    attrs = "".join(
        f" {name}" if value is None else f' {name}="{_escape_attr(value)}"'
        for name, value in sorted(item.attrs, key=lambda a: a[0])
    )
    lines.append(f"<{item.tag}{attrs}>")
    if item.tag in VOID:
        return
    for child in item.children:
        _write(child, lines)
    lines.append(f"</{item.tag}>")


def _walk(node: _Node) -> list[_Node]:
    found = [node]
    for child in node.children:
        if isinstance(child, _Node):
            found.extend(_walk(child))
    return found


def _text(node: _Node) -> str:
    parts = [c if isinstance(c, str) else _text(c) for c in node.children]
    return " ".join("".join(parts).split())


def _get(node: _Node, name: str) -> str | None:
    return next((v for k, v in node.attrs if k == name), None)


def _has(node: _Node, name: str) -> bool:
    return any(k == name for k, _ in node.attrs)


def _set(node: _Node, name: str, value: str) -> None:
    node.attrs = [(k, value if k == name else v) for k, v in node.attrs]


def _escape_text(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _escape_attr(value: str) -> str:
    return _escape_text(value).replace('"', "&quot;")
