"""Helper for the core's actions on ``POST /internal/lifecycle``.

The core start gate (and ``recover-snapshot``) asks each module to apply its
erasure journal (``erasure-replay``) and to run its ``post-restore`` step. This
helper is framework-neutral: the module's server terminates mTLS, takes the
caller identity from the verified client certificate and hands body, caller
and correlation id to :meth:`LifecycleHandler.handle`. The module's own
account signals on the same route (``account.disabled`` and similar) are not
handled here; route them before calling the helper.
"""

from __future__ import annotations

import json
import re
import threading
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Literal

from papaia_kit.correlation import accept_correlation_id
from papaia_kit.erasure._audit import (
    AuditSink,
    audit_submission,
    check_writer,
    failure_code,
    replay_detail,
)
from papaia_kit.erasure._entry import JournalEntry, format_at
from papaia_kit.erasure._epoch import StartGate
from papaia_kit.erasure._journal import ErasureJournal
from papaia_kit.erasure._replay import ReplayTrigger, replay
from papaia_kit.errors import build_envelope

MAX_LIFECYCLE_BODY = 1024
DEFAULT_CALLERS = ("papaia-lifecycle",)

_CALLER = re.compile(r"[a-z][a-z0-9-]{0,62}")
_COUNT_NAME = re.compile(r"[a-z][a-z0-9_]{0,63}")
_MAX_COUNTS = 32


class LifecycleAction(StrEnum):
    ERASURE_REPLAY = "erasure-replay"
    POST_RESTORE = "post-restore"


class LifecycleRequestError(ValueError):
    """The request body is not a valid lifecycle action."""


def _unique_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    record = dict(pairs)
    if len(record) != len(pairs):
        raise LifecycleRequestError("duplicate field")
    return record


def parse_lifecycle_request(body: bytes | str | Mapping[str, object]) -> LifecycleAction:
    """The action of a request body ``{"action": "erasure-replay" | "post-restore"}``.

    The body is UTF-8 JSON of at most 1 KiB with exactly the field ``action``;
    anything else raises :class:`LifecycleRequestError` without repeating it.
    """
    record: object
    if isinstance(body, Mapping):
        record = dict(body)
    elif isinstance(body, (bytes, str)):
        raw = body.encode("utf-8") if isinstance(body, str) else body
        if not raw or len(raw) > MAX_LIFECYCLE_BODY:
            raise LifecycleRequestError("body is empty or too large")
        try:
            record = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_keys)
        except (UnicodeDecodeError, ValueError):
            raise LifecycleRequestError("body is not a JSON object") from None
    else:
        raise LifecycleRequestError("body is not a JSON object")
    if not isinstance(record, dict) or set(record) != {"action"}:
        raise LifecycleRequestError("body must hold exactly the field action")
    action = record["action"]
    if not isinstance(action, str):
        raise LifecycleRequestError("unknown action")
    try:
        return LifecycleAction(action)
    except ValueError:
        raise LifecycleRequestError("unknown action") from None


@dataclass(frozen=True)
class LifecycleResponse:
    """Status, JSON body and headers for the module's server to send."""

    status: int
    body: dict[str, object]
    headers: dict[str, str] = field(default_factory=lambda: {"Content-Type": "application/json"})


def _check_counts(counts: object) -> dict[str, int]:
    if counts is None:
        return {}
    if not isinstance(counts, Mapping) or len(counts) > _MAX_COUNTS:
        raise TypeError("post_restore must return a mapping of at most 32 counts")
    checked: dict[str, int] = {}
    for name, value in counts.items():
        if not isinstance(name, str) or not _COUNT_NAME.fullmatch(name):
            raise TypeError("post_restore count names must match [a-z][a-z0-9_]{0,63}")
        if type(value) is not int or value < 0:
            raise TypeError("post_restore counts must be non-negative integers")
        checked[name] = value
    return checked


def _now() -> datetime:
    return datetime.now(UTC)


class LifecycleHandler:
    """Runs ``erasure-replay`` and ``post-restore`` for the core.

    ``apply_entry`` applies one journal entry and stores ``entry.seq`` as the
    module's applied seq in the same transaction (see :func:`replay`);
    ``post_restore`` runs the module's post-restore step and returns counts
    only (``None`` for a module without one). Only callers named in
    ``allowed_callers`` (identity from the verified mTLS client certificate)
    are served. Every request writes exactly one ``papaia.audit/1`` submission
    of its own to ``audit`` (``erasure_replayed``, ``post_restore_applied`` or
    ``lifecycle_request_rejected``) with the request's correlation id; a
    successful ``erasure_replayed`` carries the :class:`ReplayResult` (trigger,
    counts per kind, ``replayed_from``, ``journal_end``, ``journal_behind``).
    The journal writes its own rows for what the replay changes in it
    (delivery, acknowledged renumbering) with the same correlation id. If the
    sink raises, the exception propagates; both actions are idempotent, so the
    core repeats the request. After a replay the gate is checked again; the
    response says whether the module is ready.
    """

    def __init__(
        self,
        *,
        journal: ErasureJournal,
        gate: StartGate,
        applied_seq: Callable[[], int],
        apply_entry: Callable[[JournalEntry], object],
        audit: AuditSink,
        writer: str,
        post_restore: Callable[[], Mapping[str, int] | None] | None = None,
        allowed_callers: Iterable[str] = DEFAULT_CALLERS,
        clock: Callable[[], datetime] = _now,
    ) -> None:
        if not isinstance(journal, ErasureJournal):
            raise TypeError("journal must be an ErasureJournal")
        if not isinstance(gate, StartGate):
            raise TypeError("gate must be a StartGate")
        for name, value in (
            ("applied_seq", applied_seq),
            ("apply_entry", apply_entry),
            ("audit", audit),
        ):
            if not callable(value):
                raise TypeError(f"{name} must be callable")
        if post_restore is not None and not callable(post_restore):
            raise TypeError("post_restore must be callable")
        callers: frozenset[object] = frozenset(allowed_callers)
        if not callers or not all(isinstance(c, str) and _CALLER.fullmatch(c) for c in callers):
            raise ValueError("allowed caller ids must be non-empty and match [a-z][a-z0-9-]*")
        self._journal = journal
        self._gate = gate
        self._applied_seq = applied_seq
        self._apply_entry = apply_entry
        self._post_restore = post_restore
        self._audit = audit
        self._writer = check_writer(writer)
        self._callers = callers
        self._clock = clock
        self._lock = threading.Lock()

    def handle(
        self,
        body: bytes | str | Mapping[str, object],
        *,
        caller: str | None,
        correlation_id: object,
    ) -> LifecycleResponse:
        cid = accept_correlation_id(correlation_id)
        if not isinstance(caller, str) or caller not in self._callers:
            # an unknown caller is not named in the event: the value comes
            # from outside the allow list and is not checked further
            return self._reject("PK-ACCESS-001", 403, cid, None)
        try:
            action = parse_lifecycle_request(body)
        except LifecycleRequestError:
            return self._reject("PK-INPUT-001", 400, cid, caller)
        with self._lock:
            if action is LifecycleAction.ERASURE_REPLAY:
                return self._erasure_replay(cid, caller)
            return self._post_restore_step(cid, caller)

    # --- actions ------------------------------------------------------------------

    def _erasure_replay(self, cid: str, caller: str) -> LifecycleResponse:
        event = "erasure_replayed"
        count: int | None = None
        try:
            read = self._journal.entries(correlation_id=cid)
            result = replay(
                read.entries,
                applied_seq=self._applied_seq(),
                handler=self._apply_entry,
                trigger=ReplayTrigger.LIFECYCLE,
            )
            # The entries are applied now; a failure below still ends in
            # exactly one audit submission (counting them) and an envelope.
            count = result.applied
            if not read.provisional:
                self._journal.acknowledge_renumbering(correlation_id=cid)
            check = self._gate.check()
        except Exception as exc:
            # Includes a failing module database (applied seq, handler) and an
            # unreadable gate directory; the cause is never passed on.
            code, status = failure_code(exc)
            return self._fail(event, code, status, cid, caller, count=count)
        self._write(event, "allowed", cid, caller, detail=replay_detail(result))
        return LifecycleResponse(
            200,
            {
                "action": LifecycleAction.ERASURE_REPLAY.value,
                "module": self._journal.module,
                "applied": result.applied,
                "applied_seq": result.last_seq,
                "by_kind": dict(result.by_kind),
                "provisional": read.provisional,
                "journal_behind": result.journal_behind,
                "state": check.state.value,
                "ready": check.ready,
            },
        )

    def _post_restore_step(self, cid: str, caller: str) -> LifecycleResponse:
        event = "post_restore_applied"
        try:
            counts = _check_counts(None if self._post_restore is None else self._post_restore())
        except Exception:
            return self._fail(event, "PK-INTERNAL-001", 500, cid, caller)
        self._write(event, "allowed", cid, caller, count=sum(counts.values()))
        return LifecycleResponse(
            200,
            {
                "action": LifecycleAction.POST_RESTORE.value,
                "module": self._journal.module,
                "counts": counts,
            },
        )

    # --- responses and audit -------------------------------------------------------

    def _error(self, code: str, status: int, cid: str) -> LifecycleResponse:
        envelope = build_envelope(code, correlation_id=cid, status=status)
        return LifecycleResponse(status, envelope.to_dict(), envelope.http_headers())

    def _reject(self, code: str, status: int, cid: str, caller: str | None) -> LifecycleResponse:
        self._write("lifecycle_request_rejected", "denied", cid, caller, error_code=code)
        return self._error(code, status, cid)

    def _fail(
        self,
        event: str,
        code: str,
        status: int,
        cid: str,
        caller: str,
        *,
        count: int | None = None,
    ) -> LifecycleResponse:
        self._write(event, "error", cid, caller, error_code=code, count=count)
        return self._error(code, status, cid)

    def _write(
        self,
        event: str,
        result: Literal["allowed", "denied", "error"],
        cid: str,
        caller: str | None,
        *,
        count: int | None = None,
        error_code: str | None = None,
        detail: Mapping[str, object] | None = None,
    ) -> None:
        self._audit(
            audit_submission(
                event=event,
                result=result,
                writer=self._writer,
                correlation_id=cid,
                module=self._journal.module,
                time=format_at(self._clock()),
                service_account=caller,
                error_code=error_code,
                count=count,
                detail=detail,
            )
        )
