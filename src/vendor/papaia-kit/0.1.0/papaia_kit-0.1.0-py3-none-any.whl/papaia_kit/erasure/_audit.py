"""``papaia.audit/1`` rows of the erasure journal: writes, deliveries and replays.

Rows name the module, the kind and ``seq`` of an entry and counts, never the
``sub``, the ``subject_ref``, the ``object_ref`` or the ``reason`` of an entry:
the journal holds references to deleted personal data, and the audit trail must
not become a second copy of them (PLT-19, sicherheit §4.9).
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from datetime import UTC, datetime
from typing import Literal

from papaia_kit.audit import AUDIT_FORMAT, validate_event
from papaia_kit.correlation import accept_correlation_id, new_correlation_id
from papaia_kit.erasure._entry import (
    JournalConflictError,
    JournalCorruptError,
    JournalGapError,
    JournalUnavailableError,
    check_module,
    format_at,
)
from papaia_kit.erasure._replay import ReplayResult

AuditSink = Callable[[dict[str, object]], object]
Result = Literal["allowed", "denied", "error"]

OBJECT_TYPE = "erasure_journal"


def check_sink(audit: object) -> AuditSink:
    """The sink a component hands its rows to, usually bound to an audit writer."""
    if not callable(audit):
        raise TypeError("audit must be callable (for example AuditWriter.write bound to a conn)")
    return audit


def check_writer(writer: object) -> str:
    """The audit ``writer`` (``<source>`` or ``<source>/<component>``), checked by the schema."""
    if not isinstance(writer, str):
        raise ValueError("writer must be a string")
    probe = audit_submission(
        event="erasure_replayed",
        result="allowed",
        writer=writer,
        correlation_id=new_correlation_id(),
        module="probe",
        time=format_at(datetime.now(UTC)),
    )
    try:
        validate_event({**probe, "source_seq": 1})
    except ValueError:
        raise ValueError("writer must be '<source>' or '<source>/<component>'") from None
    return writer


def failure_code(exc: BaseException) -> tuple[str, int]:
    """Error code and HTTP status of a failed journal or replay action."""
    if isinstance(exc, JournalUnavailableError):
        return "PK-UPSTREAM-001", 503
    if isinstance(exc, (JournalCorruptError, JournalConflictError, JournalGapError)):
        return "PK-CONFLICT-001", 409
    return "PK-INTERNAL-001", 500


def audit_submission(
    *,
    event: str,
    result: Result,
    writer: str,
    correlation_id: str,
    module: str,
    time: str,
    service_account: str | None = None,
    error_code: str | None = None,
    count: int | None = None,
    detail: Mapping[str, object] | None = None,
) -> dict[str, object]:
    """A ``papaia.audit/1`` submission without ``source_seq``; the audit writer assigns it."""
    fields: dict[str, object] = {} if count is None else {"count": count}
    if detail is not None:
        fields.update(detail)
    return {
        "format": AUDIT_FORMAT,
        "time": time,
        "correlation_id": correlation_id,
        "writer": writer,
        "role": "server",
        "identity_kind": None if service_account is None else "service",
        "service_account": service_account,
        "object_ref": {"type": OBJECT_TYPE, "id": module},
        "result": result,
        "error_code": error_code,
        "detail": fields or None,
        "event": event,
    }


def replay_detail(result: ReplayResult) -> dict[str, object]:
    """``detail`` of ``erasure_replayed``: counts and positions, no entry."""
    if not isinstance(result, ReplayResult):
        raise TypeError("result must be a ReplayResult")
    detail: dict[str, object] = {"count": result.applied}
    if result.last_seq > 0:
        detail["seq"] = result.last_seq
    detail.update(
        {
            "trigger": result.trigger.value,
            "by_kind": dict(result.by_kind),
            "replayed_from": result.replayed_from,
            "journal_end": result.journal_end,
            "journal_behind": result.journal_behind,
        }
    )
    return detail


def erasure_replayed_event(
    result: ReplayResult,
    *,
    module: str,
    writer: str,
    correlation_id: object,
    service_account: str | None = None,
    clock: Callable[[], datetime] | None = None,
) -> dict[str, object]:
    """The ``erasure_replayed`` row of one successful replay, for the module's audit writer.

    ``correlation_id`` is the id of the request that started the replay; an
    invalid or missing value is replaced by a new one. ``service_account`` names
    the caller (for example ``papaia-ctl``) when a service started the run.
    """
    return audit_submission(
        event="erasure_replayed",
        result="allowed",
        writer=check_writer(writer),
        correlation_id=accept_correlation_id(correlation_id),
        module=check_module(module),
        time=format_at((clock or _now)()),
        service_account=service_account,
        detail=replay_detail(result),
    )


def _now() -> datetime:
    return datetime.now(UTC)
