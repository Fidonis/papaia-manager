# Design tokens

One source for colours, radii, fonts and layout values of every user interface
of the platform. The values are those of the manager themes `fidonis-light`
and `fidonis-dark`; where the kit adds a role (`text-muted`, `nav-active-bg`),
it is listed with its contrast in `contrast-pairs.yaml`.

| File | Content |
|---|---|
| `papaia.tokens.json` | All values, [Design Tokens Format Module 2025.10](https://www.designtokens.org/TR/2025.10/format/), groups `light` and `dark` per theme, other groups shared; SHA-256 of every font file |
| `contrast-pairs.yaml` | Colour pairs that must meet WCAG 2.1 contrast in both themes |
| `media.yaml` | Register of every font and icon file: source, release, license, rights holder, retrieval date, SHA-256 |
| `assets/fonts/`, `assets/icons/` | The registered media files, unchanged from their source |
| `licenses/` | License texts of the media files |

`tools/build.py` generates `dist/` from these files. Generated files are
checked in and never edited by hand:

```sh
make tokens         # write dist/
make check-tokens   # dist/ is current (exit 1 names each differing file) and contrast passes
```

## Names

Each token becomes one CSS custom property `--pk-<path>`: the token path
without the theme group, joined by `-`; the DTCG name `$root` adds nothing.
`light.color.primary` is `--pk-color-primary`, `text.xs.$root` is
`--pk-text-xs`, `text.xs.line-height` is `--pk-text-xs-line-height`. Every
colour role also gets the channel variable `--pk-color-<role>-rgb` (`r g b`),
used only for opacity steps in the Tailwind preset, never for text.

The reader (`papaia_kit.ui.tokens`) refuses unknown `$` fields and groups,
colour spaces other than sRGB, a `hex` that disagrees with `components`,
aliases anywhere except the colour of a border (which may only refer to a
colour of its own theme), and roles defined in one theme only.

## Derived state colours

Every theme also gets the hover, pressed and disabled colours
`--pk-color-primary-hover`, `--pk-color-primary-active`,
`--pk-color-error-hover`, `--pk-color-surface-hover`,
`--pk-color-disabled-bg` and `--pk-color-disabled-fg`. They are not in the
token file: the reader derives them from the theme's roles by an OKLCH
lightness step (rules in [`contract/base.md`](../contract/base.md)) and the
build writes them out as hex; `contrast-pairs.yaml` lists them. The sunken
surface `--pk-color-surface-sunken` (ground of unavailable cards and tiles,
[`contract/patterns/README.md`](../contract/patterns/README.md)) is derived
the same way: the page ground one step of 0.03 away from the raised surface.
The tinted surfaces `--pk-color-info-subtle`, `--pk-color-success-subtle`,
`--pk-color-warning-subtle` and `--pk-color-error-subtle` (toast, inline
alert, notice zone, error message) are derived as well: the state colour
mixed into `surface-raised`, 10 % in the light and 16 % in the dark theme.
The shadows `--pk-shadow-sm` (hovered card or tile) and `--pk-shadow-md`
(menus and raised messages above the content) are theme tokens of the group
`shadow`. The group
`measure` is the only one that accepts the unit `ch` (line length).

## Generated files (`dist/`)

| Path | Content |
|---|---|
| `css/tokens.css` | `@font-face` rules and all `--pk-*` variables; `:root[data-theme="light"]`, `:root[data-theme="dark"]`, and without the attribute the system setting through `prefers-color-scheme` |
| `css/papaia-kit.css` | The stylesheet modules include: layer order `pk.tokens, pk.base, pk.shell, pk.patterns` and all four layers |
| `css/base.css` | The base layer alone: plain content elements and form controls in `#pk-main` ([`contract/base.md`](../contract/base.md)) |
| `tailwind/preset.cjs` | Tailwind CSS 3 preset: daisyUI themes `fidonis-light`/`fidonis-dark` with the literal values, colours `pk-<role>` on the channel variables, font families, radii |
| `fonts/*.woff2` | Manrope 500/700/800, IBM Plex Sans 400/500/600, IBM Plex Mono 400, with their license texts |
| `icons/sprite.svg` | Symbols `pk-icon-<name>`: module symbols (`chat`, `studio`, `data`, `flow`, `assistant`, `me`, `manager`), shell symbols, state and action symbols (Lucide names such as `circle-check`, `circle-x`, `plus`, `trash-2`, `loader`); use `<svg><use href="…/sprite.svg#pk-icon-check"/></svg>` |
| `icons/NOTICE.txt`, `icons/LICENSE-*.txt` | Every symbol with release, rights holder and license; the license texts |
| `keycloak/papaia/login/` | Login theme: `theme.properties` (from `ui/keycloak/`), `resources/css/tokens.css`, `resources/css/papaia-login.css` (token mapping) and the fonts |
| `proxy/{404,503}.{de,en}.html`, `signed-out.{de,en}.html` | Edge pages with the token values (without font files) and `ui/edge.css` embedded |
| `mail/notification.{html,txt}.j2` | Mail templates, copied unchanged from `ui/mail/` |
| `SHA256SUMS` | SHA-256 of every generated file |

Nothing is loaded from another host: fonts, icons and stylesheets are shipped
with each module.

## Changing a value

A changed value is a minor version and carries the mark `visual` in the
changelog with the old and the new value; a removed or renamed variable is a
major version. Change the token file, run `make tokens`, commit the token file
and `dist/` together.

## Adding a media file

Put the unchanged file under `assets/`, add an entry to `media.yaml` with its
SHA-256 and, for a new license, the license text under `licenses/`. A font file
also needs a face in the token file with the same SHA-256. The build refuses a
file without an entry, an entry without a file and every checksum that does
not match. Icons must be single-colour SVGs on a 24 × 24 grid with drawing
elements only (`path`, `circle`, `rect`, `line`, `polyline`, `polygon`,
`ellipse`); scripts, links, styles and references are refused.
