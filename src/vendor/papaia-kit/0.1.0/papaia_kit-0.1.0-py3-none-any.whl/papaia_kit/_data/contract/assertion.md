# Module context assertion `papaia_kit.assertion`

A server that receives the exchanged token of a person knows who acts, but not
which app, run, step or analysis asked. The module that calls (Studio, Flow,
Data, the assistant) therefore sends a short signed statement with each call:

```
X-Papaia-Module-Context: <compact JWS>
```

**The assertion grants nothing.** Rights come from the bearer token alone and
are checked by the check chain (`contract/authz.md`) first. A server that
ignores the header loses the attribution, not security; a server in `enforce`
mode gains a second check that the call came through a module of the platform.

It replaces the Studio-only header `X-Papaia-Studio-Context`.

## Format

Compact JWS (RFC 7515), algorithm ES256 over P-256 (RFC 7518 3.4), signature as
the raw 64 bytes `r || s`.

| Part | Value |
|---|---|
| JOSE header | exactly `alg: ES256`, `kid` (1 to 128 of `[A-Za-z0-9._-]`), `typ: papaia-module-context+jwt`; any other field (`crit`, `jwk`, `jku`, `x5u`, ...) is refused |
| `iss` | client of the calling module, a name of the naming register (`papaia-studio-gateway`, `flow-engine`, `papaia-data`, ...) |
| `sub` | `sub` of the bearer token sent alongside: 1 to 255 characters, no control characters, space or lone UTF-16 surrogates |
| `aud` | the single audience of the target server, equal to the `aud` of the bearer token |
| `ctx` | object with exactly `module` (`[a-z][a-z0-9-]{0,31}`), `kind` (a string: `app`, `run`, `step` or `analysis`; an array, object or number is malformed), `id` and `version` (each 1 to 63 of `[A-Za-z0-9._-]`, starting with a letter or digit; no colon) |
| `ath` | base64url without padding of SHA-256 over the ASCII bearer token, as `ath` in RFC 9449 section 4.2 |
| `iat`, `exp` | integers; `0 < exp - iat <= 60` |
| `jti` | 16 to 64 of `[A-Za-z0-9-]`, new for every call (the signer uses a UUIDv4) |

The claim set is closed: an unknown claim, a missing claim, a duplicate key or a
claim of the wrong type makes the assertion malformed. Neither `sub` nor `ctx`
carries names, groups or roles.

| Caller | `kind` | `id` | `version` |
|---|---|---|---|
| Studio | `app` | app id | released app version |
| Flow | `run` or `step` | run id, or step id unique within the module (for example `<run>.<step>`) | flow version |
| Data | `analysis` | analysis id | analysis version |

## Keys

Each module has its own P-256 signing key, mounted as a secret file and never
shared with another module. `ModuleContextSigner.public_jwk()` gives the public
half; the module publishes it in its JWKS with the platform catalog. A server
trusts a closed list of module clients, each with the key provider of its JWKS
(`KeySet` or `JwksCache` of `papaia_kit.authz`; only ES256 keys on P-256 are
used). Rotation: publish the new key, wait for the cache time of the servers,
then sign with it.

## Verification (normative)

A verifier runs these checks in this order and refuses with the code of the
first failure. Leeway for the times is 10 seconds.

| # | Check | Code |
|---|---|---|
| 1 | Header present and not blank | `missing` |
| 2 | At most 4096 characters, three base64url segments, header and claims as above | `malformed` |
| 3 | `iss` is one of the trusted module clients | `issuer` |
| 4 | `alg` is `ES256`, a P-256 key with `kid` in that module's JWKS, 64-byte signature valid | `signature` |
| 5 | `aud` equals the server's audience | `audience` |
| 6 | `now <= exp + leeway` | `expired` |
| 7 | `exp > iat`, `exp - iat <= 60`, `iat <= now + leeway` | `lifetime` |
| 8 | `ath` equals the hash of the presented bearer token | `token_binding` |
| 9 | `sub` equals the `sub` of the presented bearer token | `subject` |
| 10 | `(iss, jti)` not accepted within the last 120 seconds | `replay` |

Check 10 runs last and is one atomic step: `ReplayCache.claim(key, now)`
records `key` (`"<iss> <jti>"`) and returns true only if it was not recorded
within the last 120 seconds, else false. A separate look-up followed by a write
is not allowed, because two concurrent calls with one assertion would both
pass. A refused assertion never reaches the store, so it never burns the id of
a genuine one.

`LruReplayCache` (the default) keeps ids per process under one lock. Its limit
is `max_entries` (default 100,000) ids within their 120 seconds, about 830
accepted assertions per second per process. When the store is full it refuses
further claims with `replay` and logs `module context replay store full`; it
never drops an unexpired id, since that id could then be replayed. A server
with several worker processes, or with more traffic, passes a shared
`ReplayCache` whose `claim` is an insert-if-absent with expiry (for example
`SET <key> 1 NX EX 120` in a key-value store).

## Server modes

| Variable | Default | Meaning |
|---|---|---|
| `PAPAIA_MODULE_CONTEXT_MODE` | `off` | `off`: the header is ignored. `log`: verify, log the origin or the refusal code of every call, never refuse. `enforce`: refuse a call without a valid assertion with `PK-CONTEXT-001` (HTTP 403) |

Any other value fails at start (`Mode.from_env`). In the release state
servers run `log`; `enforce` suits servers that are reached only through
platform modules, because a direct caller (a chat client) has no assertion.

```python
from papaia_kit.assertion import HEADER, ContextDenied, ContextGuard, Mode
from papaia_kit.authz import JwksCache

guard = ContextGuard(
    config,  # the ServerConfig of the check chain
    {"papaia-studio-gateway": JwksCache(fetch_studio_jwks)},  # trusted modules
    mode=Mode.from_env(),
    audit=audit_writer.submit,
)

principal = chain.check(token, request)  # rights first
try:
    outcome = guard.check(headers.get(HEADER), token=token, principal=principal, request=request)
except ContextDenied as denied:
    return error_response(denied.status, denied.envelope)
row = {**row_of_the_operation, **principal.audit_fields()}
if outcome.context is not None:
    row.update(outcome.context.audit_fields())  # context: {"app": "belege:7"}
```

In `log` and `enforce` the guard writes one log line per call: on success
`module context: iss=<client> module=<module> <kind>=<id> version=<version>
correlation_id=<id>`, on a refusal `module context refused: code=<code>
mode=<mode> correlation_id=<id>`. It never logs the assertion or the token. In
`enforce` a refusal also hands one `papaia.audit/1` row (`result: denied`,
`event: operation`, `error_code: PK-CONTEXT-001`, the identity fields of the
principal) to the audit writer before `ContextDenied` is raised.

## Signing

```python
from pathlib import Path
from papaia_kit.assertion import HEADER, Kind, ModuleContextSigner

signer = ModuleContextSigner.from_pem_file(
    Path("/run/secrets/module-context.pem"),
    issuer="papaia-studio-gateway",
    kid="studio-2026-11",
    module="studio",
)
headers[HEADER] = signer.sign(
    token=exchanged_token,  # the token sent in Authorization
    audience="mcp-paperless",
    subject=person_sub,
    kind=Kind.APP,
    context_id="belege",
    version="7",
)
```

The signer validates every value against the format above before signing and
defaults to the maximum lifetime of 60 seconds (`lifetime_seconds` 1 to 60).

## Test vectors

`testing/vectors/module-context.v1.json` (in the wheel:
`papaia_kit.assertion.vectors_path()`) holds valid and invalid assertions with
the expected code, the public test key and a fixed `now`. A case with
`seen_before` is verified once successfully, then again (`replay`). Every
implementation, Studio and each server copies the file unchanged and runs it in
CI; `papaia-kit assertion vectors --compare <copy>` fails unless the copy is
byte for byte the kit's file. The file is rebuilt with
`python -m tests.assertion_vectors`; a rebuild signs with a new test key and is
a new version that every copy follows.
