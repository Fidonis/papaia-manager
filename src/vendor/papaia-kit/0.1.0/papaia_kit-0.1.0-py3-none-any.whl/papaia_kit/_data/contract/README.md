# Contract documents

Normative prose that accompanies the schemas in `../schemas`: field meanings,
examples and the rules a consumer or provider must follow. Where prose and schema
disagree, the schema wins and the prose is corrected.

| Document | Schemas |
|---|---|
| `platform-services.md` | `platform-services.v1`, `platform-groups.v1` |
| `catalog-reader.md` | Consumer behaviour for both files (reader of `papaia_kit.catalog`) |
| [`exposes.md`](exposes.md): manifest section `exposes:`, service accounts, backup of volumes, storage declaration, `/healthz` | `exposes.v1`, `healthz.v1` |
| [`conformance.md`](conformance.md): conformance suites `manifest`, `catalog-consumer`, `halt`, `recording`, `realm`, `server`; recording format of provider suites | `recording.v1` |
| [`exchange.md`](exchange.md): token exchange client `papaia_kit.exchange`, one audience per token, chain only as declared | none |
| [`me-contract.md`](me-contract.md): personal-area contract version 2, declaration `personal_settings:` and module API (groups, fields, collections, data, deletion receipts, 412/428, idempotency key, fresh sign-in) | `me-contract.v2` |
| [`tasks.md`](tasks.md): task item, task routes of a source, the collector `papaia_kit.tasks.collect()` | `task-item.v1` |
| [`authz.md`](authz.md): server-side check chain, `azp-allowlist.json`, chain origin, revocation list | `error.v1` (rejections) |
| [`shell/shell.md`](shell/shell.md): markup contract of the shell (zones, measures, switcher, account menu), reference inputs and expected outputs, [`shell/normalize.md`](shell/normalize.md) | `shell/input.schema.json` (`papaia.shell-input/1`) |
| [`pages.md`](pages.md): named targets, return parameter `from`, delegation targets, page list from module parts, administration map, places that depend on another module | `pages.schema.json`, `admin-map.schema.json`, `depends-on.schema.json` |
| [`specimen.md`](specimen.md): specimen page `/_kit/specimen`, composed reference pages, comparison rule, structure checks, reference images, accessibility baseline (`pk-conform`, `pk-audit`) | `specimen.yaml` (`papaia.specimen/1`), `specimen-expected.<theme>.json` (generated), `examples/pages/<page>.<lang>.html` (generated) |
| [`design-review.md`](design-review.md): design checks `pk-conform --design` and the review list for module pull requests | composed pages in `examples/pages/` |
| [`base.md`](base.md): base layer `pk.base` for plain content elements and form controls in `#pk-main`, derived state colours, fixture page | `base.yaml` (`papaia.base/1`), `base-expected.<theme>.json` (generated) |
| Kit versions of a suite: compatibility matrix with the `visual` flag of every release, `renders_ui` per module, `pk-check bom` (README, "Kit versions in one suite") | `versions.yaml` (`papaia.kit-versions/1`), `kit-bom.schema.json` (`papaia.kit-bom/1`), `suite-bom-kit.schema.json` (field `repos[].kit` of `papaia.suite-bom/1`), `examples/kit-bom.yaml`, `examples/suite-bom-kit.yaml` |
| [`assertion.md`](assertion.md): module context assertion `X-Papaia-Module-Context`, server modes `off`/`log`/`enforce` | `error.v1` (rejections) |
| [`halt.md`](halt.md): platform halt guard `papaia_kit.halt.HaltGuard`, state file, fail-closed reads, refusal and its audit row | `audit.v1`, `error.v1` (refusal) |

`examples/` holds documents that validate against the schemas; the tests in
`tests/` use them as the base of every positive and negative vector. The
example manifests (`*.papaia-app.yaml`: Paperless, Flow, Studio, probe) illustrate the
`exposes:` contract and are not the modules' own manifests.
`vectors/` holds the shared test vectors every implementation of a kit
function runs unchanged (Python, TypeScript, conformance suites).

| File | Content |
|---|---|
| `errors.yaml` | Module code → error class (`schemas/error.v1.schema.json`), aliases, generic code |
| `messages/codes.{de,en}.yaml` | Display texts per code after pattern 8 and class titles |
| `messages/consequences.{de,en}.yaml` | Closed list of consequence sentences |
| `messages/consequences.register.json` | Kit minor version in which each consequence id was added |
| `messages/shell.{de,en}.yaml` | Fixed texts of the shell |
| `admin-map.yaml` | Administration entries of every module, review group, old paths (`308`), task -> place -> role |
| `depends-on.yaml` | Places whose function needs another module, with the "not set up" sentence |
| `messages/states.{de,en}.yaml` | Fixed texts of the five states (interface spec 2.4) |
| `messages/patterns.{de,en}.yaml` | Fixed texts of the nine patterns (interface spec 3.5) |
| `patterns/` | The nine patterns: description, states, mandatory markup, examples, timing |
| `vectors/formats.json` | Pattern 9 formats, weekday per kind of time value, shared vectors |
| `vectors/halt.json` | Platform halt guard: halted, released, stale, corrupt, unreadable, missing but expected and missing folder, in order against one folder |
| `forbidden-patterns.yaml` | Patterns that never appear in text shown to people |
| `instruction-patterns.yaml` | Text shaped like an instruction to a model, rejected in manifests |
