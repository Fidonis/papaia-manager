# Inventory of work objects

Format `papaia.inventory/1`, schema
[`schemas/inventory.v1.schema.json`](../schemas/inventory.v1.schema.json),
example [`examples/inventory.v1.json`](examples/inventory.v1.json).

Every module that lets people build work objects serves its part at
`GET /internal/inventory` (service mTLS). The manager asks every module on each
request and merges the answers; it keeps no copy. The inventory lists objects,
never their content: no rows, no conditions, no reminder text.

## Document

| Field | Content |
|---|---|
| `format` | `papaia.inventory/1` |
| `generated_on` | day of the output (UTC, no time of day) |
| `sources[]` | `{module, status}` for every module asked; `status` is `erreichbar` or `nicht erreichbar`. A module that does not answer is listed, never silently left out. |
| `items[]` | one entry per object, sorted by `id` (byte order) |
| `checksum` | `sha256:<hex>` over the canonical JSON of the document without `checksum` |

Canonical JSON: keys sorted, separators `,` and `:` without spaces, UTF-8
without escaping non-ASCII characters (`json.dumps(body, sort_keys=True,
separators=(",", ":"), ensure_ascii=False)`).

## Item

| Field | Content | Required |
|---|---|---|
| `id` | `<module>:<kind>:<object id>` | yes |
| `kind` | `app` (studio), `workflow` (flow), `metric` (data), `dashboard` (studio, data), `event_rule`, `event_reminder` (assist) | yes |
| `module` | `studio`, `flow`, `data`, `assist` | yes |
| `purpose` | purpose of an assistant entry from the declared delegation purposes, e.g. `assist.event`; fixed vocabulary, never free text | assistant entries only |
| `title` | title of the object | all but assistant entries; forbidden there |
| `version` | current version | all but assistant entries; forbidden there |
| `state` | `entwurf`, `privat`, `geprüft`, `freigegeben`, `aktiv`, `angehalten`, `stillgelegt` | yes |
| `owner_sub`, `deputy_sub` | owner and deputy (subject ids) | owner yes |
| `approver_sub`, `approved_at` | last approval, both or neither | no |
| `shared_with` | `{groups[], persons}`: group names and number of individually added persons | all but assistant entries; forbidden there |
| `catalog_entries[]` | `{catalog_id, operations[], effect}` of the bindings used | yes (may be empty) |
| `max_data_class` | highest class of all entries and tables, see [data classes](data-classes.md) | yes |
| `service_accounts[]` | `{name, audience}` | yes (may be empty) |
| `created_at`, `last_used_at`, `confirmed_at` | days without time; for assistant entries `last_used_at` is the day of the last trigger | `created_at` yes |
| `flags[]` | `owner_inactive`, `deputy_missing`, `unused_180d`, `confirmation_due`, `class_above_role` | yes (may be empty) |

Assistant entries (`event_rule`, `event_reminder`) are personal: they carry
owner, purpose, binding, effect, class and the day of the last trigger, but no
title, no version and no sharing. Unknown fields are rejected everywhere.
