"""``papaia-kit bom check FILE`` and ``pk-check bom FILE``: kit versions of a suite.

Reads a bill of materials ``papaia.kit-bom/1`` or the kit versions of a suite
bill of materials ``papaia.suite-bom/1`` and refuses it when its kit versions
must not be combined (:mod:`papaia_kit.bom`). Exit 0 allowed, 1 refused or
malformed, 2 file missing, unreadable or too large.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

from papaia_kit import __version__
from papaia_kit.bom import MAX_BOM_BYTES, BomError, check_bom, load_bom, load_matrix

__all__ = ["add_arguments", "add_parser", "run"]

EXIT_OK, EXIT_FAIL, EXIT_USAGE = 0, 1, 2


def add_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "file", type=Path, help="bill of materials (papaia.kit-bom/1 or papaia.suite-bom/1)"
    )


def add_parser(groups: Any) -> None:
    """Arguments of ``bom``; ``groups`` is the top-level subparsers action."""
    bom = groups.add_parser("bom", help="kit versions of a suite bill of materials")
    sub = bom.add_subparsers(dest="command", required=True)
    add_arguments(sub.add_parser("check", help="refuse versions that must not be combined"))


def run(args: argparse.Namespace) -> int:
    try:
        data = _read(args.file)
    except OSError as exc:
        print(f"error: {exc.strerror or type(exc).__name__}: {args.file}", file=sys.stderr)
        return EXIT_USAGE
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    try:
        entries = load_bom(data, source=str(args.file))
        problems = check_bom(entries, load_matrix())
    except BomError as exc:
        problems = list(exc.problems)
    if problems:
        for problem in problems:
            print(f"  {problem}", file=sys.stderr)
        print(f"bill of materials refused (kit {__version__})", file=sys.stderr)
        return EXIT_FAIL
    versions = sorted({entry.kit for entry in entries}, key=lambda v: tuple(map(int, v.split("."))))
    ui = sum(1 for entry in entries if entry.renders_ui)
    print(
        f"bom: {len(entries)} modules ({ui} render kit UI), kit {', '.join(versions)} "
        "may be combined"
    )
    return EXIT_OK


def _read(path: Path) -> bytes:
    with path.open("rb") as handle:
        data = handle.read(MAX_BOM_BYTES + 1)
    if len(data) > MAX_BOM_BYTES:
        raise ValueError(f"{path}: larger than {MAX_BOM_BYTES} bytes")
    return data
