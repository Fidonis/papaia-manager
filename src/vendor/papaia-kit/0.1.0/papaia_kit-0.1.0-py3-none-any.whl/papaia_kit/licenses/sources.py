"""Readers that turn lock files and installed metadata into license records."""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tomllib
from importlib import metadata
from pathlib import Path
from typing import Any

from papaia_kit.licenses.expression import (
    License,
    LicenseExpressionError,
    Node,
    Record,
    license_alias,
    parse_expression,
)
from papaia_kit.licenses.policy import SCOPES, PolicyError, VerifiedEntry, normalise_name

# Longer "License" fields are pasted license texts, not names.
_MAX_LICENSE_NAME = 80
_RECORD_KEYS = ("name", "version", "license", "scope", "ecosystem")
_MAX_FIELD = 300


def _field(value: Any, where: str, *, required: bool = True) -> str:
    if value is None and not required:
        return ""
    if not isinstance(value, str) or len(value) > _MAX_FIELD or (required and not value):
        raise PolicyError(f"{where}: expected a string of at most {_MAX_FIELD} characters")
    return value


def json_records(path: Path) -> list[Record]:
    """Read a JSON list of records (fixtures and records exported by other tools)."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PolicyError(f"{path}: {exc}") from exc
    if not isinstance(raw, list):
        raise PolicyError(f"{path}: expected a JSON list")
    records = []
    for i, item in enumerate(raw):
        where = f"{path}[{i}]"
        if not isinstance(item, dict):
            raise PolicyError(f"{where}: expected an object")
        unknown = sorted(set(item) - set(_RECORD_KEYS))
        if unknown:
            raise PolicyError(f"{where}: unknown field(s) {', '.join(unknown)}")
        scope = _field(item.get("scope", "runtime"), f"{where}.scope")
        if scope not in SCOPES:
            raise PolicyError(f"{where}: unknown scope {scope!r}")
        records.append(
            Record(
                name=_field(item.get("name"), f"{where}.name"),
                version=_field(item.get("version"), f"{where}.version", required=False),
                license=_field(item.get("license"), f"{where}.license", required=False),
                scope=scope,
                ecosystem=_field(item.get("ecosystem", "python"), f"{where}.ecosystem"),
                source="records",
            )
        )
    return records


def _npm_license(entry: dict[str, Any], lock_dir: Path, key: str) -> tuple[str, str]:
    value = entry.get("license")
    if value is None and isinstance(entry.get("licenses"), list):
        value = [v.get("type") if isinstance(v, dict) else v for v in entry["licenses"]]
    if isinstance(value, dict):
        value = value.get("type")
    if isinstance(value, list):
        value = " OR ".join(v for v in value if isinstance(v, str))
    if isinstance(value, str) and value:
        return value, "package-lock"
    manifest = lock_dir / key / "package.json"
    if manifest.is_file():
        installed = json.loads(manifest.read_text(encoding="utf-8")).get("license")
        if isinstance(installed, str) and installed:
            return installed, "package.json"
    return "", "package-lock"


def npm_records(lock: Path) -> list[Record]:
    """Read a package-lock.json (lockfileVersion 3); dev packages are build scope."""
    try:
        data = json.loads(lock.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PolicyError(f"{lock}: {exc}") from exc
    if not isinstance(data, dict) or data.get("lockfileVersion") != 3:  # noqa: PLR2004
        raise PolicyError(f"{lock}: only lockfileVersion 3 is supported")
    packages = data.get("packages")
    if not isinstance(packages, dict):
        raise PolicyError(f"{lock}: missing packages table")
    records = []
    for key, entry in sorted(packages.items()):
        # "" is the project itself; paths outside node_modules are workspace
        # members and links point at them: both are own code.
        if not key or "node_modules/" not in key or not isinstance(entry, dict):
            continue
        if entry.get("link"):
            continue
        name = key.rsplit("node_modules/", 1)[1]
        license_text, source = _npm_license(entry, lock.parent, key)
        records.append(
            Record(
                name=name,
                version=str(entry.get("version", "")),
                license=license_text,
                scope="build" if entry.get("dev") else "runtime",
                ecosystem="javascript",
                source=source,
            )
        )
    return records


# Group and extra names that hold test tools (scope "test"); every other
# dependency group is a build or development tool (scope "build"). Extras are
# installed by users of the package and count as runtime, except extras with
# one of the development names below, which projects use in place of groups.
_TEST_GROUPS = frozenset({"test", "tests", "testing"})
_DEV_EXTRAS = frozenset({"dev", "develop", "development", "lint", "docs", "typing", *_TEST_GROUPS})
# Most restrictive scope first: runtime denies most, build denies restricted
# classes that test still allows with an exception.
_SCOPE_ORDER = ("runtime", "build", "test")
# Lock sources that are code of the project or its workspace, not third party.
_OWN_SOURCES = frozenset({"editable", "virtual"})
# Names of the GPL family in license texts and notices, in any letter case:
# the heading of the full text as well as notices such as "under the terms of
# the GNU Lesser General Public License".
_COPYLEFT_TEXT = re.compile(
    r"\bGNU\s+(?:(?:AFFERO|LESSER|LIBRARY)\s+)?(?:GENERAL\s+PUBLIC\s+LICEN[CS]E|[AL]?GPL)\b",
    re.IGNORECASE,
)
# Fixed passages of standard license texts that name the GPL family without
# placing the package under it. They are blanked before the search, so any
# other mention in the same file still counts. Whitespace may be reflowed.
_STANDARD_PASSAGES = tuple(
    re.compile(r"\s+".join(map(re.escape, passage.split())), re.IGNORECASE)
    for passage in (
        # PSF License Agreement for Python 1.6.1, governing-law clause
        "previously distributed under the GNU General Public License (GPL),",
        # MPL-2.0 section 1.12, definition of "Secondary License"
        "means either the GNU General Public License, Version 2.0, the GNU Lesser General "
        "Public License, Version 2.1, the GNU Affero General Public License, Version 3.0, "
        "or any later versions of those licenses.",
    )
)
_COPYLEFT_ID = re.compile(r"GPL", re.IGNORECASE)
COPYLEFT_FILE_REF = "LicenseRef-GPL-family-text-in-license-files"
# A License field that is neither a known name nor an SPDX expression is kept
# as an unknown part next to the classifiers, so that it needs a [[verified]]
# entry. Only these pure pointers to the license file (or the placeholder of
# old build tools) carry no terms of their own and give way to the classifiers.
_POINTER_ONLY = re.compile(
    r"(?:unknown|(?:see\s+(?:the\s+)?)?(?:file\s+)?(?:LICEN[CS]E|COPYING)"
    r"(?:\.(?:txt|md|rst))?(?:\s+file)?)\.?",
    re.IGNORECASE,
)
UNPARSED_FIELD_REF = "LicenseRef-unparsed-license-field"
_MAX_LICENSE_FILE = 1_000_000


class EnvironmentMismatch(PolicyError):  # noqa: N818 - reads as the condition it reports
    """The running interpreter is not the environment of the checked project."""


def _export_names(project: Path, *selection: str) -> set[str]:
    """Package names of one locked selection (``uv export``, all platforms)."""
    out = subprocess.run(  # noqa: S603 - fixed argument list, no shell
        [  # noqa: S607 - uv is the project tool and resolved from PATH on purpose
            "uv",
            "export",
            "--frozen",
            *selection,
            "--no-hashes",
            "--no-emit-project",
            "--no-emit-workspace",
            "--no-header",
            "--no-annotate",
            "--format",
            "requirements-txt",
        ],
        cwd=project,
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    names = set()
    for raw in out.splitlines():
        line = raw.strip()
        if line and not line.startswith(("#", "-")):
            names.add(normalise_name(re.split(r"[=<>;\[ @]", line, maxsplit=1)[0]))
    return names


def _group_scope(name: str) -> str:
    return "test" if normalise_name(name) in _TEST_GROUPS else "build"


def locked_scopes(project: Path, pyproject: dict[str, Any]) -> dict[str, str]:
    """Scope of every package in the project's locked closure.

    ``runtime``: the closure of the dependencies and of the extras users
    install; ``test``: groups named test, tests or testing; ``build``: every
    other dependency group and development extra. A package reached from
    several selections takes the most restrictive scope.
    """
    project_table = pyproject.get("project", {})
    selections: list[tuple[str, tuple[str, ...]]] = [("runtime", ("--no-default-groups",))]
    for extra in project_table.get("optional-dependencies", {}):
        scope = _group_scope(extra) if normalise_name(extra) in _DEV_EXTRAS else "runtime"
        selections.append((scope, ("--no-default-groups", "--extra", extra)))
    for group in pyproject.get("dependency-groups", {}):
        selections.append((_group_scope(group), ("--only-group", group)))
    scopes: dict[str, str] = {}
    for scope, selection in selections:
        for name in _export_names(project, *selection):
            current = scopes.get(name)
            if current is None or _SCOPE_ORDER.index(scope) < _SCOPE_ORDER.index(current):
                scopes[name] = scope
    return scopes


def _license_files(dist: metadata.Distribution) -> dict[str, str]:
    """Texts of the files in the ``licenses/`` folder of the dist-info (PEP 639)."""
    texts: dict[str, str] = {}
    for rel in dist.metadata.get_all("License-File") or []:
        text = dist.read_text(f"licenses/{rel}")
        if text is None:
            # Older installers put license files next to METADATA.
            text = dist.read_text(rel)
        if text is not None:
            texts[rel] = text[:_MAX_LICENSE_FILE]
    return texts


def _as_expression(text: str) -> str | None:
    """The text if it is a known license name or a well-formed SPDX expression."""
    if license_alias(text):
        return license_alias(text)
    try:
        parse_expression(text)
    except LicenseExpressionError:
        return None
    return text


def _every_choice_is_gpl_family(text: str) -> bool:
    """True if each way of choosing among the OR branches keeps a GPL-family license."""

    def covered(node: Node) -> bool:
        if isinstance(node, License):
            return bool(_COPYLEFT_ID.search(node.spdx))
        if node.operator == "OR":
            return all(covered(part) for part in node.parts)
        return any(covered(part) for part in node.parts)

    try:
        return covered(parse_expression(text))
    except LicenseExpressionError:
        return False


def _names_copyleft(body: str) -> bool:
    for passage in _STANDARD_PASSAGES:
        body = passage.sub(" ", body)
    return _COPYLEFT_TEXT.search(body) is not None


def _with_part(text: str, ref: str) -> str:
    part = text if " " not in text else f"({text})"
    return f"{part} AND {ref}"


def metadata_license(dist: metadata.Distribution) -> tuple[str, str]:
    """License expression of an installed distribution and where it was read.

    Order as specified: ``License-Expression``, then ``License``, then the
    trove classifiers. A ``License`` field that is neither a known name nor an
    SPDX expression (prose such as "GNU GPL v3" or "Proprietary") is never
    dropped: next to classifiers it adds the unknown part
    ``LicenseRef-unparsed-license-field``, without classifiers it is kept as
    is; both fail until a [[verified]] entry states the license. Only a pure
    pointer such as "see LICENSE" or the placeholder "UNKNOWN" gives way to
    the classifiers. A pasted license text (several lines) is not a name; it
    is searched for GPL-family terms like the license files.

    Several license classifiers are combined with AND: they usually describe
    bundled parts under different licenses, not a choice. The files in the
    ``licenses/`` folder are read as well; GPL-family terms there add an
    unknown part unless every choice of the expression already includes a
    GPL-family license, so that the package needs a [[verified]] entry.
    """
    meta = dist.metadata
    files = _license_files(dist)
    text, origin = "", "none"
    expression = str(meta.get("License-Expression") or "").strip()
    raw = str(meta.get("License") or "").strip()
    pasted = "\n" in raw
    is_name = bool(raw) and not pasted and len(raw) <= _MAX_LICENSE_NAME
    pointer = is_name and _POINTER_ONLY.fullmatch(raw) is not None
    classifiers = [
        c.split("::")[-1].strip()
        for c in meta.get_all("Classifier") or []
        if c.startswith("License ::") and c.split("::")[-1].strip() != "OSI Approved"
    ]
    named = _as_expression(raw) if is_name and not pointer else None
    if expression:
        text, origin = expression, "License-Expression"
    elif named:
        text, origin = named, "License"
    elif classifiers:
        # A classifier without an SPDX mapping keeps its text and fails as unknown.
        names = [license_alias(c) or c for c in classifiers]
        text = names[0] if len(names) == 1 else " AND ".join(f"({n})" for n in names)
        text, origin = (_simplify(text), "Classifier")
        if raw and not pasted and not pointer:
            text = _with_part(text, UNPARSED_FIELD_REF)
    elif is_name:
        text, origin = raw, "License"
    texts = {**files, **({"License field": raw} if pasted else {})}
    copyleft = any(_names_copyleft(body) for body in texts.values())
    if copyleft and text and not _every_choice_is_gpl_family(text):
        text = _with_part(text, COPYLEFT_FILE_REF)
    source = origin if not files else f"{origin}; files: {', '.join(sorted(files))}"
    return text, source


def _simplify(text: str) -> str:
    """Drop parentheses around single identifiers: ``(MIT) AND (ISC)`` -> ``MIT AND ISC``."""
    return re.sub(r"\(([A-Za-z0-9.+:-]+)\)", r"\1", text)


def installed_distributions() -> list[metadata.Distribution]:
    """Distributions of the running interpreter."""
    return list(metadata.distributions())


def _expected_environment(project: Path) -> Path:
    configured = os.environ.get("UV_PROJECT_ENVIRONMENT")
    if configured:
        path = Path(configured)
        return path if path.is_absolute() else project / path
    return project / ".venv"


def _locked_packages(project: Path) -> dict[str, tuple[str, set[str]]]:
    """Third-party packages of uv.lock: normalised name -> (name, versions)."""
    try:
        lock = tomllib.loads((project / "uv.lock").read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise PolicyError(f"{project / 'uv.lock'}: {exc}") from exc
    packages: dict[str, tuple[str, set[str]]] = {}
    for entry in lock.get("package", []):
        if not isinstance(entry, dict) or not isinstance(entry.get("name"), str):
            raise PolicyError(f"{project / 'uv.lock'}: malformed [[package]] entry")
        source = entry.get("source", {})
        if isinstance(source, dict) and _OWN_SOURCES & set(source):
            continue
        key = normalise_name(entry["name"])
        packages.setdefault(key, (entry["name"], set()))[1].add(str(entry.get("version", "")))
    return packages


def python_records(project: Path, verified: tuple[VerifiedEntry, ...] = ()) -> list[Record]:
    """Records for every package of the project's uv.lock, read from its environment.

    Run it as ``uv run --locked papaia-kit licenses check --python-project .``
    so that the interpreter is the project's synced environment. The check
    fails closed: an interpreter outside the project environment raises
    EnvironmentMismatch, and a locked package that is missing or installed at
    another version becomes a failing record. A package that cannot be
    installed on this platform (environment marker) passes only with a
    [[verified]] entry for its exact version.
    """
    pyproject_path = project / "pyproject.toml"
    if not (project / "uv.lock").is_file() or not pyproject_path.is_file():
        raise PolicyError(f"{project}: expected pyproject.toml and uv.lock")
    expected = _expected_environment(project).resolve()
    running = Path(sys.prefix).resolve()
    if running != expected:
        raise EnvironmentMismatch(
            f"the running interpreter ({running}) is not the environment of {project} "
            f"({expected}); run the check with `uv run --locked` inside the project"
        )
    pyproject = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
    scopes = locked_scopes(project, pyproject)
    installed = {
        normalise_name(dist.metadata["Name"]): dist
        for dist in installed_distributions()
        if dist.metadata["Name"]
    }
    checked = {(v.package, v.version): v for v in verified}
    records = []
    for key, (name, versions) in sorted(_locked_packages(project).items()):
        scope = scopes.get(key, "runtime")  # not reached by any selection: fail closed
        dist = installed.get(key)
        locked = " or ".join(sorted(versions))
        if dist is not None and dist.version in versions:
            text, source = metadata_license(dist)
            records.append(Record(name, dist.version, text, scope, source=source))
            continue
        entry = next((checked[(key, v)] for v in sorted(versions) if (key, v) in checked), None)
        if dist is None and entry is not None:
            records.append(
                Record(
                    name, entry.version, entry.license, scope, source=f"verified: {entry.source}"
                )
            )
            continue
        problem = (
            "locked but not installed in the project environment; run `uv sync --locked`, "
            "or add a [[verified]] entry if an environment marker excludes it here"
            if dist is None
            else f"locked at {locked} but {dist.version} is installed; run `uv sync --locked`"
        )
        records.append(Record(name, locked, "", scope, source="uv.lock", problem=problem))
    return records
