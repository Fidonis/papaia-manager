"""Signing keys of the realm (JWKS) for step 1 of the chain.

Only RS256 and ES256 are accepted (security 2.1 step 1, RFC 8725 3.1-3.2):
``none`` and every HMAC algorithm are refused before a key is looked up, and a
key is only used with the one algorithm that fits its type. Fetching the JWKS
is left to the caller (``JwksCache`` takes a function), so the kit opens no
network connection of its own.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable, Mapping
from typing import Any, Protocol

from cryptography.hazmat.primitives.asymmetric import ec, rsa
from jwt import PyJWK
from jwt.exceptions import PyJWKError

ALGORITHMS = ("RS256", "ES256")
MIN_RSA_BITS = 2048
MAX_KID_LENGTH = 128
MAX_KEYS = 64
# kty and curve each algorithm requires
_KEY_SHAPE = {"RS256": ("RSA", None), "ES256": ("EC", "P-256")}


class KeyProvider(Protocol):
    """Looks up the verification key for a ``kid``."""

    def key_for(self, kid: str) -> PyJWK | None: ...


def _algorithm(jwk: Mapping[str, Any]) -> str | None:
    kty, alg = jwk.get("kty"), jwk.get("alg")
    for name, (shape_kty, curve) in _KEY_SHAPE.items():
        if kty == shape_kty and (curve is None or jwk.get("crv") == curve):
            return name if alg in (None, name) else None
    return None


def _usable(key: PyJWK) -> bool:
    material = key.key
    if isinstance(material, rsa.RSAPublicKey):
        return material.key_size >= MIN_RSA_BITS
    return isinstance(material, ec.EllipticCurvePublicKey) and isinstance(
        material.curve, ec.SECP256R1
    )


class KeySet:
    """Verification keys of one JWKS document, by ``kid``.

    Keys that cannot sign tokens for this chain (encryption keys, symmetric
    keys, other algorithms or curves, RSA below 2048 bits) are skipped. A
    structurally broken document raises ``ValueError``.
    """

    def __init__(self, keys: Mapping[str, PyJWK]) -> None:
        self._keys = dict(keys)

    @classmethod
    def from_jwks(cls, jwks: object) -> KeySet:
        if not isinstance(jwks, Mapping) or not isinstance(jwks.get("keys"), list):
            raise ValueError("JWKS must be an object with a 'keys' list")
        entries = jwks["keys"]
        if len(entries) > MAX_KEYS:
            raise ValueError("JWKS holds too many keys")
        keys: dict[str, PyJWK] = {}
        seen: set[str] = set()
        for entry in entries:
            if not isinstance(entry, Mapping):
                raise ValueError("JWKS key must be an object")
            kid = entry.get("kid")
            if not isinstance(kid, str) or not kid or len(kid) > MAX_KID_LENGTH:
                raise ValueError("JWKS key needs a 'kid' of 1 to 128 characters")
            if kid in seen:
                raise ValueError("JWKS holds a duplicate 'kid'")
            seen.add(kid)
            if entry.get("use", "sig") != "sig":
                continue
            algorithm = _algorithm(entry)
            if algorithm is None:
                continue
            try:
                key = PyJWK(dict(entry), algorithm)
            except (PyJWKError, ValueError, TypeError):
                continue
            if _usable(key):
                keys[kid] = key
        return cls(keys)

    def key_for(self, kid: str) -> PyJWK | None:
        return self._keys.get(kid)

    def __len__(self) -> int:
        return len(self._keys)


class JwksCache:
    """``KeyProvider`` over a JWKS fetched by ``fetch``, with ``kid`` cache.

    An unknown ``kid`` (key rotation) triggers a new fetch, at most once per
    ``min_refresh_seconds`` so that tokens with made-up ``kid`` values cannot
    flood the identity provider. The set is also refreshed after
    ``max_age_seconds``. A failed fetch keeps the previous keys.

    ``fetch`` runs while the cache lock is held, so concurrent checks wait for
    it: it must use a short timeout (a few seconds). While fetches keep
    failing, keys removed from the JWKS stay in use; ``age_seconds()`` and
    ``stale()`` report that for doctor.
    """

    def __init__(
        self,
        fetch: Callable[[], object],
        *,
        min_refresh_seconds: float = 30.0,
        max_age_seconds: float = 300.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._fetch = fetch
        self._min_refresh = min_refresh_seconds
        self._max_age = max_age_seconds
        self._clock = clock
        self._lock = threading.Lock()
        self._keys = KeySet({})
        self._loaded_at: float | None = None
        self._attempted_at: float | None = None

    def _refresh(self, now: float) -> None:
        self._attempted_at = now
        try:
            keys = KeySet.from_jwks(self._fetch())
        except Exception:  # noqa: BLE001 - any fetch or parse failure keeps the old keys
            return
        self._keys = keys
        self._loaded_at = now

    def age_seconds(self) -> float | None:
        """Seconds since the key set was last loaded, or None before the first load."""
        with self._lock:
            return None if self._loaded_at is None else self._clock() - self._loaded_at

    def stale(self) -> bool:
        """True when no key set is loaded or it is older than ``max_age_seconds``."""
        age = self.age_seconds()
        return age is None or age > self._max_age

    def key_for(self, kid: str) -> PyJWK | None:
        with self._lock:
            now = self._clock()
            may_fetch = self._attempted_at is None or now - self._attempted_at >= self._min_refresh
            stale = self._loaded_at is None or now - self._loaded_at >= self._max_age
            if may_fetch and (stale or self._keys.key_for(kid) is None):
                self._refresh(now)
            return self._keys.key_for(kid)
