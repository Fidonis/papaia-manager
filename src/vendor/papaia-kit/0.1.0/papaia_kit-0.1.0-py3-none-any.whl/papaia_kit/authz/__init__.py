"""Authorization check chain shared by every module and server (security 2.1).

``CheckChain.check(token, request)`` verifies a bearer token for one request:
signature, issuer and access token type, a single audience (several only for ``trust: platform``
and the chat client), ``azp`` in the allow list of the own audience (an empty
list refuses everything), identity kind, revocation list, module role and the
effect released for the ``azp``. The ``scope`` claim is never a rights source.
A refusal raises ``AuthzDenied`` with an ``error.v1`` envelope and hands one
``papaia.audit/1`` row with result ``denied`` to the audit sink. The origin of
a token chain (``origin_azp``) comes from the configured upstream origins; the
``X-Papaia-Origin-Azp`` header is information only.
"""

from papaia_kit.authz._chain import (
    ACCESS_TOKEN_TYPE,
    AUDIT_FORMAT,
    CORRELATION_HEADER,
    LEEWAY_SECONDS,
    MAX_TOKEN_LENGTH,
    MISMATCH_EVENT,
    ORIGIN_HEADER,
    AuditSink,
    AuthzDenied,
    CheckChain,
    Principal,
    Reason,
    RevocationSource,
    bearer_token,
)
from papaia_kit.authz._config import (
    CHAIN_HOLDERS,
    MULTI_AUDIENCE_CLIENTS,
    AzpAllowList,
    Effect,
    IdentityKind,
    Request,
    ServerConfig,
    Trust,
)
from papaia_kit.authz._keys import ALGORITHMS, JwksCache, KeyProvider, KeySet
from papaia_kit.authz._revocation import RevocationList, RevocationState, RevocationStatus

__all__ = [
    "ACCESS_TOKEN_TYPE",
    "ALGORITHMS",
    "AUDIT_FORMAT",
    "CHAIN_HOLDERS",
    "CORRELATION_HEADER",
    "LEEWAY_SECONDS",
    "MAX_TOKEN_LENGTH",
    "MISMATCH_EVENT",
    "MULTI_AUDIENCE_CLIENTS",
    "ORIGIN_HEADER",
    "AuditSink",
    "AuthzDenied",
    "AzpAllowList",
    "CheckChain",
    "Effect",
    "IdentityKind",
    "JwksCache",
    "KeyProvider",
    "KeySet",
    "Principal",
    "Reason",
    "Request",
    "RevocationList",
    "RevocationSource",
    "RevocationState",
    "RevocationStatus",
    "ServerConfig",
    "Trust",
    "bearer_token",
]
