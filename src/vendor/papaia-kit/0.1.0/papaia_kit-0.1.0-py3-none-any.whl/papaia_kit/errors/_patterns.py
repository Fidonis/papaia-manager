"""Forbidden patterns in text shown to people (interface spec W5)."""

from __future__ import annotations

import functools
import re
import unicodedata
from dataclasses import dataclass
from typing import Any

import yaml

from papaia_kit._resources import contract_dir

KINDS = frozenset({"message", "text", "button"})

# Control, format (bidi controls, zero-width characters), private-use and
# surrogate characters, plus line and paragraph separators. None of them
# belongs in text shown to people; they can hide or reorder what is displayed.
_HIDDEN_CATEGORIES = frozenset({"Cc", "Cf", "Co", "Cs", "Zl", "Zp"})


class CatalogError(ValueError):
    """A contract data file of the kit is malformed."""


@dataclass(frozen=True)
class ForbiddenPattern:
    id: str
    description: str
    kinds: frozenset[str]
    regex: re.Pattern[str]


@dataclass(frozen=True)
class PatternHit:
    pattern: str
    match: str


def read_yaml(name: str) -> dict[str, Any]:
    """Load one contract file and check its version."""
    path = contract_dir() / name
    with path.open(encoding="utf-8") as handle:
        data = yaml.safe_load(handle)
    if not isinstance(data, dict) or data.get("version") != 1:
        raise CatalogError(f"{name}: expected a mapping with version 1")
    return data


def require_keys(where: str, data: object, required: set[str], optional: set[str]) -> None:
    if not isinstance(data, dict):
        raise CatalogError(f"{where}: expected a mapping")
    keys = set(data)
    if missing := required - keys:
        raise CatalogError(f"{where}: missing {sorted(missing)}")
    if unknown := keys - required - optional:
        raise CatalogError(f"{where}: unknown {sorted(unknown)}")


@functools.cache
def load_forbidden_patterns() -> tuple[ForbiddenPattern, ...]:
    """Patterns from ``contract/forbidden-patterns.yaml``, compiled."""
    data = read_yaml("forbidden-patterns.yaml")
    require_keys("forbidden-patterns.yaml", data, {"version", "patterns"}, set())
    entries = data["patterns"]
    if not isinstance(entries, list) or not entries:
        raise CatalogError("forbidden-patterns.yaml: patterns must be a non-empty list")
    out: list[ForbiddenPattern] = []
    for entry in entries:
        require_keys(
            "forbidden-patterns.yaml entry",
            entry,
            {"id", "description", "kinds", "regex"},
            {"ignore_case"},
        )
        kinds = entry["kinds"]
        if not isinstance(kinds, list) or not set(kinds) <= KINDS or not kinds:
            raise CatalogError(f"forbidden-patterns.yaml {entry['id']}: bad kinds")
        flags = re.IGNORECASE if entry.get("ignore_case", False) is True else 0
        try:
            regex = re.compile(str(entry["regex"]), flags)
        except re.error as exc:
            raise CatalogError(f"forbidden-patterns.yaml {entry['id']}: {exc}") from exc
        out.append(
            ForbiddenPattern(str(entry["id"]), str(entry["description"]), frozenset(kinds), regex)
        )
    return tuple(out)


def find_forbidden_patterns(text: str, kind: str = "message") -> list[PatternHit]:
    """Every forbidden pattern found in ``text`` shown as ``kind`` (message, text, button)."""
    if kind not in KINDS:
        raise ValueError(f"unknown kind {kind!r}")
    return [
        PatternHit(pattern.id, match.group(0))
        for pattern in load_forbidden_patterns()
        if kind in pattern.kinds
        for match in pattern.regex.finditer(text)
    ]


def has_hidden_characters(text: str) -> bool:
    """True if ``text`` holds a control, format, private-use or separator character."""
    return any(unicodedata.category(ch) in _HIDDEN_CATEGORIES for ch in text)
