"""Format, signer and verifier of the module context assertion (architecture V-11).

The checks run in one fixed order so that every implementation reports the
same code for the same input; ``testing/vectors/module-context.v1.json`` is the
shared truth. Only ES256 over P-256 is accepted, and the algorithm is fixed
here, never taken from the header, which closes the ``alg`` confusion attacks
(``none``, HMAC with the public key).
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import logging
import re
import threading
import time
import uuid
from collections import OrderedDict
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Final, Protocol

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from jwt.algorithms import ECAlgorithm

from papaia_kit._resources import vectors_dir
from papaia_kit.authz import MAX_TOKEN_LENGTH, KeyProvider
from papaia_kit.names import Kind as NameKind
from papaia_kit.names import is_valid

HEADER: Final = "X-Papaia-Module-Context"
ASSERTION_TYPE: Final = "papaia-module-context+jwt"
MAX_LIFETIME_SECONDS: Final = 60
LEEWAY_SECONDS: Final = 10
# Longer than lifetime plus leeway on both sides: a jti cannot come back while
# its assertion would still be accepted.
REPLAY_TTL_SECONDS: Final = 120.0
MAX_ASSERTION_LENGTH: Final = 4096
VECTORS_FILE: Final = "module-context.v1.json"

_HEADER_FIELDS: Final = frozenset({"alg", "kid", "typ"})
_CLAIMS: Final = frozenset({"iss", "sub", "aud", "ctx", "ath", "iat", "exp", "jti"})
_CONTEXT_FIELDS: Final = frozenset({"module", "kind", "id", "version"})
_SEGMENT: Final = re.compile(r"[A-Za-z0-9_-]*")
_ATH: Final = re.compile(r"[A-Za-z0-9_-]{43}")
_JTI: Final = re.compile(r"[A-Za-z0-9-]{16,64}")
_KID: Final = re.compile(r"[A-Za-z0-9._-]{1,128}")
_MODULE: Final = re.compile(r"[a-z][a-z0-9-]{0,31}")
# Identifier and version join into one papaia.audit/1 reference "<id>:<version>",
# so neither may contain the colon.
_CONTEXT_VALUE: Final = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,62}")
# Lone surrogates are excluded: they cannot be encoded and never name a person.
_SUBJECT: Final = re.compile(r"[^\x00-\x20\x7f\ud800-\udfff]{1,255}")
_MAX_NUMERIC_DATE: Final = 2**63 - 1
_ES256: Final = ECAlgorithm(ECAlgorithm.SHA256)
_SIGNATURE_BYTES: Final = 64

logger = logging.getLogger("papaia_kit.assertion")


class Kind(StrEnum):
    """What called the server: an app (Studio), a run or step (Flow), an analysis (Data)."""

    APP = "app"
    RUN = "run"
    STEP = "step"
    ANALYSIS = "analysis"


# Membership on str values only: a JSON array or object in ``ctx.kind`` is not
# hashable and must end as ``malformed``, never as an exception.
_KIND_VALUES: Final = frozenset(kind.value for kind in Kind)


class Code(StrEnum):
    """Refusal code of the verifier, in the order of the checks. Safe to log."""

    MISSING = "missing"
    MALFORMED = "malformed"
    ISSUER = "issuer"
    SIGNATURE = "signature"
    AUDIENCE = "audience"
    EXPIRED = "expired"
    LIFETIME = "lifetime"
    TOKEN_BINDING = "token_binding"  # noqa: S105 - a code name, not a secret
    SUBJECT = "subject"
    REPLAY = "replay"


class ContextInvalid(Exception):  # noqa: N818 - reads as "raise ContextInvalid"
    """The assertion is absent or failed a check; ``code`` never holds token material."""

    def __init__(self, code: Code) -> None:
        super().__init__(f"module context {code.value}")
        self.code = code


@dataclass(frozen=True, slots=True)
class ModuleContext:
    """Verified origin of one call: which module, and which app, run, step or analysis."""

    issuer: str
    module: str
    kind: Kind
    context_id: str
    version: str
    jti: str

    def audit_fields(self) -> dict[str, Any]:
        """``context`` part of the server's own ``papaia.audit/1`` row."""
        return {"context": {self.kind.value: f"{self.context_id}:{self.version}"}}

    def log_fields(self) -> str:
        """``key=value`` text for the server log; every value passed the format checks."""
        return (
            f"iss={self.issuer} module={self.module} "
            f"{self.kind.value}={self.context_id} version={self.version}"
        )


def access_token_hash(token: str) -> str:
    """``ath``: base64url without padding of SHA-256 over the ASCII access token (RFC 9449 4.2)."""
    digest = hashlib.sha256(token.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def vectors_path() -> Path:
    """The shared test vectors; consumers compare their copy byte for byte."""
    return vectors_dir() / VECTORS_FILE


def _require(ok: bool, name: str) -> None:
    if not ok:
        raise ValueError(f"{name} is malformed")


def _name_ok(value: object, kind: NameKind) -> bool:
    return isinstance(value, str) and is_valid(value, kind)


def _matches(pattern: re.Pattern[str], value: object) -> bool:
    return isinstance(value, str) and pattern.fullmatch(value) is not None


def _kind_ok(value: object) -> bool:
    return isinstance(value, str) and value in _KIND_VALUES


def _context_ok(value: object) -> bool:
    return _matches(_CONTEXT_VALUE, value)


def _token_ok(token: object) -> bool:
    return isinstance(token, str) and token.isascii() and 0 < len(token) <= MAX_TOKEN_LENGTH


class ModuleContextSigner:
    """Signs the assertion a module sends with each call to a server.

    ``key`` is the module's own P-256 key; its public half (``public_jwk()``) is
    published with the module's catalog entry. Every call gets a new ``jti``.
    """

    def __init__(
        self,
        *,
        issuer: str,
        key: ec.EllipticCurvePrivateKey,
        kid: str,
        module: str,
        lifetime_seconds: int = MAX_LIFETIME_SECONDS,
        clock: Callable[[], float] = time.time,
    ) -> None:
        material: object = key
        if not isinstance(material, ec.EllipticCurvePrivateKey) or not isinstance(
            material.curve, ec.SECP256R1
        ):
            raise ValueError("key must be a P-256 private key")
        _require(_name_ok(issuer, NameKind.CLIENT), "issuer")
        _require(_matches(_KID, kid), "kid")
        _require(_matches(_MODULE, module), "module")
        lifetime: object = lifetime_seconds
        if not _numeric_date(lifetime) or not 1 <= lifetime_seconds <= MAX_LIFETIME_SECONDS:
            raise ValueError("lifetime_seconds must be from 1 to 60")
        self._issuer = issuer
        self._key = key
        self._kid = kid
        self._module = module
        self._lifetime = lifetime_seconds
        self._clock = clock

    @classmethod
    def from_pem_file(cls, path: Path, **kwargs: Any) -> ModuleContextSigner:
        """Signer with the unencrypted PEM key at ``path`` (a mounted secret)."""
        key = serialization.load_pem_private_key(path.read_bytes(), password=None)
        if not isinstance(key, ec.EllipticCurvePrivateKey):
            raise ValueError("key must be a P-256 private key")
        return cls(key=key, **kwargs)

    def public_jwk(self) -> dict[str, str]:
        """Public half of the key as a JWK for the module's JWKS."""
        numbers = self._key.public_key().public_numbers()

        def coordinate(value: int) -> str:
            return base64.urlsafe_b64encode(value.to_bytes(32, "big")).rstrip(b"=").decode()

        return {
            "kty": "EC",
            "crv": "P-256",
            "kid": self._kid,
            "alg": "ES256",
            "use": "sig",
            "x": coordinate(numbers.x),
            "y": coordinate(numbers.y),
        }

    def sign(
        self,
        *,
        token: str,
        audience: str,
        subject: str,
        kind: Kind | str,
        context_id: str,
        version: str,
    ) -> str:
        """Assertion for one call with ``token`` (the exchanged token sent alongside)."""
        _require(_token_ok(token), "token")
        _require(_name_ok(audience, NameKind.AUDIENCE), "audience")
        _require(_matches(_SUBJECT, subject), "subject")
        _require(_kind_ok(kind), "kind")
        _require(_context_ok(context_id), "context_id")
        _require(_context_ok(version), "version")
        issued = int(self._clock())
        claims = {
            "iss": self._issuer,
            "sub": subject,
            "aud": audience,
            "ctx": {
                "module": self._module,
                "kind": Kind(kind).value,
                "id": context_id,
                "version": version,
            },
            "ath": access_token_hash(token),
            "iat": issued,
            "exp": issued + self._lifetime,
            "jti": str(uuid.uuid4()),
        }
        return jwt.encode(
            claims, self._key, algorithm="ES256", headers={"kid": self._kid, "typ": ASSERTION_TYPE}
        )


class ReplayCache(Protocol):
    """Single-use store for accepted ``jti`` values; pluggable for servers with several workers.

    ``claim`` must be one atomic insert-if-absent (``SET key NX EX 120`` in a
    shared key-value store): it returns ``True`` and records ``key`` only if
    ``key`` was not recorded within the time to live, else ``False``. A
    separate look-up followed by a write lets two concurrent calls both pass.
    """

    def claim(self, key: str, now: float) -> bool: ...


class LruReplayCache:
    """In-memory replay store (default), per process.

    With several worker processes a replay to another worker is not detected;
    such servers plug in a shared store. When ``max_entries`` ids are still
    within their time to live, further claims are refused (fail closed) and a
    warning is logged; an unexpired id is never dropped, since it could then
    be replayed.
    """

    def __init__(self, ttl_seconds: float = REPLAY_TTL_SECONDS, max_entries: int = 100_000) -> None:
        if ttl_seconds <= 0 or max_entries <= 0:
            raise ValueError("ttl_seconds and max_entries must be positive")
        self._ttl = ttl_seconds
        self._max = max_entries
        self._entries: OrderedDict[str, float] = OrderedDict()
        self._lock = threading.Lock()

    def _purge(self, now: float) -> None:
        while self._entries:
            jti, expires = next(iter(self._entries.items()))
            if expires > now:
                return
            del self._entries[jti]

    def claim(self, key: str, now: float) -> bool:
        with self._lock:
            self._purge(now)
            if key in self._entries:
                return False
            if len(self._entries) >= self._max:
                logger.warning(
                    "module context replay store full: max_entries=%d, claim refused", self._max
                )
                return False
            self._entries[key] = now + self._ttl
            return True

    def __len__(self) -> int:
        return len(self._entries)


def _no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, value in pairs:
        if name in result:
            raise ContextInvalid(Code.MALFORMED)
        result[name] = value
    return result


def _decode(segment: str) -> bytes:
    try:
        return base64.urlsafe_b64decode(segment + "=" * (-len(segment) % 4))
    except (binascii.Error, ValueError):
        raise ContextInvalid(Code.MALFORMED) from None


def _object(segment: str) -> dict[str, Any]:
    if not segment:
        raise ContextInvalid(Code.MALFORMED)
    try:
        value = json.loads(_decode(segment), object_pairs_hook=_no_duplicates)
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ContextInvalid(Code.MALFORMED) from None
    if not isinstance(value, dict):
        raise ContextInvalid(Code.MALFORMED)
    return value


def _numeric_date(value: object) -> bool:
    return (
        not isinstance(value, bool) and isinstance(value, int) and 0 <= value <= _MAX_NUMERIC_DATE
    )


def _claims_ok(claims: Mapping[str, Any]) -> bool:
    ctx = claims.get("ctx")
    return (
        set(claims) == _CLAIMS
        and _name_ok(claims["iss"], NameKind.CLIENT)
        and isinstance(claims["sub"], str)
        and _SUBJECT.fullmatch(claims["sub"]) is not None
        and _name_ok(claims["aud"], NameKind.AUDIENCE)
        and isinstance(claims["ath"], str)
        and _ATH.fullmatch(claims["ath"]) is not None
        and _numeric_date(claims["iat"])
        and _numeric_date(claims["exp"])
        and isinstance(claims["jti"], str)
        and _JTI.fullmatch(claims["jti"]) is not None
        and isinstance(ctx, dict)
        and set(ctx) == _CONTEXT_FIELDS
        and isinstance(ctx["module"], str)
        and _MODULE.fullmatch(ctx["module"]) is not None
        and _kind_ok(ctx["kind"])
        and _context_ok(ctx["id"])
        and _context_ok(ctx["version"])
    )


@dataclass(frozen=True, slots=True)
class _Parsed:
    header: dict[str, Any]
    claims: dict[str, Any]
    signing_input: bytes
    signature: bytes


def _parse(value: str) -> _Parsed:
    """Structure, closed header and claim sets, ``typ`` and claim types."""
    if len(value) > MAX_ASSERTION_LENGTH:
        raise ContextInvalid(Code.MALFORMED)
    parts = value.split(".")
    if len(parts) != 3 or not all(_SEGMENT.fullmatch(part) for part in parts):  # noqa: PLR2004
        raise ContextInvalid(Code.MALFORMED)
    header = _object(parts[0])
    if set(header) != _HEADER_FIELDS or header["typ"] != ASSERTION_TYPE:
        raise ContextInvalid(Code.MALFORMED)
    claims = _object(parts[1])
    if not _claims_ok(claims):
        raise ContextInvalid(Code.MALFORMED)
    signing_input = f"{parts[0]}.{parts[1]}".encode("ascii")
    return _Parsed(header, claims, signing_input, _decode(parts[2]))


class ModuleContextVerifier:
    """Verifies assertions for one server audience.

    ``modules`` maps each trusted module client (``iss``) to the key provider of
    its JWKS (``KeySet`` or ``JwksCache`` from ``papaia_kit.authz``); a module
    not listed is refused with ``issuer``. Checks in this order, the first
    failure ends: missing, malformed, issuer, signature, audience, expired,
    lifetime, token_binding, subject, replay. The ``jti`` is claimed in one
    atomic step after every other check passed, so a refused assertion never
    burns a genuine id and two concurrent calls cannot both be accepted.
    """

    def __init__(
        self,
        modules: Mapping[str, KeyProvider],
        *,
        audience: str,
        leeway_seconds: int = LEEWAY_SECONDS,
        replay: ReplayCache | None = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        for issuer in modules:
            _require(_name_ok(issuer, NameKind.CLIENT), "module issuer")
        _require(_name_ok(audience, NameKind.AUDIENCE), "audience")
        if not 0 <= leeway_seconds <= LEEWAY_SECONDS:
            raise ValueError("leeway_seconds must be from 0 to 10")
        self._modules = dict(modules)
        self._audience = audience
        self._leeway = leeway_seconds
        self._replay: ReplayCache = replay if replay is not None else LruReplayCache()
        self._clock = clock

    @property
    def audience(self) -> str:
        return self._audience

    def verify(self, value: str | None, *, token: str, subject: str) -> ModuleContext:
        """Verify the header ``value`` sent with ``token`` for the person ``subject``."""
        if not isinstance(value, str) or not value.strip():
            raise ContextInvalid(Code.MISSING)
        now = self._clock()
        parsed = _parse(value.strip())
        claims = parsed.claims
        keys = self._modules.get(claims["iss"])
        if keys is None:
            raise ContextInvalid(Code.ISSUER)
        self._verify_signature(parsed, keys)
        if claims["aud"] != self._audience:
            raise ContextInvalid(Code.AUDIENCE)
        issued, expires = claims["iat"], claims["exp"]
        if now > expires + self._leeway:
            raise ContextInvalid(Code.EXPIRED)
        if (
            expires <= issued
            or expires - issued > MAX_LIFETIME_SECONDS
            or issued > now + self._leeway
        ):
            raise ContextInvalid(Code.LIFETIME)
        if not _token_ok(token) or not hmac.compare_digest(
            claims["ath"].encode("ascii"), access_token_hash(token).encode("ascii")
        ):
            raise ContextInvalid(Code.TOKEN_BINDING)
        given: object = subject
        if not _matches(_SUBJECT, given) or not hmac.compare_digest(
            claims["sub"].encode("utf-8"), str(given).encode("utf-8")
        ):
            raise ContextInvalid(Code.SUBJECT)
        if not self._replay.claim(f"{claims['iss']} {claims['jti']}", now):
            raise ContextInvalid(Code.REPLAY)
        ctx = claims["ctx"]
        return ModuleContext(
            issuer=claims["iss"],
            module=ctx["module"],
            kind=Kind(ctx["kind"]),
            context_id=ctx["id"],
            version=ctx["version"],
            jti=claims["jti"],
        )

    @staticmethod
    def _verify_signature(parsed: _Parsed, keys: KeyProvider) -> None:
        kid = parsed.header["kid"]
        if parsed.header["alg"] != "ES256" or not isinstance(kid, str) or not _KID.fullmatch(kid):
            raise ContextInvalid(Code.SIGNATURE)
        key = keys.key_for(kid)
        if key is None or key.algorithm_name != "ES256":
            raise ContextInvalid(Code.SIGNATURE)
        if len(parsed.signature) != _SIGNATURE_BYTES:
            raise ContextInvalid(Code.SIGNATURE)
        if not _ES256.verify(parsed.signing_input, key.key, parsed.signature):
            raise ContextInvalid(Code.SIGNATURE)
