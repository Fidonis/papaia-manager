"""Correlation id: one value that follows a request through every module and server.

Rules (``contract/audit.md``, section "Correlation id"):

- Header ``X-Papaia-Correlation-Id``; 1 to 64 characters out of ``A-Z``,
  ``a-z``, ``0-9`` and ``-``.
- A value shaped like a token or a prefixed key (the ``token_free`` rule of
  ``schemas/audit.v1.schema.json``) is invalid even though its characters are
  allowed: the id is written into every audit event of the request.
- A receiver keeps a valid value. A missing or invalid value is replaced by a
  new UUIDv7 (RFC 9562); it is never shortened, repaired or recorded.
- Every follow-up call carries the accepted value: as the HTTP header, as
  ``_meta.correlation_id`` in MCP requests, and in the state of a flow run.
- ``traceparent`` (W3C Trace Context) may travel alongside; it never replaces
  the correlation id, which is what audit events carry.
"""

from __future__ import annotations

import json
import re
import secrets
import time
import uuid
from collections.abc import Iterable, Mapping
from functools import cache
from typing import TypeGuard

from papaia_kit._resources import schemas_dir

CORRELATION_HEADER = "X-Papaia-Correlation-Id"
MCP_META_KEY = "correlation_id"
MAX_CORRELATION_ID_LENGTH = 64

_VALID = re.compile(r"[A-Za-z0-9-]{1,64}")
_HEADER_KEY = CORRELATION_HEADER.lower()

__all__ = [
    "CORRELATION_HEADER",
    "MAX_CORRELATION_ID_LENGTH",
    "MCP_META_KEY",
    "accept_correlation_id",
    "correlation_headers",
    "correlation_id_from_headers",
    "correlation_id_from_mcp_meta",
    "is_valid_correlation_id",
    "mcp_meta",
    "new_correlation_id",
]


@cache
def _token_shape() -> re.Pattern[str]:
    """The token rule of the audit schema, so header path and schema always agree."""
    schema = json.loads((schemas_dir() / "audit.v1.schema.json").read_text(encoding="utf-8"))
    pattern: str = schema["$defs"]["token_free"]["not"]["pattern"]
    return re.compile(pattern)


def is_valid_correlation_id(value: object) -> TypeGuard[str]:
    """True if ``value`` is a string that satisfies the correlation id rule."""
    return (
        isinstance(value, str)
        and _VALID.fullmatch(value) is not None
        and _token_shape().search(value) is None
    )


def new_correlation_id() -> str:
    """A new correlation id: a UUIDv7 (48 bit Unix milliseconds, 74 random bits)."""
    millis = time.time_ns() // 1_000_000
    value = (millis & ((1 << 48) - 1)) << 80
    value |= 0x7 << 76  # version
    value |= secrets.randbits(12) << 64  # rand_a
    value |= 0b10 << 62  # variant
    value |= secrets.randbits(62)  # rand_b
    return str(uuid.UUID(int=value))


def accept_correlation_id(value: object) -> str:
    """The value itself if valid, otherwise a new correlation id.

    The replaced value is dropped on purpose: it may be oversized or carry data
    that must not reach logs or audit events.
    """
    if is_valid_correlation_id(value):
        return str(value)
    return new_correlation_id()


def correlation_id_from_headers(
    headers: Mapping[str, str] | Iterable[tuple[str, str]],
) -> str:
    """Accepted correlation id of an incoming request.

    Header names compare case-insensitively. Repeated headers with different
    values are ambiguous and get a new id, like an invalid value.
    """
    items = headers.items() if isinstance(headers, Mapping) else headers
    values = {value for name, value in items if name.lower() == _HEADER_KEY}
    if len(values) != 1:
        return new_correlation_id()
    return accept_correlation_id(values.pop())


def correlation_id_from_mcp_meta(meta: object) -> str:
    """Accepted correlation id from the ``_meta`` object of an MCP request.

    ``_meta`` comes from the wire: anything that is not an object (missing,
    a list, a string) counts as a missing value and gets a new id.
    """
    value = meta.get(MCP_META_KEY) if isinstance(meta, Mapping) else None
    return accept_correlation_id(value)


def _checked(correlation_id: str) -> str:
    if not is_valid_correlation_id(correlation_id):
        # The value is not echoed: it failed the rule and may carry anything.
        raise ValueError("refusing to propagate an invalid correlation id; accept it first")
    return correlation_id


def correlation_headers(correlation_id: str) -> dict[str, str]:
    """Header to set on every outgoing HTTP call."""
    return {CORRELATION_HEADER: _checked(correlation_id)}


def mcp_meta(correlation_id: str) -> dict[str, str]:
    """Entries to merge into ``_meta`` of every outgoing MCP request."""
    return {MCP_META_KEY: _checked(correlation_id)}
