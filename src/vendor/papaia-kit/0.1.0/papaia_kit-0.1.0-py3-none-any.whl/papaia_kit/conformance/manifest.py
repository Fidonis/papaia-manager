"""Manifest suite: the section ``exposes:`` against the schema, the naming register and the
checks beyond the schema listed in ``contract/exposes.md``.

Every add-on runs it in its own CI over its manifest ``papaia-app.yaml``; the core
runs it over the ``exposes.yaml`` of its profiles. Several files given together
are one installation, so catalog ids must be unique across all of them.
"""

from __future__ import annotations

import json
import re
import time
from collections.abc import Iterator, Mapping, Sequence
from collections.abc import Set as AbstractSet
from dataclasses import dataclass
from functools import cache
from pathlib import Path
from typing import Any

import yaml
from jsonschema import Draft202012Validator

from papaia_kit._resources import contract_dir, schemas_dir
from papaia_kit.conformance.ecma_regex import ecma_pattern_error
from papaia_kit.conformance.result import Case, SuiteResult, case
from papaia_kit.names import (
    MAX_NAME_LENGTH,
    ROLE_MODULES,
    InvalidName,
    Kind,
    successor,
    validate,
)

SUITE = "manifest"
MANIFEST_CHECKS = (
    "load",
    "schema",
    "unique-ids",
    "names",
    "id-field",
    "patterns",
    "delegation",
    "accounts",
    "volumes",
    "instructions",
)
# JUnit property, one per manifest that marks entries with header identity; its
# value lists their ids.
HEADER_IDENTITY_PROPERTY = "header_identity"
MAX_MANIFEST_BYTES = 1024 * 1024
# Deepest nesting of mappings and sequences a manifest may use; embedded JSON
# schemas stay far below it, and it keeps the recursive composer and every walk
# below the interpreter's recursion limit.
MAX_NESTING = 64
_MAX_MESSAGE = 300

# Plain-text fields of the manifest (contract/exposes.md "Plain text"), plus the
# title and description keywords of embedded schemas, which reach models as
# tool descriptions.
_PLAIN_TEXT_KEYS = frozenset(
    {
        "title",
        "description",
        "summary",
        "example",
        "purpose",
        "legal_basis",
        "way",
        "reason",
        "note",
        "role_hint",
        "responsible",
    }
)

# Subschema positions of JSON Schema 2020-12 (plus the older names a document
# may still carry); values under any other keyword are data, not schemas.
_SCHEMA_MAPS = ("properties", "patternProperties", "$defs", "definitions", "dependentSchemas")
_SCHEMA_ONE = (
    "additionalProperties",
    "unevaluatedProperties",
    "items",
    "additionalItems",
    "unevaluatedItems",
    "contains",
    "propertyNames",
    "not",
    "if",
    "then",
    "else",
    "contentSchema",
)
_SCHEMA_LISTS = ("allOf", "anyOf", "oneOf", "prefixItems")


@dataclass(frozen=True, slots=True)
class DelegationHolder:
    module: str
    client: str


# A delegation is held at exactly one client (contract/exposes.md "Delegation").
DELEGATION_HOLDERS: Mapping[str, DelegationHolder] = {
    "flow": DelegationHolder("papaia-flow", "flow-engine"),
    "assist": DelegationHolder("papaia-assist", "assist-gate"),
}


class ManifestError(ValueError):
    """A manifest or compose file cannot be read as a YAML mapping."""


# --- loading ------------------------------------------------------------------


class _StrictLoader(yaml.SafeLoader):
    """Safe loader that rejects duplicate keys, anchors and aliases.

    A duplicate key would let a later value silently replace a reviewed one;
    aliases let a small file expand without bound. Nesting is capped at
    ``MAX_NESTING`` levels.
    """

    _depth = 0

    def compose_node(self, parent: Any, index: Any) -> Any:
        event = self.peek_event()  # type: ignore[no-untyped-call]
        if isinstance(event, yaml.AliasEvent) or getattr(event, "anchor", None) is not None:
            raise ManifestError(
                f"anchors and aliases are not allowed (line {event.start_mark.line + 1})"
            )
        if self._depth >= MAX_NESTING:
            raise ManifestError(
                f"nested too deeply (more than {MAX_NESTING} levels, "
                f"line {event.start_mark.line + 1})"
            )
        self._depth += 1
        try:
            return super().compose_node(parent, index)
        finally:
            self._depth -= 1

    def construct_mapping(self, node: Any, deep: bool = False) -> dict[Any, Any]:
        seen: set[object] = set()
        for key_node, _ in node.value:
            key = self.construct_object(key_node, deep=deep)
            try:
                duplicate = key in seen
            except TypeError:
                raise ManifestError(
                    f"key is not a plain value (line {key_node.start_mark.line + 1})"
                ) from None
            if duplicate:
                raise ManifestError(f"duplicate key {key!r} (line {key_node.start_mark.line + 1})")
            seen.add(key)
        return super().construct_mapping(node, deep=deep)


def _load_yaml(path: Path) -> Any:
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise ManifestError(f"cannot read ({exc.strerror or type(exc).__name__})") from None
    if len(data) > MAX_MANIFEST_BYTES:
        raise ManifestError(f"larger than {MAX_MANIFEST_BYTES} bytes")
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        raise ManifestError("not UTF-8") from None
    try:
        return yaml.load(text, Loader=_StrictLoader)  # noqa: S506 - _StrictLoader is a SafeLoader
    except RecursionError:
        raise ManifestError("nested too deeply") from None
    except yaml.YAMLError as exc:
        problem = getattr(exc, "problem", None) or type(exc).__name__
        mark = getattr(exc, "problem_mark", None)
        where = f" at line {mark.line + 1}" if mark is not None else ""
        raise ManifestError(f"not YAML ({problem}{where})") from None


def load_manifest(path: Path) -> dict[str, Any]:
    """The manifest (or core-profile file) as a mapping with a key ``exposes``."""
    document = _load_yaml(path)
    if not isinstance(document, dict):
        raise ManifestError("expected a mapping at the top level")
    if "exposes" not in document:
        raise ManifestError("no exposes: section")
    return document


def load_compose_volumes(path: Path) -> frozenset[str]:
    """Names of the top-level volumes of a compose file."""
    document = _load_yaml(path)
    if not isinstance(document, dict):
        raise ManifestError("compose file: expected a mapping at the top level")
    volumes = document.get("volumes") or {}
    if not isinstance(volumes, dict) or not all(isinstance(k, str) for k in volumes):
        raise ManifestError("compose file: volumes: is not a mapping of names")
    return frozenset(volumes)


# --- suite --------------------------------------------------------------------


def check_manifest_files(
    paths: Sequence[Path], *, compose: Path | None = None, core_profile: bool = False
) -> SuiteResult:
    """Run the manifest suite over the files of one installation.

    ``compose`` is the compose file of the module; it is only allowed with exactly
    one manifest. ``core_profile`` checks the ``exposes.yaml`` of core profiles,
    which carry no ``name``; without it every file is an add-on manifest and
    must name its module. Raises ``ManifestError`` if the compose file cannot
    be read.
    """
    if compose is not None and len(paths) != 1:
        raise ValueError("--compose takes exactly one manifest")
    compose_volumes = load_compose_volumes(compose) if compose is not None else None
    started = time.monotonic()
    names = [p.name for p in paths]
    labels = [p.name if names.count(p.name) == 1 else str(p) for p in paths]
    loaded: list[tuple[str, Any]] = []
    load_failures: list[Case] = []
    for label, path in zip(labels, paths, strict=True):
        try:
            loaded.append((label, load_manifest(path)))
        except ManifestError as exc:
            load_failures.append(case(SUITE, label, "load", [f"{label}: {exc}"]))
    checked = check_manifest_documents(
        loaded, compose_volumes=compose_volumes, core_profile=core_profile
    )
    by_label = {label: index for index, label in enumerate(labels)}
    cases = sorted(
        (*load_failures, *checked.cases),
        key=lambda c: (by_label[c.group], MANIFEST_CHECKS.index(c.name)),
    )
    return SuiteResult(SUITE, tuple(cases), time.monotonic() - started, checked.properties)


def check_manifest_documents(
    documents: Sequence[tuple[str, Any]],
    *,
    compose_volumes: AbstractSet[str] | None = None,
    core_profile: bool = False,
) -> SuiteResult:
    """Run every check but ``load`` over loaded manifests, given as ``(label, document)``."""
    if compose_volumes is not None and len(documents) != 1:
        raise ValueError("compose volumes need exactly one manifest")
    started = time.monotonic()
    seen_ids: dict[str, str] = {}
    cases: list[Case] = []
    properties: list[tuple[str, str]] = []
    for label, document in documents:
        entries = _entries(document)
        checks: dict[str, list[str]] = {
            "load": [],
            "schema": _schema(document),
            "unique-ids": _unique_ids(label, entries, seen_ids),
            "names": _names(document, entries, core_profile=core_profile),
            "id-field": _id_fields(entries),
            "patterns": _patterns(entries),
            "delegation": _delegation(document, entries),
            "accounts": _accounts(entries),
            "volumes": _volumes(entries, compose_volumes),
            "instructions": _instructions(document.get("exposes")),
        }
        cases += [case(SUITE, label, name, checks[name]) for name in MANIFEST_CHECKS]
        if not checks["schema"]:
            marked = header_identity_entries(document)
            if marked:
                properties.append((f"{HEADER_IDENTITY_PROPERTY}.{label}", ", ".join(marked)))
    return SuiteResult(SUITE, tuple(cases), time.monotonic() - started, tuple(properties))


def header_identity_entries(document: Mapping[str, Any]) -> tuple[str, ...]:
    """Ids of the entries that take a person's identity from a request header.

    The core refuses to publish a port for these entries' services, also on
    ``127.0.0.1`` (contract/exposes.md "Header identity"). A missing marker is
    ``false``. A marker that is not a boolean, or a marked entry without a string
    ``id``, raises ``ManifestError`` instead of being read as ``false``, so a
    caller that skipped the schema check never opens a port by mistake.
    """
    section = document.get("exposes")
    if not isinstance(section, list):
        raise ManifestError("exposes: is not a list of entries")
    marked: list[str] = []
    for index, entry in enumerate(section):
        if not isinstance(entry, Mapping) or "header_identity" not in entry:
            continue
        value = entry["header_identity"]
        if not isinstance(value, bool):
            raise ManifestError(f"exposes/{index}/header_identity: must be true or false")
        if not value:
            continue
        entry_id = entry.get("id")
        if not isinstance(entry_id, str):
            raise ManifestError(f"exposes/{index}/id: missing on an entry with header_identity")
        marked.append(entry_id)
    return tuple(marked)


def _entries(document: Mapping[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    section = document.get("exposes")
    if not isinstance(section, list):
        return []
    return [(f"exposes/{i}", e) for i, e in enumerate(section) if isinstance(e, dict)]


def _items(entry: Mapping[str, Any], key: str, where: str) -> Iterator[tuple[str, Any]]:
    value = entry.get(key)
    if isinstance(value, list):
        for index, item in enumerate(value):
            yield f"{where}/{key}/{index}", item


def _short(text: str) -> str:
    return text if len(text) <= _MAX_MESSAGE else text[: _MAX_MESSAGE - 3] + "..."


def _pointer(key: object) -> str:
    return str(key).replace("~", "~0").replace("/", "~1")


# --- checks -------------------------------------------------------------------


@cache
def _validator() -> Draft202012Validator:
    schema = json.loads((schemas_dir() / "exposes.v1.schema.json").read_text(encoding="utf-8"))
    # No format checker: the meta-schema marks `pattern` as format "regex", which
    # Python would check in its own dialect. The ECMA-262 check is `patterns`.
    return Draft202012Validator(schema)


def _schema(document: Mapping[str, Any]) -> list[str]:
    errors = sorted(
        _validator().iter_errors(document.get("exposes")),
        key=lambda e: [str(p) for p in e.absolute_path],
    )
    return [
        _short("/".join(["exposes", *(_pointer(p) for p in e.absolute_path)]) + f": {e.message}")
        for e in errors
    ]


def _unique_ids(
    label: str, entries: list[tuple[str, dict[str, Any]]], seen: dict[str, str]
) -> list[str]:
    failures = []
    for where, entry in entries:
        entry_id = entry.get("id")
        if not isinstance(entry_id, str):
            continue
        if entry_id in seen:
            failures.append(f"{where}/id: {entry_id!r} is also declared in {seen[entry_id]}")
        else:
            seen[entry_id] = f"{label} {where}/id"
    return failures


_NAME_SEGMENTS = re.compile(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*")

# First segments a module prefix may not take: the platform's own namespace and
# the prefixes of clients, service accounts, audiences and exchange scopes.
RESERVED_PREFIXES = frozenset({"papaia", "svc", "mcp", "aud"})
# Roles of other modules a service account of any module may hold.
SHARED_SERVICE_ACCOUNT_ROLES = frozenset({"prefs-read"})
# A module name leaves room for ``svc-<module>-<purpose>`` within the limit.
_MAX_MODULE_NAME = 40


@dataclass(frozen=True, slots=True)
class _Module:
    """The owner of the names in one file: ``prefix`` is ``None`` for a core profile."""

    name: str | None
    prefix: str | None
    failures: tuple[str, ...]


def _module(document: Mapping[str, Any], *, core_profile: bool) -> _Module:
    """``flow`` for the manifest ``papaia-flow``, ``paperless`` for ``paperless``.

    A core profile has no name and no prefix. An add-on manifest must name its
    module; the prefix may not fall into a reserved namespace, and the prefix of
    a platform module (``studio`` ...) belongs only to ``papaia-<module>``.
    """
    if core_profile:
        if "name" not in document:
            return _Module(None, None, ())
        failure = "name: a core profile has no name; check add-on manifests without --core-profile"
        return _Module(None, None, (failure,))
    if "name" not in document:
        failure = (
            "name: missing; an add-on manifest names its module "
            "(a core profile is checked with --core-profile)"
        )
        return _Module(None, None, (failure,))
    name = document["name"]
    problem = _module_name_failure(name)
    if problem is not None:
        return _Module(None, None, (_short(problem),))
    return _Module(name, name.removeprefix("papaia-"), ())


def _module_name_failure(name: object) -> str | None:
    if (
        not isinstance(name, str)
        or len(name) > _MAX_MODULE_NAME
        or not _NAME_SEGMENTS.fullmatch(name)
    ):
        return (
            f"name: {name!r} is not a valid module name (lower-case ASCII letters and "
            f"digits in segments joined by '-', at most {_MAX_MODULE_NAME} characters)"
        )
    first = name.removeprefix("papaia-").split("-", 1)[0]
    if first in RESERVED_PREFIXES:
        return f"name: {name!r} falls into the reserved namespace {first!r}"
    if first in ROLE_MODULES and name != f"papaia-{first}":
        return (
            f"name: {name!r} takes the prefix of the platform module {first!r}; "
            f"only 'papaia-{first}' may use it"
        )
    return None


def _own_role(name: str, prefix: str | None) -> bool:
    """A role ``<module>-<role>`` of the manifest's own module.

    The register lists the role prefixes of the platform modules; an add-on
    module names its roles after itself (architecture V-12), so its own prefix
    is accepted here unless the name was removed.
    """
    if prefix is None or not name.startswith(f"{prefix}-") or len(name) > MAX_NAME_LENGTH:
        return False
    if not _NAME_SEGMENTS.fullmatch(name):
        return False
    try:
        return successor(name, Kind.ROLE) is None
    except InvalidName:
        return False


def _names(
    document: Mapping[str, Any],
    entries: list[tuple[str, dict[str, Any]]],
    *,
    core_profile: bool,
) -> list[str]:
    module = _module(document, core_profile=core_profile)
    prefix = module.prefix
    found: list[tuple[str, object, Kind]] = []
    # Names the core creates for this module: they carry the module's own prefix.
    owned: list[tuple[str, object, str]] = []
    # Roles a service account of this module asks for.
    account_roles: list[tuple[str, object]] = []
    for where, entry in entries:
        found.append((f"{where}/audience", entry.get("audience"), Kind.AUDIENCE))
        for at, role in _items(entry, "roles", where):
            if isinstance(role, dict):
                found.append((f"{at}/name", role.get("name"), Kind.ROLE))
                owned.append((f"{at}/name", role.get("name"), f"{prefix}-"))
        for at, surface in _items(entry, "ui", where):
            if isinstance(surface, dict):
                found += [(r, n, Kind.ROLE) for r, n in _items(surface, "visible_for_roles", at)]
        for at, account in _items(entry, "service_accounts", where):
            if not isinstance(account, dict):
                continue
            found.append((f"{at}/id", account.get("id"), Kind.SERVICE_ACCOUNT))
            owned.append((f"{at}/id", account.get("id"), f"svc-{prefix}-"))
            roles = list(_items(account, "roles", at))
            found += [(r, n, Kind.ROLE) for r, n in roles]
            account_roles += roles
            found += [(r, n, Kind.AUDIENCE) for r, n in _items(account, "audiences", at)]
    failures = list(module.failures)
    for where, name, kind in found:
        if not isinstance(name, str):
            continue  # absent or of the wrong type: the schema check reports it
        if kind is Kind.ROLE and _own_role(name, prefix):
            continue
        try:
            validate(name, kind)
        except InvalidName as exc:
            failures.append(_short(f"{where}: {exc}"))
    if module.failures or core_profile:
        # A core profile is the platform's own declaration: its names are checked
        # against the register only. An add-on without a valid module name owns
        # no names; the failure above already fails the check.
        return failures
    failures += [
        _short(
            f"{where}: {name!r} does not belong to module {module.name!r} "
            f"(expected prefix {start!r})"
        )
        for where, name, start in owned
        if isinstance(name, str) and not name.startswith(start)
    ]
    failures += [
        _short(
            f"{where}: {name!r} is not a role a service account of module {module.name!r} "
            f"may hold (own roles '{prefix}-<role>' or "
            f"{', '.join(sorted(SHARED_SERVICE_ACCOUNT_ROLES))})"
        )
        for where, name in account_roles
        if isinstance(name, str)
        and not name.startswith(f"{prefix}-")
        and name not in SHARED_SERVICE_ACCOUNT_ROLES
    ]
    return failures


def _operations(
    entries: list[tuple[str, dict[str, Any]]],
) -> Iterator[tuple[str, dict[str, Any]]]:
    for where, entry in entries:
        for at, operation in _items(entry, "operations", where):
            if isinstance(operation, dict):
                yield at, operation


def _id_fields(entries: list[tuple[str, dict[str, Any]]]) -> list[str]:
    failures = []
    for where, operation in _operations(entries):
        resource = operation.get("resource")
        if not isinstance(resource, dict) or not isinstance(resource.get("id_field"), str):
            continue
        field = resource["id_field"]
        schema = operation.get("input_schema")
        properties = schema.get("properties") if isinstance(schema, dict) else None
        if not isinstance(properties, dict) or field not in properties:
            failures.append(
                _short(f"{where}/resource/id_field: {field!r} is not a property of input_schema")
            )
    return failures


def _embedded_schemas(
    entries: list[tuple[str, dict[str, Any]]],
) -> Iterator[tuple[str, object]]:
    for where, operation in _operations(entries):
        for key in ("input_schema", "output_schema"):
            yield f"{where}/{key}", operation.get(key)
    for where, entry in entries:
        for at, event in _items(entry, "events", where):
            if isinstance(event, dict):
                yield f"{at}/payload_schema", event.get("payload_schema")


def _subschemas(schema: dict[str, Any], where: str) -> Iterator[tuple[str, object]]:
    for keyword in _SCHEMA_MAPS:
        children = schema.get(keyword)
        if isinstance(children, dict):
            for name, child in children.items():
                yield f"{where}/{keyword}/{_pointer(name)}", child
    for keyword in _SCHEMA_ONE:
        child = schema.get(keyword)
        if isinstance(child, list) and keyword == "items":
            yield from ((f"{where}/items/{i}", item) for i, item in enumerate(child))
        else:
            yield f"{where}/{keyword}", child
    for keyword in _SCHEMA_LISTS:
        children = schema.get(keyword)
        if isinstance(children, list):
            yield from ((f"{where}/{keyword}/{i}", c) for i, c in enumerate(children))


def _schema_patterns(schema: object, where: str) -> Iterator[tuple[str, str]]:
    """``(location, pattern)`` of every ``pattern`` and ``patternProperties`` key."""
    if not isinstance(schema, dict):
        return
    pattern = schema.get("pattern")
    if isinstance(pattern, str):
        yield f"{where}/pattern", pattern
    keyed = schema.get("patternProperties")
    if isinstance(keyed, dict):
        for key in keyed:
            if isinstance(key, str):
                yield f"{where}/patternProperties/{_pointer(key)}", key
    for at, child in _subschemas(schema, where):
        yield from _schema_patterns(child, at)


def _patterns(entries: list[tuple[str, dict[str, Any]]]) -> list[str]:
    failures = []
    for where, schema in _embedded_schemas(entries):
        for at, pattern in _schema_patterns(schema, where):
            error = ecma_pattern_error(pattern)
            if error is not None:
                failures.append(
                    _short(
                        f"{at}: {pattern!r} does not compile as an ECMA-262 regular "
                        f"expression: {error}"
                    )
                )
    return failures


def _delegation(
    document: Mapping[str, Any], entries: list[tuple[str, dict[str, Any]]]
) -> list[str]:
    module = document.get("name")
    holder_text = repr(module) if isinstance(module, str) else "a manifest without name"
    failures = []
    for where, entry in entries:
        delegation = entry.get("delegation")
        if not isinstance(delegation, dict):
            continue
        for at, purpose in _items(delegation, "purposes", f"{where}/delegation"):
            if not isinstance(purpose, str):
                continue
            holder = DELEGATION_HOLDERS.get(purpose.split(".", 1)[0])
            if holder is not None and module != holder.module:
                failures.append(
                    f"{at}: purpose {purpose!r} is held only by {holder.module} "
                    f"(client {holder.client}), not by {holder_text}"
                )
    return failures


def _accounts(entries: list[tuple[str, dict[str, Any]]]) -> list[str]:
    failures = []
    for where, entry in entries:
        for at, account in _items(entry, "service_accounts", where):
            if not isinstance(account, dict):
                continue
            owner, deputy = account.get("owner_sub"), account.get("deputy_sub")
            if isinstance(owner, str) and owner == deputy:
                failures.append(f"{at}/deputy_sub: must differ from owner_sub")
        delegation = entry.get("delegation")
        if isinstance(delegation, dict):
            idle, age = delegation.get("max_idle_days"), delegation.get("max_age_days")
            if isinstance(idle, int) and isinstance(age, int) and idle > age:
                failures.append(
                    f"{where}/delegation/max_idle_days: {idle} is greater than max_age_days {age}"
                )
    return failures


def _volumes(
    entries: list[tuple[str, dict[str, Any]]], compose_volumes: AbstractSet[str] | None
) -> list[str]:
    declared: list[tuple[str, str]] = []
    for where, entry in entries:
        for at, volume in _items(entry, "volumes", where):
            if isinstance(volume, dict) and isinstance(volume.get("name"), str):
                declared.append((f"{at}/name", volume["name"]))
    names = {name for _, name in declared}
    failures = []
    for where, entry in entries:
        storage = entry.get("storage")
        if not isinstance(storage, dict):
            continue
        for at, secret in _items(storage, "secrets", f"{where}/storage"):
            location = secret.get("location") if isinstance(secret, dict) else None
            if isinstance(location, str) and location not in names:
                failures.append(f"{at}/location: {location!r} is not declared in volumes[]")
    if compose_volumes is not None:
        failures += [
            f"{at}: {name!r} is not a volume of the compose file"
            for at, name in declared
            if name not in compose_volumes
        ]
        failures += [
            f"compose: volume {name!r} is not declared in volumes[]"
            for name in sorted(compose_volumes - names)
        ]
    return failures


@dataclass(frozen=True, slots=True)
class _InstructionPattern:
    id: str
    regex: re.Pattern[str]


@cache
def _instruction_patterns() -> tuple[_InstructionPattern, ...]:
    path = contract_dir() / "instruction-patterns.yaml"
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("version") != 1:
        raise ValueError("instruction-patterns.yaml: expected a mapping with version 1")
    return tuple(
        _InstructionPattern(item["id"], re.compile(item["regex"], re.IGNORECASE))
        for item in data["patterns"]
    )


def _instruction(text: str) -> str | None:
    for pattern in _instruction_patterns():
        if pattern.regex.search(text):
            return pattern.id
    return None


def _plain_texts(node: object, where: str) -> Iterator[tuple[str, str]]:
    if isinstance(node, list):
        for index, item in enumerate(node):
            yield from _plain_texts(item, f"{where}/{index}")
        return
    if not isinstance(node, dict):
        return
    for key, value in node.items():
        at = f"{where}/{_pointer(key)}"
        if key in _PLAIN_TEXT_KEYS:
            if isinstance(value, str):
                yield at, value
            elif isinstance(value, dict):
                for language, text in value.items():
                    if isinstance(text, str):
                        yield f"{at}/{_pointer(language)}", text
        yield from _plain_texts(value, at)


def _instructions(section: object) -> list[str]:
    failures = []
    for where, text in _plain_texts(section, "exposes"):
        found = _instruction(text)
        if found is not None:
            failures.append(f"{where}: text reads like an instruction to a model ({found})")
    return failures
