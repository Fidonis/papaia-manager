"""Handover suite: one version of the Data to Studio handover schema (V-09, RE-28, DAT-17-A3).

The schema file of ``papaia.data-handover/1`` lives in Data
(``schemas/data-handover-1.json``) and nowhere else is it authoritative; Studio
pins its digest and the bill of materials of the suite lists it. The suite
computes the digest of a schema file (Data's file or Studio's copy) and
compares it with every pin given and with the entry of the bill of materials.
Checks, one case each:

- ``schema``: the file is strict JSON, a JSON Schema (draft 2020-12) of an
  object with ``additionalProperties: false`` whose ``contract_version`` is the
  constant ``papaia.data-handover/1``;
- ``pin``: the digest equals every pin (``--pin``, ``--pin-file``);
- ``bom``: the digest equals the digest of the bill of materials.

The digest is ``sha256:`` over the RFC 8785 canonical form of the file, so
formatting does not change it. Messages name files, places and digests, never
other content.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError

from papaia_kit.catalog import canonical_json
from papaia_kit.conformance.manifest import ManifestError, _load_yaml
from papaia_kit.conformance.result import Case, SuiteResult, case

SUITE = "handover"
HANDOVER_CHECKS = ("schema", "pin", "bom")
HANDOVER_CONTRACT = "papaia.data-handover/1"
MAX_SCHEMA_BYTES = 1024 * 1024
MAX_PIN_BYTES = 1024
# Fields of a contract entry in the bill of materials.
BOM_ENTRY_FIELDS = frozenset({"name", "repo", "path", "digest"})
_DIGEST = re.compile(r"sha256:[0-9a-f]{64}")
_NOT_RUN = "not run: the schema file fails its check"


class HandoverError(ValueError):
    """Unusable input of the suite (nothing to compare, unreadable pin file): exit code 2."""


def handover_digest(schema: Any) -> str:
    """``sha256:`` over the RFC 8785 canonical form of the schema document."""
    return "sha256:" + hashlib.sha256(canonical_json(schema)).hexdigest()


def load_pin_file(path: Path) -> str:
    """The one digest of a pin file: ``sha256:<64 hex>`` and an optional line break."""
    try:
        with path.open("rb") as handle:
            raw = handle.read(MAX_PIN_BYTES + 1)
    except OSError as exc:
        raise HandoverError(f"cannot read the pin file {path}: {exc.strerror}") from None
    if len(raw) > MAX_PIN_BYTES:
        raise HandoverError(f"pin file {path} is larger than {MAX_PIN_BYTES} bytes")
    text = raw.decode("ascii", errors="replace").removesuffix("\n")
    if not _DIGEST.fullmatch(text):
        raise HandoverError(f"pin file {path} must hold one sha256:<64 lower-case hex digits>")
    return text


def _unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate member name")
        result[key] = value
    return result


def _load_schema(  # noqa: PLR0911 - one return per way the file can fail
    path: Path,
) -> tuple[dict[str, Any] | None, list[str]]:
    try:
        with path.open("rb") as handle:
            raw = handle.read(MAX_SCHEMA_BYTES + 1)
    except OSError as exc:
        return None, [f"cannot read ({exc.strerror or type(exc).__name__})"]
    if len(raw) > MAX_SCHEMA_BYTES:
        return None, [f"larger than {MAX_SCHEMA_BYTES} bytes"]
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return None, ["not UTF-8"]
    try:
        document = json.loads(text, object_pairs_hook=_unique)
    except ValueError as exc:
        reason = "duplicate member name" if "duplicate" in str(exc) else "not JSON"
        return None, [reason]
    except RecursionError:
        return None, ["not JSON (nested too deeply)"]
    if not isinstance(document, dict):
        return None, ["the schema must be a JSON object"]
    return document, _schema_problems(document)


def _schema_problems(document: Mapping[str, Any]) -> list[str]:
    try:
        Draft202012Validator.check_schema(document)
    except SchemaError as error:
        where = "/".join(str(p) for p in error.absolute_path) or "(root)"
        return [f"not a JSON Schema (draft 2020-12): {where} fails {error.validator}"]
    problems = []
    if document.get("type") != "object" or document.get("additionalProperties") is not False:
        # DAT-17-A2: rows, query text and tokens stay out only through a closed object.
        problems.append("the root must be an object with additionalProperties: false")
    properties = document.get("properties")
    version = properties.get("contract_version") if isinstance(properties, dict) else None
    if not isinstance(version, dict) or version.get("const") != HANDOVER_CONTRACT:
        problems.append(f"properties/contract_version must be the constant {HANDOVER_CONTRACT}")
    try:
        canonical_json(document)
    except (ValueError, TypeError):
        problems.append("the schema has no canonical form (RFC 8785)")
    return problems


def _bom_digest(  # noqa: PLR0911 - one return per way the bill can fail
    path: Path,
) -> tuple[str | None, str | None]:
    """The digest of the handover entry in the bill of materials, or the reason there is none."""
    try:
        document = _load_yaml(path)
    except ManifestError as exc:
        return None, f"bill of materials {path.name}: {exc}"
    if not isinstance(document, dict):
        return None, f"bill of materials {path.name}: expected a mapping at the top level"
    if "contracts" not in document:
        return None, f"bill of materials {path.name}: no contracts: section"
    contracts = document["contracts"]
    if not isinstance(contracts, list):
        return None, f"bill of materials {path.name}: contracts must be a list"
    entries = [e for e in contracts if isinstance(e, dict) and e.get("name") == HANDOVER_CONTRACT]
    if not entries:
        return None, f"bill of materials {path.name}: no entry {HANDOVER_CONTRACT} in contracts"
    if len(entries) > 1:
        return None, f"bill of materials {path.name}: more than one entry {HANDOVER_CONTRACT}"
    entry = entries[0]
    if unknown := sorted(str(key) for key in set(entry) - BOM_ENTRY_FIELDS):
        return None, f"bill of materials {path.name}: unknown fields {unknown} in the entry"
    digest = entry.get("digest")
    if not isinstance(digest, str) or not _DIGEST.fullmatch(digest):
        return None, (
            f"bill of materials {path.name}: the entry needs a digest "
            "sha256:<64 lower-case hex digits>"
        )
    return digest, None


def run_handover_suite(
    schema: Path,
    *,
    pins: Sequence[tuple[str, str]] = (),
    bom: Path | None = None,
) -> SuiteResult:
    """Check the schema file and compare its digest with ``pins`` and the bill of materials.

    ``pins`` are ``(source, digest)`` pairs; the source names the pin in messages
    (``--pin`` or the pin file). At least one pin or a bill of materials is needed.
    """
    if not pins and bom is None:
        raise HandoverError("nothing to compare: give --pin, --pin-file or --bom")
    for source, value in pins:
        if not _DIGEST.fullmatch(value):
            raise HandoverError(f"{source}: expected sha256:<64 lower-case hex digits>")
    started = time.monotonic()
    group = schema.name
    document, problems = _load_schema(schema)
    cases: list[Case] = [case(SUITE, group, "schema", problems)]
    digest = handover_digest(document) if document is not None and not problems else None
    if pins:
        failures = (
            [_NOT_RUN]
            if digest is None
            else [
                f"digest {digest} does not match {source} {value}"
                for source, value in pins
                if value != digest
            ]
        )
        cases.append(case(SUITE, group, "pin", failures))
    if bom is not None:
        expected, reason = _bom_digest(bom)
        if reason is not None:
            failures = [reason]
        elif digest is None:
            failures = [_NOT_RUN]
        else:
            failures = (
                [f"digest {digest} does not match the bill of materials {expected}"]
                if expected != digest
                else []
            )
        cases.append(case(SUITE, group, "bom", failures))
    properties = (("digest", digest),) if digest is not None else ()
    return SuiteResult(SUITE, tuple(cases), time.monotonic() - started, properties)
