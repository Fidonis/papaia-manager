"""Types shared by the rules and the register."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class Kind(StrEnum):
    """Kind of a named object. A name is only valid together with its kind."""

    AUDIENCE = "audience"
    CLIENT = "client"
    SCOPE = "scope"
    ROLE = "role"
    SERVICE_ACCOUNT = "service-account"
    SERVICE = "service"
    NETWORK = "network"

    @property
    def label(self) -> str:
        return self.value.replace("-", " ")


@dataclass(frozen=True, slots=True)
class Entry:
    """One registered name with the repository that owns it."""

    name: str
    kind: Kind
    owner: str
    purpose: str
    # Only for clients: standard token exchange enabled. A client with token
    # exchange is never an audience, except the chain holder (security 1.2).
    token_exchange: bool = False
    # Exists only in the realm of the test profile, never in a product realm
    # (security 1.2, PLT-21-A5).
    test_profile_only: bool = False


@dataclass(frozen=True, slots=True)
class Removed:
    """A name that is no longer allowed, with the name that replaces it."""

    name: str
    successor: str
    reason: str
    # None: removed for every kind
    kinds: frozenset[Kind] | None = None
    # Last stage in which the realm sync may still create the old name next to
    # its successor; None: no transition. Validation rejects the name anyway.
    until_stage: int | None = None


class InvalidName(ValueError):  # noqa: N818 - reads as "raise InvalidName"
    """A name breaks the naming rule of its kind or was removed."""

    def __init__(self, name: str, kind: Kind, reason: str, successor: str | None = None) -> None:
        self.name = name
        self.kind = kind
        self.reason = reason
        self.successor = successor
        message = f"{name!r} is not a valid {kind.label} name: {reason}"
        if successor:
            message += f"; use {successor!r}"
        super().__init__(message)
