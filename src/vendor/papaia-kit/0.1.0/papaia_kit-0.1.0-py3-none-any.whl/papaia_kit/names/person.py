"""The one person identifier: ``sub``.

``person_id`` equals ``sub`` for persons and is absent for service accounts.
A token without a session id (``sid``) comes from ``client_credentials`` and
therefore from a service account (security 1.9). A token without ``sid`` whose
``azp`` is a registered person client contradicts that rule (for example
lightweight tokens) and is rejected instead of being read as a service account.
"""

from __future__ import annotations

from collections.abc import Mapping

from papaia_kit.names._model import Kind
from papaia_kit.names.register import lookup
from papaia_kit.names.rules import is_valid

SUBJECT_CLAIM = "sub"
PERSON_ID_CLAIM = "person_id"
SESSION_CLAIM = "sid"
MAX_SUBJECT_LENGTH = 255


class InvalidClaims(ValueError):  # noqa: N818 - reads as "raise InvalidClaims"
    """The identity claims of a token contradict the person identifier rule."""


def _text(claims: Mapping[str, object], claim: str) -> str:
    value = claims.get(claim)
    if not isinstance(value, str) or not value:
        raise InvalidClaims(f"claim {claim!r} must be a non-empty string")
    if len(value) > MAX_SUBJECT_LENGTH:
        raise InvalidClaims(f"claim {claim!r} is longer than {MAX_SUBJECT_LENGTH} characters")
    if not value.isprintable() or value != value.strip():
        raise InvalidClaims(f"claim {claim!r} contains whitespace or control characters")
    return value


def person_id(claims: Mapping[str, object]) -> str | None:
    """The person identifier of verified token claims, or None for a service account.

    The claims must already be verified (signature, issuer, audience); this
    function only applies the identifier rule. It never returns anything but
    ``sub``, so every store keys persons by ``sub``.
    """
    if not isinstance(claims, Mapping):
        raise TypeError(f"claims must be a mapping, not {type(claims).__name__}")
    sub = _text(claims, SUBJECT_CLAIM)
    session = _text(claims, SESSION_CLAIM) if SESSION_CLAIM in claims else None
    azp = claims.get("azp")
    service_client = isinstance(azp, str) and is_valid(azp, Kind.SERVICE_ACCOUNT)
    if service_client and session is not None:
        raise InvalidClaims("service account token carries a session id")
    person_client = isinstance(azp, str) and lookup(azp, Kind.CLIENT) is not None
    if session is None and person_client and not service_client:
        raise InvalidClaims(f"token of person client {azp!r} carries no session id 'sid'")
    if service_client or session is None:
        if PERSON_ID_CLAIM in claims:
            raise InvalidClaims(f"service account token must not carry {PERSON_ID_CLAIM!r}")
        return None
    declared = claims.get(PERSON_ID_CLAIM)
    if declared is not None and declared != sub:
        raise InvalidClaims(f"claim {PERSON_ID_CLAIM!r} differs from {SUBJECT_CLAIM!r}")
    return sub
