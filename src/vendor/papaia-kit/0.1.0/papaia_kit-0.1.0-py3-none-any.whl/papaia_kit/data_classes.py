"""The one data class scale of the platform.

The scale lives in ``schemas/data-classes.json`` and is shared by every module,
add-on and server; none keeps its own list. The position in the file is the
order, from least to most sensitive. Comparisons go by that position, never by
name, so ``employee`` is above ``internal`` although it sorts before it.

Every value that crosses a boundary is parsed strictly: an unknown name, a
different spelling or a non-string raises :class:`UnknownDataClassError`. A caller
that must keep working with an undeclared class decides on its own to treat it
as :func:`highest`; the scale never guesses.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from types import MappingProxyType
from typing import Any

from papaia_kit._resources import schemas_dir

__all__ = [
    "FORMAT",
    "DataClass",
    "Scale",
    "UnknownDataClassError",
    "at_most",
    "compare",
    "exceeds",
    "from_scale",
    "highest",
    "highest_of",
    "ids",
    "load",
    "lowest",
    "parse",
    "scale",
]

FORMAT = "papaia.data-classes/1"
FILE_NAME = "data-classes.json"

_LANGUAGES = frozenset({"de", "en"})
_ID = re.compile(r"[a-z][a-z_]{0,31}")
_MAPPING_ID = re.compile(r"[a-z][a-z0-9-]{0,47}")
_TITLE_MAX = 80
_TEXT_MAX = 400
# Bound for echoing a rejected value in an error message.
_SHOWN_MAX = 40


class UnknownDataClassError(ValueError):
    """A value is not a class of the scale (or not a level of a source scale)."""

    def __init__(self, value: object, where: str = "data class") -> None:
        shown = repr(value)
        if len(shown) > _SHOWN_MAX:
            shown = shown[:_SHOWN_MAX] + "..."
        super().__init__(f"unknown {where} {shown}")


@dataclass(frozen=True)
class DataClass:
    """One class of the scale. Instances order by ``rank``; equality is by id and rank."""

    id: str
    rank: int
    title: Mapping[str, str] = field(compare=False)
    definition: Mapping[str, str] = field(compare=False)

    # Ordering against strings or other types is refused: falling back to string
    # comparison would order alphabetically, which is exactly the error to avoid.
    def __lt__(self, other: object) -> bool:
        return self.rank < _same(other).rank

    def __le__(self, other: object) -> bool:
        return self.rank <= _same(other).rank

    def __gt__(self, other: object) -> bool:
        return self.rank > _same(other).rank

    def __ge__(self, other: object) -> bool:
        return self.rank >= _same(other).rank

    def __str__(self) -> str:
        return self.id


def _same(other: object) -> DataClass:
    if not isinstance(other, DataClass):
        raise TypeError(f"cannot order DataClass against {type(other).__name__}")
    return other


class Scale:
    """The ordered classes plus the mapping tables of older scales."""

    def __init__(
        self, classes: tuple[DataClass, ...], mappings: Mapping[str, Mapping[str, str]]
    ) -> None:
        self.classes = classes
        self._by_id = {entry.id: entry for entry in classes}
        self._mappings = mappings

    def parse(self, value: object) -> DataClass:
        """The class named by ``value`` (exact id) or ``value`` itself if it is one."""
        if isinstance(value, DataClass) and self._by_id.get(value.id) == value:
            return value
        if isinstance(value, str) and value in self._by_id:
            return self._by_id[value]
        raise UnknownDataClassError(value)

    def compare(self, left: object, right: object) -> int:
        """-1, 0 or 1 as ``left`` is less, equally or more sensitive than ``right``."""
        a, b = self.parse(left).rank, self.parse(right).rank
        return (a > b) - (a < b)

    def highest_of(self, values: Iterable[object]) -> DataClass:
        parsed = [self.parse(value) for value in values]
        if not parsed:
            raise ValueError("no data class given")
        return max(parsed)

    def from_scale(self, scale_id: str, level: object) -> DataClass:
        """Translate a level of an older scale (see ``mappings`` in the file)."""
        table = self._mappings.get(scale_id)
        if table is None:
            raise ValueError(f"unknown source scale {scale_id[:_SHOWN_MAX]!r}")
        if not isinstance(level, str) or level not in table:
            raise UnknownDataClassError(level, f"level of {scale_id}")
        return self._by_id[table[level]]


def load(path: Path) -> Scale:
    """Read and check a data class file; any deviation raises ``ValueError``."""
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"{path.name}: not JSON ({exc.msg})") from exc
    _keys(document, {"format", "classes", "mappings"}, "file")
    if document["format"] != FORMAT:
        raise ValueError(f"format must be {FORMAT!r}")
    classes = _classes(document["classes"])
    known = {entry.id for entry in classes}
    return Scale(classes, _mappings(document["mappings"], known))


def _keys(value: Any, expected: set[str], where: str) -> None:
    if not isinstance(value, dict):
        raise ValueError(f"{where}: object expected")
    if set(value) != expected:
        unknown, missing = sorted(set(value) - expected), sorted(expected - set(value))
        raise ValueError(f"{where}: unknown fields {unknown}, missing fields {missing}")


def _texts(value: Any, limit: int, where: str) -> Mapping[str, str]:
    _keys(value, set(_LANGUAGES), where)
    for language, text in value.items():
        if not isinstance(text, str) or not text or text != text.strip() or len(text) > limit:
            raise ValueError(f"{where}.{language}: 1 to {limit} characters without padding")
    return MappingProxyType(dict(value))


def _classes(value: Any) -> tuple[DataClass, ...]:
    if not isinstance(value, list) or not value:
        raise ValueError("classes: non-empty list expected")
    result: list[DataClass] = []
    seen: set[str] = set()
    for rank, entry in enumerate(value):
        where = f"classes[{rank}]"
        _keys(entry, {"id", "title", "definition"}, where)
        class_id = entry["id"]
        if not isinstance(class_id, str) or not _ID.fullmatch(class_id):
            raise ValueError(f"{where}.id: lower-case identifier expected")
        if class_id in seen:
            raise ValueError(f"duplicate data class {class_id!r}")
        seen.add(class_id)
        title = _texts(entry["title"], _TITLE_MAX, f"{where}.title")
        definition = _texts(entry["definition"], _TEXT_MAX, f"{where}.definition")
        result.append(DataClass(class_id, rank, title, definition))
    return tuple(result)


def _mappings(value: Any, known: set[str]) -> Mapping[str, Mapping[str, str]]:
    if not isinstance(value, list):
        raise ValueError("mappings: list expected")
    result: dict[str, Mapping[str, str]] = {}
    for index, entry in enumerate(value):
        where = f"mappings[{index}]"
        _keys(entry, {"id", "title", "source", "source_levels", "map"}, where)
        mapping_id = entry["id"]
        if not isinstance(mapping_id, str) or not _MAPPING_ID.fullmatch(mapping_id):
            raise ValueError(f"{where}.id: lower-case identifier expected")
        if mapping_id in result:
            raise ValueError(f"duplicate mapping {mapping_id!r}")
        _texts(entry["title"], _TITLE_MAX, f"{where}.title")
        source = entry["source"]
        if not isinstance(source, str) or not source.strip() or len(source) > _TEXT_MAX:
            raise ValueError(f"{where}.source: 1 to {_TEXT_MAX} characters")
        levels = entry["source_levels"]
        if (
            not isinstance(levels, list)
            or not levels
            or not all(isinstance(level, str) and _ID.fullmatch(level) for level in levels)
            or len(set(levels)) != len(levels)
        ):
            raise ValueError(f"{where}.source_levels: unique identifiers expected")
        table = entry["map"]
        if not isinstance(table, dict) or set(table) != set(levels):
            raise ValueError(f"{where}.map: exactly one target per source level")
        for level, target in table.items():
            if target not in known:
                raise ValueError(f"{where}.map.{level}: {target!r} is not on the scale")
        result[mapping_id] = MappingProxyType(dict(table))
    return MappingProxyType(result)


@lru_cache(maxsize=1)
def _default() -> Scale:
    return load(schemas_dir() / FILE_NAME)


def scale() -> tuple[DataClass, ...]:
    """All classes of the kit's scale, least sensitive first."""
    return _default().classes


def ids() -> tuple[str, ...]:
    return tuple(entry.id for entry in _default().classes)


def lowest() -> DataClass:
    return _default().classes[0]


def highest() -> DataClass:
    return _default().classes[-1]


def parse(value: object) -> DataClass:
    """The class with exactly this id; anything else raises :class:`UnknownDataClassError`."""
    return _default().parse(value)


def compare(left: object, right: object) -> int:
    """-1, 0 or 1 as ``left`` is less, equally or more sensitive than ``right``."""
    return _default().compare(left, right)


def at_most(value: object, limit: object) -> bool:
    """True if ``value`` is not above ``limit`` (data may go where ``limit`` is allowed)."""
    return _default().compare(value, limit) <= 0


def exceeds(value: object, limit: object) -> bool:
    """True if ``value`` is above ``limit``; callers answer with ``class_exceeded``."""
    return _default().compare(value, limit) > 0


def highest_of(values: Iterable[object]) -> DataClass:
    """The most sensitive class among ``values``; an empty input raises ``ValueError``."""
    return _default().highest_of(values)


def from_scale(scale_id: str, level: object) -> DataClass:
    """Translate a level of an older scale (``me-contract-v1``, ``studio``)."""
    return _default().from_scale(scale_id, level)
