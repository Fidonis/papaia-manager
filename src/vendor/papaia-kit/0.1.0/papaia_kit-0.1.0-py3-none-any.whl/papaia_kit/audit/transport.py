"""Transport of outbox batches to ``papaia-audit`` (``POST /v1/ingest``, mutual TLS only)."""

from __future__ import annotations

import asyncio
import http.client
import ssl
from pathlib import Path
from typing import Literal, Protocol
from urllib.parse import urlsplit

from papaia_kit.audit.outbox import MAX_ACK_BYTES

INGEST_URL = "https://papaia-audit:8443/v1/ingest"
CONTENT_TYPE = "application/x-ndjson"

IngestFailure = Literal["unreachable", "tls", "rejected", "bad_response"]

__all__ = [
    "CONTENT_TYPE",
    "INGEST_URL",
    "AsyncIngestTransport",
    "HttpsIngestTransport",
    "IngestError",
    "IngestFailure",
    "IngestTransport",
    "ThreadedIngestTransport",
]


class IngestError(Exception):
    """A batch was not acknowledged. ``reason`` is one of :data:`IngestFailure`.

    The message never carries the request or response body.
    """

    def __init__(self, reason: IngestFailure, detail: str = "") -> None:
        self.reason: IngestFailure = reason
        # A status number or an exception class name; never a body.
        self.detail = detail
        super().__init__(f"{reason}: {detail}" if detail else reason)


class IngestTransport(Protocol):
    """Sends one encoded batch and returns the raw acknowledgement."""

    def send(self, body: bytes) -> bytes: ...


class AsyncIngestTransport(Protocol):
    async def send(self, body: bytes) -> bytes: ...


class HttpsIngestTransport:
    """``POST`` to the ingest over TLS with a client certificate of the platform PKI.

    There is no plaintext mode and no way to turn verification off: the URL must
    be ``https``, the server certificate must chain to ``ca_file`` and match the
    host name, and the client always presents ``cert_file``. ``papaia-audit``
    takes the source name from that certificate.
    """

    def __init__(
        self,
        *,
        cert_file: str | Path,
        key_file: str | Path,
        ca_file: str | Path,
        url: str = INGEST_URL,
        timeout: float = 10.0,
    ) -> None:
        parts = urlsplit(url)
        if parts.scheme != "https":
            raise ValueError("audit ingest requires an https URL; plaintext is refused")
        if not parts.hostname or parts.username or parts.password:
            raise ValueError("audit ingest URL needs a host and no user information")
        if parts.query or parts.fragment:
            raise ValueError("audit ingest URL must not carry a query or fragment")
        if not timeout > 0:
            raise ValueError("timeout must be positive")
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        try:
            context.load_verify_locations(cafile=str(ca_file))
            context.load_cert_chain(certfile=str(cert_file), keyfile=str(key_file))
        except (OSError, ssl.SSLError) as error:
            # File names only; the files' content never appears in a message.
            raise ValueError(
                f"cannot load the client certificate or CA ({type(error).__name__})"
            ) from None
        self._context = context
        self._host = parts.hostname
        self._port = parts.port or 443
        self._path = parts.path or "/"
        self._timeout = timeout

    def send(self, body: bytes) -> bytes:
        conn = http.client.HTTPSConnection(
            self._host, self._port, context=self._context, timeout=self._timeout
        )
        try:
            conn.request(
                "POST",
                self._path,
                body=body,
                headers={"Content-Type": CONTENT_TYPE, "Accept": "application/json"},
            )
            response = conn.getresponse()
            payload = response.read(MAX_ACK_BYTES + 1)
        except ssl.SSLError as error:
            raise IngestError("tls", type(error).__name__) from None
        except (OSError, http.client.HTTPException) as error:
            raise IngestError("unreachable", type(error).__name__) from None
        finally:
            conn.close()
        if response.status != http.HTTPStatus.OK:
            raise IngestError("rejected", f"status {response.status}")
        if len(payload) > MAX_ACK_BYTES:
            raise IngestError("bad_response", "acknowledgement too large")
        return payload


class ThreadedIngestTransport:
    """Runs a blocking transport in a worker thread for :class:`AsyncAuditWriter`."""

    def __init__(self, transport: IngestTransport) -> None:
        self._transport = transport

    async def send(self, body: bytes) -> bytes:
        return await asyncio.to_thread(self._transport.send, body)
